'use strict';var data={},fakePP=0,debug=console.log,log=console.log,verTG=0,_DEBUG=1,num_tabs=0,dark;function geVal(a,b){chrome.storage.local.get(a,b)}
function getVal(a,b){geVal(a,c=>{b(c[a])})}
function tVal(a){}
function seVal(a,b){chrome.storage.local.set(a,b)}
function setVal(a,b,c){var k={};k[a]=b;seVal(k,c)}
function gm(a){return chrome.i18n.getMessage(a)||a}
var menu=chrome.contextMenus;_DEBUG&&menu.removeAll();(function(){function a(e){if(1>e)throw Error("长度不能小于1");var g={};g.data=new Map;g.sz=e;g.set=function(l,m){var n=g.data,q=g.sz;n.delete(l);n.set(l,m);n.size>q&&(l=n.keys().next().value,n.delete(l))};
g.get=function(l){var m=g.data;if(m.has(l)){var n=m.get(l);m.delete(l);m.set(l,n);l=n}else l=null;return l};
return g}
function b(e,g){var l=popupCache.bkmk?.id;if(l==e||l==g)popupCache.bkmk=0;(l=c!=e&&(!g||g!=k))||(h=Date.now(),l=100<=h-p);if(l){p=h;c=e;k=g;l=0;for(var m,n;m=data.bkmks[l++];){if(n=m[e])n.data=null,n.stl=!0,n.ver++;g&&(n=m[g])&&(n.data=null,n.stl=!0,n.ver++)}}}
(function(){chrome.bookmarks.onMoved.addListener(function(e,g){b(g.oldParentId,g.parentId);e==navBkmk&&fixNav()});
chrome.bookmarks.onRemoved.addListener(function(e,g){b(g.parentId);e==navBkmk&&fixNav()});
chrome.bookmarks.onCreated.addListener(function(e,g){b(g.parentId)});
chrome.bookmarks.onChanged.addListener(function(e,g){chrome.bookmarks.get(e,function(l){l&&l.length&&b(l[0].parentId)})});
chrome.bookmarks.onChildrenReordered.addListener(function(e,g){b(e)})})();
var c,k,p=0,h=0,f=a(5);window.newLru=a;window.pullBkmk=function(e,g,l,m){if(m){l&&(popupCache={});for(var n=0,q;q=data.bkmks[n++];)if(q=q[e])q.data=null,q.stl=!0,q.ver++}if(popupCache.bkmk?.id===e&&popupCache.bkmk?.data)g(popupCache.bkmk?.data);else if(e.startsWith("recent"))m=parseInt(e.slice(6).replaceAll("=","").trim())||1E3,chrome.bookmarks.getRecent(m,function(r){g(r);l&&(popupCache.bkmk={id:e,data:r})});
else if(e.startsWith("q="))chrome.bookmarks.search(e.slice(2),function(r){g(r);l&&(popupCache.bkmk={id:e,data:r})});
else{var t=0;if(!m){n=0;for(var u;q=data.bkmks[n++];)if((u=q[e])&&u.data){t=u.data;break}}t?(setTimeout(function(){g(t)},0),l&&(popupCache.bkmk={id:e,
data:t})):chrome.bookmarks.getChildren(e,function(r){f.set(e,r);g(r);l&&(popupCache.bkmk={id:e,data:r})})}}})();
data.bkmks=[];function d(){return data}
loadJs("tabModel.js",function(){});
menu.create({id:"open_page",title:gm("r"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp",title:gm("6"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp1",title:gm("6")+" ("+gm("uu")+")",contexts:["browser_action","page_action"]},()=>{});
var _MD;menu.create({id:"dark",title:"temp",contexts:["browser_action","page_action"]},()=>{});
menu.onClicked.addListener(func);function toggleDark(){dark=!dark;updateDarkMenu();setVal("dark",dark);return dark}
function updateDarkMenu(){menu.update("dark",{title:gm("切换扩展颜色")+" ("+(dark?gm(" 黑暗 "):gm(" 亮 "))+")"})}
getVal("dark",a=>{dark=a;updateDarkMenu()});
data.getOpt=function(){data.opt||(data.opt={autoExp:1,mcTab:1,tkImp:0,topImp:0,uniImp:1});return data.opt};
data.saveOpt=function(){var a=data.opt;a?.dirty&&(delete a.dirty,setVal("opt",a))};
getVal("opt",a=>{a.dirty&&delete a.dirty;data.opt=a});
function func(a){a=a.menuItemId;"open_page"==a&&chrome.tabs.create({url:`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html`});"add_tmp"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b)});
"add_tmp1"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b,0,!0)});
"dark"==a&&toggleDark();_DEBUG&&_MD&&_MD(a)}
var tmpUrlData,tmpUrlPath,tmpUrlTitle,tmpUrlDataDirty,impUrlTd={};function getImpd(a){if(a==tmpUrlPath&&tmpUrlData)return tmpUrlData}
function cacheImpd(a,b){getTmpUrlPath(c=>{a==c&&(tmpUrlData=b)})}
function getTmpUrlPath(a){tmpUrlPath?a(tmpUrlPath):getVal("sel_tmp_url",b=>{"string"==typeof b&&(b={key:b});b=b||{};var c=b.key;c||="";c.startsWith("imp_")||(c="imp_tmp");tmpUrlPath=c;tmpUrlTitle=b.title||"";a(tmpUrlPath)})}
function setTmpUrlPath(a,b,c){tmpUrlPath!=a&&(tmpUrlDataDirty&&saveTmpUrls(),tmpUrlData=tmpUrlPath=0,setVal("sel_tmp_url",{key:a,title:b},c));tmpUrlTitle=b||""}
getTmpUrlPath(()=>{});
function getTmpUrlData(a){tmpUrlData?a(tmpUrlData):getTmpUrlPath(b=>{getVal(b,c=>{c||={};c.data||(c.data=[]);tmpUrlData=c;a(c)})})}
function pullImpt(a,b){var c=tmpUrlPath===a;if(c&&tmpUrlData)b(tmpUrlData);else{var k=0;if(!k){for(var p=0,h;(h=data.bkmks[p++])&&!(k=h[a]););k?(setTimeout(function(){b(k)},0),c&&(tmpUrlData=k)):getVal(a,f=>{f||={};
f.data||(f.data=[]);parseInt(f.v)&&(f.v=0);"string"==typeof f.data&&(f.data=JSON.parse(f.data));b(f);c&&(tmpUrlData=f)})}}}
function dataToClipboard(a){navigator.clipboard.writeText(a)}
function addToTmpUrls(a,b,c,k,p){dataToClipboard(a);getTmpUrlData(h=>{function f(m){p?h.data.splice(0,0,m):"add"==h.data[h.data.length-1]?.url?h.data.splice(h.data.length-1,0,m):h.data.push(m);tmpUrlDataDirty=!0;h.v=(h.v||0)+1}
for(var e=!1,g=0;g<h.data.length;g++)if(h.data[g].url===a){p?h.data.splice(g,1):e=!0;break}if(!e){var l=c?.url;function m(){b=l.slice(l.indexOf(":")+3);0<b.indexOf("/",5)&&(b=b.slice(0,b.indexOf("/",5)))}
void 0!==b||l.startsWith("chrome")||l.startsWith("edge")?(b||m(),f({url:a,title:b,favIconUrl:c.favIconUrl}),k&&k(h.data)):chrome.tabs.executeScript(c.id,{code:`window._tmpUrl=\"${a.replace('"',"")}\";window._tmpTop=${p};window._tmpTo=\"${tmpUrlTitle} - ${"important://"+tmpUrlPath.slice(4)}\"`},function(n){chrome.tabs.executeScript(c.id,{file:"js/tada_active.js"},function(q){(b=q[0])&&"undefined"!=b||m();f({url:a,title:b,favIconUrl:c.favIconUrl});k&&k(h.data)})})}})}
menu.create({title:gm("bz"),contexts:["link"],onclick:function(a,b){setTimeout(()=>{var c=Date.now()-topTempTime;addToTmpUrls(a.linkUrl,void 0,b,0,100>c&&0<=c)},50)}});
function loadSortable(a){loadJs("popup/Sortable.js",function(){a()})}
function loadListView(a){loadJs("popup/ListView.js",function(){a&&a()})}
function loadJs(a,b){var c=document.createElement("script");c.type="text/javascript";c.onload=b;c.src=a;document.body.appendChild(c)}
var lastAct,bkWnds={};chrome.tabs.onActivated.addListener(function(a){bkWnds[lastAct]&&chrome.tabs.sendMessage(lastAct,{name:"blur"},function(b){});
bkWnds[lastAct=a.tabId]&&chrome.tabs.sendMessage(a.tabId,{name:"focus"},function(b){});
tmpUrlDataDirty&&saveTmpUrls()});
data.favTabsVer=data.favTabsSave=data.tabsVer=0;function saveImportabs(a,b){cacheImpd(a,b);setVal(a,b,function(){})}
chrome.tabs.onUpdated.addListener(function(a,b,c){if(a=data.favTabs[a])data.favTabsVer++,a.lastUrl=a.url!=c.url?c.url:void 0});
chrome.tabs.getAllInWindow(null,function(a){num_tabs=a.length});
chrome.tabs.onCreated.addListener(function(a){num_tabs++});
chrome.tabs.onRemoved.addListener(function(a){num_tabs--;0==num_tabs&&onClose()});
function onUnLoad(){chrome.storage.local.set({date:Date.now()},function(){})}
function saveTmpUrls(){tmpUrlDataDirty=0;tmpUrlData&&setVal(tmpUrlPath,tmpUrlData)}
function onClose(){data.favTabsSave!=data.favTabsVer&&saveImportabs();onUnLoad();tmpUrlDataDirty&&saveTmpUrls()}
chrome.runtime.onMessage.addListener(function(a,b,c){if(a&&a.type){if("bkmk"==a.type){var k=b.tab.url;a.url&&(k=a.url);function f(e){e={ret:e||[]};a.cb&&chrome.tabs.executeScript(b.tab.id,{code:`var backEvt = new CustomEvent("${a.cb}", {detail : ${JSON.stringify(e)}});
						window.dispatchEvent(backEvt);`},()=>{})}
a.get?chrome.bookmarks.search({url:k},e=>f(e)):a.update?chrome.bookmarks.search({url:k},function(e){e&&e.length?chrome.bookmarks.update(e[0].id,{title:a.name},g=>f(g)):chrome.bookmarks.create({title:a.name,
url:k},function(g){f(g)})}):chrome.bookmarks.create({title:a.name,
url:k},function(e){f(e)});
c("nores")}"load_url"==a.type&&(a.sch?chrome.tabs.query({url:a.sch},function(f){(f=f?f[0]:0)&&chrome.tabs.update(f.id,{url:a.url})}):searchActiveTab(f=>{chrome.tabs.update(f.id,{url:a.url})}));
"paste"==a.type&&sendPasteToContentScript(a.data);if("openAll"==a.type){c=a.urls.split("{BKMKBK}");var p=0,h;for(h in c){let f=c[h];setTimeout(function(){f&&chrome.tabs.create({url:f,active:!1})},500*p);
p++}}}});
function getContentFromClipboard(){var a="",b=document.getElementById("sandbox");b.value="";b.select();document.execCommand("paste")&&(a=b.value,console.log("got value from sandbox: "+a));b.value="";return a}
function sendPasteToContentScript(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){chrome.tabs.sendMessage(b[0].id,{data:a})})}
var topTempTime,delTm=0,schTime,detTime,navPath,navCtx,navBkmk;function fixNav(){navBkmk&&navCtx.idx--}
function checkDeltm(){var a=Date.now();if(250<=a-delTm)return delTm=a,1}
function navNxt(a){if(void 0===a){a=!0;var b=Date.now()-topTempTime;100>b&&0<=b&&(a=!1)}var c=navPath;c.startsWith("q=")||!isNaN(c)?pullBkmk(c,k=>{function p(e){return e.startsWith("javascript:")||e.startsWith("https://separator")}
var h=navCtx.idx;h+=a?1:-1;0>h&&(h=0);h>=k.length&&(h=k.length-1);navCtx.idx=h;navCtx.ni&&(h=k.length-h-1);for(var f=k[h];f&&(!f.url||p(f.url));)f=k[h+(a?1:-1)*(navCtx.ni?-1:1)],navCtx.idx+=a?1:-1;f&&(navBkmk=f.id,searchActiveTab(e=>{chrome.tabs.update(e.id,{url:f.url})}))}):c.startsWith("imp")&&pullImpt(c,k=>{var p=navCtx.idx;
navCtx.tmp&&a||(p+=a?1:-1);0>p&&(p=0);p>=k.data.length&&(p=k.data.length-1);var h=k.data[navCtx.idx=p];h&&(navCtx.tmp&&checkDeltm()&&(p=k.data.splice(navCtx.idx,1),log("deleted ……",p),saveImportabs(c,k)),searchActiveTab(f=>{chrome.tabs.update(f.id,{url:h.url});h.session&&chrome.tabs.executeScript(f.id,{code:`var ret=${h.session};
							for (var key in ret) {
								sessionStorage.setItem(key, ret[key]);
							}
							document.documentElement.scrollTop=ret.scrollTop`},function(e){})}))})}
chrome.commands.onCommand.addListener(function(a){"top-temp-url"==a?(topTempTime=Date.now(),schTime&&200>topTempTime-schTime&&searchActiveTab(b=>{chrome.tabs.executeScript(b.id,{code:"getSelection().isCollapsed"},function(c){!1===c[0]&&(schTime=topTempTime,chrome.browserAction.openPopup(function(k){chrome.runtime.lastError}))})})):"sch-panel"==a?schTime=Date.now():"next-item"==a&&navPath?navNxt():"prev-item"==a&&navPath&&navNxt(!1)});
var schKeys=void 0;function getSchKeys(a){void 0==schKeys?getVal("sch_keys",b=>{a(schKeys=b||[])}):a(schKeys)}
function putSchKey(a){getSchKeys(b=>{if(b[b.length-1]!=a){for(var c=0;c<b.length;c++)if(b[c]==a){b.splice(c,1);break}b.push(a);25<b.length&&b.splice(0,b.length-20);setVal("sch_keys",b)}})}
function exportSettings(a){chrome.storage.local.get(null,function(b){log("exportSettings::",b);window.backup=b;a&&a(b)})}
function importSettings(a,b){try{a=JSON.parse(a)}catch(c){console.log(c)}"object"===typeof a&&chrome.storage.local.set(a,function(c){b&&b(c)})}
function searchActiveTab(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(b?b[0]:0)})}
function reload(){chrome.runtime.reload()}
;