function initGridTab(win, docu, host){'use strict';(function(){function na(a,b){var c=a.firstChild;if(c)return c;for(;a&&a!=b;){if(c=a.nextSibling)return c;a=a.parentNode}}
function x(a,b,c){a=R.createElement(a||"DIV");c&&(a.className=c);b&&b.appendChild(a);return a}
function ba(a,b){b=F;q&&b&&b.hovable&&(a instanceof DragEvent&&a.preventDefault(),a=(new Date).getTime(),L!=b&&(L&&ca(),foverStar=a,L=b),0<foverStar&&500<a-foverStar&&(q.options.revertOnSpill=0,S=!0,da(1),T()))}
function ea(a){T();a.preventDefault();a.stopPropagation();y.multiDragElements=fa}
function da(a){q.options.group=a?"appoug":"null";y._prepareGroup(q.options)}
function ca(){M=!1;u&&(u.classList.remove("icon_h"),u=null)}
function U(a){a=ha.styleSheets;for(var b,c=0;(b=a[c++])&&b.ownerNode!=ia;);if(b&&host.parentNode){c=host.clientWidth;a=document.body;G=isPopup?c:Math.min(c,(a.clientHeight+a.clientWidth)/2);a=Math.floor(G/5)+-1;A=Math.floor(c/a);8<A&&(a=Math.floor(c/8)+-1,A=8);n=a-3;var d=n*A;B=.72*n;a=.3*B/2;var e=.7*B;V=(n-B)/2;W=(c-d)/2;b=b.rules?b.rules:b.cssRules;c=0;for(var f;c<b.length;c++)switch(d=b[c],f=d.selectorText,f){case ".item-sqr":d.style.width=n+"px";d.style.height=n+12+"px";break;case ".fimg":f=
e+"px";d.style.width=f;d.style.height=f;d.style.marginLeft=V+"px";d.style.padding=a+"px";break;case ".fico":d.style.backgroundSize=e+"px";break;case ".sico":var k=.75*n*.4;f=k+"px";var g=(B-2*k)/3+"px";d.style.width=f;d.style.height=f;d.style.margin=g;d.style.backgroundSize=k+"px";break;case "#grido":d.style.marginLeft=W+"px";break;case "#drpMask":d.style.marginLeft=-W+"px";break;case "#foldo":case "#folderview":d.style.width=n*(A-1)+"px"}}}
function ja(){U();0>=G&&-5<G--?setTimeout(ja,10):v.hidden=0}
function oa(a){for(var b=r.d;b&&!b.classList.contains("item-sqr");)b=b.parentNode;host.dblclick(a,b)}
function ka(a,b,c,d){c?b=1==c?C:2==c?D:c.el||c:b.innerHTML="";for(var e=b==D,f=[w(0),w(1),w(2)],k=0,g;g=a[k];k++){var l=g[f[0]],m=x("DIV",0,"item-sqr");m.raw=1;m.ondblclick=oa;e&&(m.infolder=1);var N=x("DIV",m,"fimg"),X=x(pa,N,"fico"),pa="DIV";if(l.constructor===Array){N.style.position="relative";m.f_=m;for(var t=Math.min(l.length,4),H=0;H<t;H++){var qa=x("IMG",N,"sico fimg_"+H),Y=l[H][f[2]]||"chrome://favicon/size/48/"+l[H][f[0]];qa.style.backgroundImage="url("+Y+")"}}else Y=g[f[2]]||"chrome://favicon/size/48/"+
l,X.style.backgroundImage="url("+Y+")";g.fixed&&(m.fixed=1);l=x("SPAN",m,"fnam");t=g[f[1]]||"";"("==t[0]&&t.includes(")")&&(t=t.slice(1+t.indexOf(")")));l.innerText=t;m.icon=X;m.iconItem=N;m.textItem=l;m.hovable=1;m.data=g;X.title=t;d?b.insertBefore(m,d):b.appendChild(m)}if(c)return d?d.previousElementSibling:b.lastElementChild;host.onload(b)}
function ra(a){host.dirty();var b=a.data,c=b.url,d=a.iconItem,e=!a.f_;e?(a.f_=a,d.style.position="relative",a.classList.add("icon_h"),a.prepend(d),a.iconItem=d,a.icon.style.backgroundImage="",setTimeout(()=>{a.classList.remove("icon_h")},80)):a.classList.remove("icon_h");
a.ondblclick=host.dblclick;O&&e&&(b.title=O.data.title);a.textItem.innerText=b.title;e=d.children;for(var f=Math.min(c.length,4),k=0;4>k;k++){var g=e[k+1];if(k<f){b=c[k];var l=b[w(0)];g?g.style.display="":g=x("DIV",d,"sico fimg_"+k);l=b[w(2)]||"chrome://favicon/size/48/"+l;g.style.backgroundImage="url("+l+")"}else if(g)g.style.display="none";else break}a.textItem.innerText=b.title}
function T(){P.hidden=1;v.classList.add("d_hide");I.classList.remove("ovis");Q=z;if(J){var a=J.data,b=Z.innerText;a.title!=b&&(a.title=b,ra(J),F||console.log("//todo delay a sec and save"))}}
var R=docu,y=win,ha=R,h=function(a){return ha.getElementById(a)},p=h("gdSty");
p||(p=x("LINK",R.head),p.id="gdSty",p.rel="stylesheet",p.type="text/css",p.href="sortable.css");var ia=p;host.shadow=host;host.shadow.innerHTML='<div id="APP" class="mask ovis">\n\t<div class="mask" id="mask" ></div>\n\t<div id="gridview" class="mask">\n\t\t<div id="grido" >\n\t\t</div> \n\t</div> \n\t<div id="drpMask" class="mask"></div>\n\t<table id="folderview" border="0" bordercolor="#ff0000" cellpadding="5" hidden class="d_hide">\n\t\t<tr height="auto">\n\t\t\t<td>\n\t\t\t\t<div id="foldo"></div>\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr height="auto" valign="top">\n\t\t\t<td><hr/><span id="folderName" contentEditable=true>文件夹名称</span></td>\n\t\t</tr>\n\t</table>\n</div>';
host.mod=0;ia||=h("gdSty");var la={};for(p=h=host.shadow;h=na(h,p);)h.id&&(la[h.id]=h);h=function(a){return la[a]};
var z,P=h("drpMask");p=h("mask");var D=h("foldo"),I=h("gridview"),v=h("folderview"),Z=h("folderName"),O,C=h("grido");h("APP");C.scrollParent=I;P.ondragover=p.ondragover=ba;P.onclick=p.onclick=ea;Z.onkeydown=function(a){13==a.keyCode&&"folderName"===a.target.id&&ea(a)};
y.allowDrop=ba;var ma,K,aa,E,F,L,S,u,M,J,fa=[];y.multiDragElements=fa;var r={down:function(a){r.nullHovering();ca();r.d=a.target;r.gridis=a.altKey&&a.shiftKey;y.disani=M=F=E=S=0},
hover:function(a){},
hoved:function(a){var b=u&&M;if(!a)return b;if(b){b=u;var c=b.data,d=c.url;d.constructor!==Array&&(c={},Object.assign(c,b.data),c.url=d=[b.data],b.data=c,c.title="文件夹");a.forEach(function(e,f){e.url.constructor===Array?e.url.forEach(function(k,g){d.push(k)}):d.push(e)})}},
foled:function(a){a.target==C&&E&&!K&&(K=setTimeout(()=>{K=E=null},800))},
nullHovering:function(){M=!1;u&&(u.classList.remove("icon_h"),u=null)},
foved:function(){if(L&&S){var a=J;if(a){a=a.data;for(var b=[],c=D.childNodes,d=c.length,e=0;e<d;e++)c[e].data&&b.push(c[e].data);a.url=b}return 1}return 0},
postDrop:function(a){a&&(q.els().forEach(function(b,c){z.els().push(b)}),q.els.length=0)},
trace:function(){console.log("trace"+Error().stack)},
click:function(a){for(var b=r.d;b&&!b.classList.contains("item-sqr");)b=b.parentNode;if(b){if(!a.asc&&!r.gridis){var c=b.data;if(c&&c.url){var d=c.url;if(d.constructor===Array){J=b;a=document.documentElement.clientHeight;var e=Math.ceil(d.length/Math.max(A-1,1)),f=n+32;e=Math.min(Math.floor((a-100)/f),e)*f;f=b.offsetLeft+n/2+V;var k=b.offsetTop+B/2,g=b.offsetTop-e/2,l=document.documentElement.scrollTop;g=Math.min(l+a-e-100,Math.max(l,g));v.style.top=g+3+"px";D.style.height=e+"px";a=32;b.offsetLeft>
document.documentElement.clientWidth/2-n/2&&(a=n-a);v.style.left=a+3+"px";v.style.transformOrigin=f-a+"px "+(k-g-I.scrollTop)+"px";Z.innerText=c.title;P.hidden=0;v.hidden=0;v.classList.remove("d_hide");q.options.revertOnSpill=1;I.classList.add("ovis");ka(d,D);da(0);Q=q;deselect=!1}else host.click(a,b)}else host.click(a,b)}b.iconItem.classList.add("ihover");setTimeout(()=>{b.iconItem.classList.remove("ihover")},300)}},
setData:function(a,b){a.setData("text",b.data[w(0)])},
f:1},w,G=0,n,A,B,V,W;host.onAttach=function(){G=0;y.addEventListener("resize",U);ja();host.grid&&(tvNow.grid(1).el.focus(),host.onResume())};
host.onRemove=function(a){a||(v.hidden=1,y.removeEventListener("resize",U));host.save()};
var Q=z=new Sortable(C,{multiDrag:!0,swapThreshold:.34,revertOnSpill:!0,invertSwap:!0,scroll:!0,forceAutoscroll:!0,scrollSensitivity:200,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"appoug",root:!0,forceFallback:!1,sort:!0,funs:r,setData:r.setData,onStart:function(a){O=a.item.f_},
onEnd:function(a){O=null;z.did(a)&&host.dirty()},
onMove(a){if(a.dragged.fixed||a.related.fixed)return!1;(a.related.f_||a.originalEvent.shiftKey)&&a.related!==E&&(clearTimeout(ma),K&&clearTimeout(K),aa=!1,E=a.related,ma=setTimeout(function(){aa=!0},500));
if(a.related===E&&!aa)return!1}});var q=new Sortable(h("foldo"),{multiDrag:!0,swapThreshold:.34,revertOnSpill:!0,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",funs:r,setData:r.setData,onStart:function(a){F=a.item},
onEnd:function(a){F=null;q.did(a)&&host.dirty()},
onMove(a){if(a.dragged.fixed||a.related.fixed)return!1}});T();host.layout=function(a,b,c,d){(w=b)||(w=function(e){return 0==e?"url":1==e?"title":"favIconUrl"});
return ka(a,C,c,d)};
host.grid=function(a){return 1==a?z:Q};
host.grido=function(a){return 1==a?z.el:Q.el};
host.dblclick=function(a,b){a=0;b==I||b==C?a=z:b==D&&(a=q);a&&a.multiDrag._deselectMultiDrag()};
host.load()})();}