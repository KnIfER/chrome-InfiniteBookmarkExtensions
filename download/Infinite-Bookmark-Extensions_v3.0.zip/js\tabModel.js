'use strict';function newTabid(b,a){a||=0;var d=55<a?555<a?1015:110:15,c=10*Math.floor(a/10);var f=d+3;do if(a=c+Math.floor(Math.random()*d),0>--f){a=-1;break}while(b[a]);if(-1==a){do a=Math.floor(1E10*Math.random());while(b[a])}return a}
function newTab(b,a,d,c,f,e){var g={};g.type=d||0;g.path=a;void 0!=f&&(g.title=f);if(void 0==e||void 0!=b[e])e=newTabid(b,c?c.children.length:0);return b[g.id=e]=g}
var tabsLoaded=!1,popupCache={};function reinitTabs(b){popupCache={};return initTabs(b)}
function pullTabsByGroup(b,a,d){var c=a.id===popupCache.sel_id;c&&(a.tPs=popupCache.tPs,a.tPs||(a.tPs=popupCache.tPs={}));getVal([a.id],function(f){var e=f;try{e=JSON.parse(f)}catch(g){}e&&e.constructor===Array||(e=[]);e.now=a.tid||0;c&&(popupCache.tabs=e);b(e,a,d)})}
function getTabGroupSpec(b,a,d){if(b){b=b.sessionStorage.getItem(a,null);try{b=JSON.parse(b)}catch(c){b=0}b?d&&d(b):getTabGroupSpec(0,a,d)}else getVal(a,function(c){d&&d(c)})}
function initTabs(b,a,d){getTabGroupSpec(a,"sel_tab_gp",c=>{d&&(c=d);c&&void 0!==c.id||(c={id:"tabs",tid:0,type:1});getTabGroupSpec(a,"v_"+c.id+"__",f=>{f=f||{};1==c.type?chrome.bookmarks.getChildren("1",function(e){f.bar=e;pullTabsByGroup(b,c,f)}):pullTabsByGroup(b,c,f)})})}
reinitTabs(()=>{});
function saveTabs(b,a,d){a&&setVal(b.id||"tabs",a,function(c){d()})}
;