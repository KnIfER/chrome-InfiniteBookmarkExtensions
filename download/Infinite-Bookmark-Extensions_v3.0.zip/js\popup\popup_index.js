'use strict';var m=chrome.extension.getBackgroundPage(),aa=4,ba=m.dark;if(m.fakePP){if(400>Date.now()-m.fakePP)throw setTimeout(function(){window.close()},200),1;
m.fakePP=0}const da=15,ha=0,ja=1,ka=2;var la,ma,pa,y=location.href==`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html?popup=1`,qa=console.log,ra=console.log,va=console.error,B=document,I=window,xa,ya=0,Ba=void 0;I.isPopup=y;function Ca(a,b){return(b||B).getElementById(a)}
function Da(a,b){return(b||B).getElementByTagName(a)[0]}
function Ea(a,b){return(b||B).getElementsByTagName(a)}
function Ga(a,b){return(b||B).getElementsByClassName(a)[0]}
function Ha(a,b){return(b||B).getElementsByClassName(a)}
function K(a){return chrome.i18n.getMessage(a)||a}
function Ia(a,b){a.innerText=b}
function Ja(a,b){a.innerHTML=b}
function Ka(a,b,c){for(;b;){if(b.classList&&b.classList.contains(a))return b;if(c&&b==c)break;b=b.parentNode}}
function La(a,b,c,d){d||=win;d.addEventListener(a,b,c)}
function Ma(a,b,c,d){d||=win;d.removeEventListener(a,b,c)}
function Na(a){var b=a.path||"";a=a.type;a==Pa?b.startsWith("recent")||(/^\d+$/g.test(b)?b="chrome://bookmarks/?id="+b:(b.startsWith("q=")&&(b=b.slice(2)),b="chrome://bookmarks/?q="+b)):a==Qa&&(b.startsWith("recent")||(b="important://"+b.slice(4)));return b}
function O(a,b,c,d){a=B.createElement(a||"DIV");c&&(a.className=c);d&&(a.style=d);b&&b.appendChild(a);return a}
function R(a,b){try{b?a.stopImmediatePropagation():a.stopPropagation(),a.preventDefault()}catch(c){va(c)}}
function La(a,b,c,d){(d||I).addEventListener(a,b,c)}
function Ta(a){navigator.clipboard.writeText(a)}
const Ua=chrome.storage.local;function Va(a,b){Ua.get(a,b)}
function Wa(a){Ua.get(a,b=>{console.log(b[a])})}
function Ya(a,b){Va(a,c=>{b(c[a])})}
var Za={};function $a(a,b){Za[a]?b(Za[a]):Ya(a,c=>{b(Za[a]=c)})}
function ab(a,b){Ua.set(a,b)}
function cb(a,b,c){var d={};d[a]=b;ab(d,c)}
function db(a,b){Ua.remove(a,b)}
var eb=m.d(),fb,gb,hb={},ib=O("style",document.head);hb.reload=()=>{setTimeout(()=>{location.reload()},350)};
eb.bkmks.push(hb);O("style",document.head).innerText=`.folder-icon > .item-icon{-webkit-mask-image:url("chrome-extension://${chrome.runtime.id}/images/folder_open.svg")}`;ib.innerText=".img,IMG,.fico{display:none!important}";var jb=Ca("tabos"),kb=Ca("tabNew"),T=kb.parentNode,lb=T.parentNode,ob,pb,qb=[],rb,sb,tb,ub,vb,xb,yb,Cb={},Db={},Eb={},Fb,Gb,Hb,Ib,Jb=eb.getOpt();B.title=K("2u");var Kb,Lb;function Mb(a,b,c){if(a){a=a.classList;var d=a.contains(b);if(void 0===c||d^!!c)d?a.remove(b):a.add(b)}}
function Nb(a){return a.path.startsWith("recent")}
function Pb(a,b){m.initListView&&!Qb||m.loadListView();Kb||function(){function d(g,k,z){if(!k.t){var t=k._=k;t.classList.add("item-wrap");k.dot=O("P",t,"dot");k.con=O(0,t,"item-icon");k.icon=O(0,k.con,"img");k.lv=O("DIV",t,"item-tlv");k.t=O("P",k.lv,"item-title");k.st=O("P",k.lv,"item-subtitle");k.lv.draggable=!0;k.lv.ondragstart=Q;k.lv.ondragend=ia;k.ondblclick=ta;k.oncontextmenu=G;k.lst=g}t=g.ada.getItem(z);var v=g.salad;t||={title:""};k.data=t;var A=t.title||" ";if(A.startsWith("(")){var x=A.indexOf(")");
0<x&&(A=A.slice(x+1).trim())}k.t.innerText=A;A=t.url;x=k.icon;k.lv.href=A;Rb(t)^k.folder&&(k.folder=!k.folder,k.folder?(k._.classList.add("folder-icon"),x.style.backgroundImage=""):k._.classList.remove("folder-icon"));var C=v&&v[t.id];Mb(k._,"selecting",C||null);C&&C.e!=k._&&(v[t.id].e=k._);na==t.id&&wb!=k&&Fa(wb);A?(k.st.innerText=A,k.folder||("javascript:"==A||A.startsWith("javascript:&tm=")||A.startsWith("https://separator")?x.style.backgroundImage="":(t=x.style,v=A,A=v.indexOf("/",v.indexOf(":")+
3),0<A&&(v=v.slice(0,A)),t.backgroundImage='url("chrome://favicon/'+v+'")'))):x.style.backgroundImage="";g.tada===z&&(Sb(k,15),g.tada=void 0)}
function f(g){g=g.target||g;for(var k=0;g;){if(g.data&&g.classList.contains("item")){k=g;break}if(g==B.body||g.classList.contains("ListView"))break;g=g.parentNode}return k}
function h(g){Object.keys(g).forEach(z=>{(z=g[z])&&Mb(z.e,"selecting",0)});
for(var k in g)delete g[k]}
function n(g){if(g){var k=g.tD,z=k.path;hb[z]&&(hb[z].data=0);m.pullBkmk(z,function(t){g.v.onRemove();Kb.bind(g,t,Tb(t,k,z))},y,!0)}}
function l(g){var k=g.ada.dPos(W.pos+1);1==k&&Ub&&Ub.clientY-g.getBoundingClientRect().y<W.offsetHeight/2-5&&(k=0);return k}
function p(g,k,z,t){var v=W.data;k=v.url;var A=W.lst,x=A.salad,C=function(L){L&&n(A);Vb()};
switch(g){case "fold":var M=prompt(K("pe"),K("ai"));A=W.lst;if(M){var P=l(A);chrome.bookmarks.create({parentId:v.parentId,title:M,index:P},C)}break;case "&addThis":P=l(A);Wb(L=>{!L||t.ctrlKey?chrome.bookmarks.create({parentId:v.parentId,url:la.url,title:la.title,index:P},C):chrome.bookmarks.move(L.id,{parentId:v.parentId,index:P},C)});
break;case "newFav":!t||t.ctrlKey?u(v,A,v.parentId,0,v.index+(A.ada.ni?-1:1),!0):Xb(L=>u(v,A,v.parentId,L,v.index+(A.ada.ni?-1:1)));
break;case "add&Sep":r(t,v,A);break;case "&edit":u(v,A);break;case "&replace":Xb(L=>u(v,A,void 0,L));
break;case "&delete":E(v,A);break;case "openFolder":Yb(ob,{path:v.id});break;case "pinTop":(()=>{function L(X,ua,mb,Oa){Xa.length?(ua&&(Oa=bb[ua.pos],ua.id==X.id&&(ua.title=X.title),Oa==ua&&(X=bb.splice(ua.pos,1)[0],ua.pos<mb&&mb--,ua.pos=mb,bb.splice(mb,0,X))),H(Xa.shift())):C(X||1)}
function H(X){var ua=0,mb=(X.title||"").startsWith(ca);if(!J)for(var Oa;Oa=bb[ua];){if(mb&&!nb&&Oa==X){oa="";ua=0;break}if(!(Oa.title||"").startsWith(ca))break;ua++}Oa=bc=>{oa&&bc&&!mb&&!J?chrome.bookmarks.update(X.id,{title:oa+X.title},me=>{L(me,X,ua)}):L(bc,X,ua)};
Y?Oa(X):chrome.bookmarks.move(X.id,{parentId:X.parentId,index:ua},Oa)}
var J=!t||t.shiftKey,Y=t&&t.ctrlKey,oa="\ud83d\udccc ",ca=oa.trim(),bb=listView.arr,nb=w(v,x),Xa=q(v,x,nb,A);nb=1<Xa.length;L()})();
break;case "pinBot":(()=>{function L(ca){var bb=H.length,nb=(ca.title||"").startsWith("\ud83d\udccc "),Xa=X=>{nb&&chrome.bookmarks.update(ca.id,{title:ca.title.slice(3)});oa.length?L(oa.shift()):C(X||1)};
J?Xa(ca):chrome.bookmarks.move(ca.id,{parentId:ca.parentId,index:bb},Xa)}
var H=listView.arr,J=t&&t.ctrlKey,Y=w(v,x),oa=q(v,x,Y,A);Y=1<oa.length;oa.length?L(oa.shift()):C(1)})();
break;case "openAll":g="";for(M in x)g+=A.arr[x[M].pos].url+"{BKMKBK}";chrome.runtime.sendMessage({urls:g,type:"openAll"},function(L){});
break;case "copyUrl":Ta(v.url);Zb(v.url);break;case "openInCurrent":Rb(v)?pb.etLoca.reload(v.id,v.title):k.startsWith("javascript:")?chrome.tabs.executeScript(la.id,{code:decodeURIComponent(k.slice(11))},function(L){y&&window.close()}):chrome.tabs.update(la.id,{url:k},function(L){y&&window.close()});
za();break;case "openInNewTab":$b(v.url,function(L){L&&0<L.length?chrome.tabs.update(L[0].id,{active:!0}):chrome.tabs.create({url:v.url})});
za();break;case "openInBackgroud":Xb(L=>{chrome.tabs.create({url:v.url,index:L.index+1,active:!1})});
za();break;case "openInTmp":(()=>{var L=w(v,x),H=q(v,x,L,A);L=1<H.length;for(var J=0;L=H[J];J++)m.addToTmpUrls(L.url,L.title||"",0,()=>{H[J+1]||Sb(W)})})();
break;case "openInIframe":M=m.newTab(Cb,v.url,ac,T);M.title=v.title;cc(dc([M],0,ob.nextSibling));T.dirty();break;default:return 1}ec();return 1}
function r(g,k,z,t){t=t?"https://separator.mayastudios.com/index.php?t=horz":"javascript:";fc()&&(t+="&tm="+Date.now());chrome.bookmarks.create({parentId:k.parentId,url:t,title:"───────────",index:z.ada.dPos(W.pos+1)},function(v){v&&(n(z),ec(),(g.ctrlKey||1==g.button)&&u(v,z))})}
function w(g,k){return k[g.id]&&1<Object.keys(k).length}
function q(g,k,z,t){var v=t.arr,A=[],x=!1;if(z){for(var C in k)if(z=t.ada.d4sa(C,k[C]),z=v[z])x||z!=g||(x=!0),A.push(z);A.sort(function(M,P){return M.pos-P.pos})}x||A.push(g);
return A}
function u(g,k,z,t,v,A){gc("assets/dialog.js",function(){var x=showDialog(B,B.body);Ia(x.t,K("i"));Ja(x.t1,hc(K("ti").toUpperCase())+hc(K("64").toUpperCase()));var C=void 0!==z;Ia(x.btn0,C?K("gy"):K("2"));Ia(x.btn1,K("z"));var M=Ea("TEXTAREA",x.t1);M[0].value=t?.title||g.title;var P=t?.pendingUrl||t?.url||g.url||"",L=P.startsWith("javascript:");L&&(P=decodeURIComponent(P));M[1].value=P;L&&ic(M[1]);x._kd=H=>{if("Enter"==H.key&&!H.ctrlKey&&(H=x.s.shadow.activeElement,H?.wrap&&"TEXTAREA"==H.tagName&&
H.value.startsWith("javascript:")))return 1};
x.btn0.onclick=()=>{var H=M[1].value;A&&fc()&&(H+=(H.includes("?")?"&":"?")+"tm="+Date.now());H.startsWith("javascript:")&&(H="javascript:"+encodeURIComponent(H.slice(11)));var J=Y=>{Y&&(n(k),x.x());Vb()};
H={url:H,title:M[0].value};C?(H.parentId=z,H.index=v,chrome.bookmarks.create(H,J)):chrome.bookmarks.update(g.id,H,J)};
x.btn1.onclick=()=>{x.x()}},I.showDialog)}
function E(g,k){var z=k.salad,t=w(g,z),v=q(g,z,t,k);gc("assets/dialog.js",function(){var A=showDialog(B,B.body);Ja(A.t,K("6k"));Ja(A.t1,K("p7").replace("size",v.length));Ia(A.btn0,K("b8"));Ia(A.btn1,K("z"));A.btn0.onclick=()=>{var x=()=>{chrome.bookmarks.remove(v.shift().id,function(){0==v.length?n(k):x();Vb()})};
x();A.x()};
A.btn1.onclick=()=>{A.x()}},I.showDialog)}
function G(g){if(window.oncontextmenu==jc)jc(g);else{var k=f(g);if(k)if(g.target==k.icon)ta(g,1),R(g);else{kc(k);var z=k.data,t=k.lst,v=w(z,t.salad),A=lc(t.tD),x=mc(z.url,la.url);v=0==Nc?["",[0,A?"&addThis":0,K("zm"),1,,[0,"add&Sep",K("f")],[0,"fold",K("pe"),1],[0,"newFav",K("b"),1]],[0,A?0:"openFolder",K("c"),1],[0,v?"openAll":0,K("5j")],[0,"&edit",K("y"),1],[0,"&delete",K("v")],[0,x||g.altKey?"&replace":0,K("pp")],[0,"pinTop",K("2t"),1],[0,"pinBot",K("cy")]]:["",[0,"openInCurrent",
K("ol")],[0,"openInNewTab",K("mt")],[0,"openInBackgroud",K("jb")],[0,"openInTmp",K("6")],[0,"openInIframe",K("ln")],[0,"copyUrl",K("qs")]];nc(v,p,g,k,G,[K("p4"),K("g"),Jb.wrapBT?"多行":"单行",Jb.dblBK?"双击":"本页"],Nc,C=>{2>C&&(m.menuPageBkmk=Nc=C,G(g));2==C&&(Jb.wrapBT=!Jb.wrapBT,Jb.dirty=1,oc(),ec());3==C&&(Jb.dblBK=!Jb.dblBK,Jb.dirty=1,ec())});
Ub=g;pc=function(){kc()};
if(qc()){v=rc();if(k=Ca("add&Sep",v))k.title=K("tu"),k.oncontextmenu=C=>{R(C);r(C,z,t,!0)},k.onmousedown=C=>{1==C.button&&(R(C),r(C,z,t,!0))};
if(k=Ca("openInCurrent",v))k.title=K("右键不关闭弹窗"),k.oncontextmenu=C=>{chrome.tabs.update(la.id,{url:z.url},function(M){ec()});
R(C);za()};
if(k=Ca("newFav",v))k.title=K("ag"),k.oncontextmenu=C=>{p("newFav");R(C)};
if(k=Ca("pinTop",v))k.oncontextmenu=C=>{p("pinTop");R(C)}}}}}
function N(g,k,z){g.innerText=k.ni?"⇈":"⇊";g.title=k.ni?K("z5"):K("ks");z&&(z=g.title,z=k.ni?"⇈&emsp;"+z:z+"⇊",Zb(z))}
function ea(g,k){k=k.icon;return g.clientX>k.offsetLeft+k.offsetWidth}
function S(g,k,z,t){var v=g.ver;g=g.salad;k?(Mb(k,"selecting",z),z?g[k.data.id]={pos:k.pos,e:k,ver:v}:delete g[k.data.id]):void 0!=t&&(g[z.id]={pos:t,ver:v})}
function Fa(g){wb=g;g.lst.sel=Bd=g.pos;na=g.id}
function za(g){g||=W;m.navPath=g.lst.tD.path;m.navCtx={idx:g.pos,ni:g.lst.ada.ni};m.navBkmk=g.data.id}
function ta(g,k){if(!sc){var z=f(g);if(z){kc(z);za(z);var t=g.target==z.icon||!Jb.dblBK&&y;if(ea(g,z)||t){var v=z.data,A=v.url;if(A)A.startsWith("javascript:")?Xb(M=>{chrome.tabs.executeScript(M.id,{code:decodeURIComponent(A.slice(11))},function(){!y||g.ctrlKey||k||window.close()})}):t||g.shiftKey||g.ctrlKey?Xb(M=>{t||g.shiftKey?chrome.tabs.update(M.id,{url:v.url},function(){!y||g.ctrlKey||k||window.close()}):g.ctrlKey&&$b(v.url,P=>{P&&0<P.length?chrome.tabs.update(P[0].id,{active:!0}):chrome.tabs.create({url:v.url,
active:!1,index:M.index+1})})}):window.open(A);
else if(v.dateGroupModified){if(!g.ctrlKey){z=0;for(var x;x=T.children[z++];)if(x.d?.path==v.id&&x.type==Pa){var C=x;break}}C?cc(C):(C=m.newTab(Cb,v.id,0,T),C.title=v.title,cc(dc([C],0,ob.nextSibling)));T.dirty()}}}}}
function wa(g,k,z,t){var v=g.data,A=Ib.data,x=Ib.pos-g.pos,C=Ib.lst==g.lst?0:g.lst;if(x||C||void 0!==t){x=g.pos+1;k||x--;pb.onRemove();var M=Ib.lst,P=M.v,L=M.salad;g=Object.keys(L);var H=P.tP.pos,J=g[0].ver,Y=0;k=M.ada.ni;try{g=g.sort(function(ca,bb){if(L[ca].ver!=J)throw Y=1,1;return L[ca].pos-L[bb].pos})}catch(ca){}Y&&(g=M.ada.sort(L,g.length));
k&&g.reverse();x<=H&&(H=0);function oa(ca,bb){function nb(X){ca.nxt++;if(X&&z){var ua=L[X.id],mb=ua.pos;H&&mb<H&&P.tP.pos--;C&&(A.parentId==X.parentId||Nb(M.tD)||delete L[X.id],C.salad[X.id]={id:ua.id})}ca.nxt<ca.length?oa(ca,X?X.index+1:x+ca.nxt):X=0;if(!X&&ob.d.type==Pa){var Oa=ob.d.path;m.pullBkmk(Oa,function(bc){fa(pb.lv,bc,Tb(bc,ob.d,Oa))})}}
var Xa={index:bb,parentId:v.parentId};z?chrome.bookmarks.move(ca[ca.nxt],Xa,nb):chrome.bookmarks.get(ca[ca.nxt],X=>{(X&&=X[0])?(Xa.url=X.url,Xa.title=X.title,chrome.bookmarks.create(Xa,nb)):nb()})}
g.nxt=0;M=C||M;x=t?void 0:M.ada.dPos(x);oa(g,x)}V()}
function Ra(g){if(!sc)if(Sa){if(g.button==ha)if(lc(ob.d)){var k=f(g),z={},t=!g.ctrlKey;k?z=k.getBoundingClientRect():(k=g.target,k=k.classList.contains("ListView")?{pos:k.ada.size,lst:k,data:{parentId:k.tD.path}}:0);k?wa(k,g.clientY>z.y+z.height/2,t):V()}else Zb("请切换到普通的书签文件夹！")}else if(k=f(g))if(g.target==k.icon||!Jb.dblBK&&y&&ea(g,k))ta(g);else{z=k.lst;var v=k.data.id,A=z.salad;g.ctrlKey||h(A);t=ea(g,k);if(g.shiftKey){if(S(z,k,1),wb&&wb.lst==z){v=k;A=k.pos-Bd;var x=0<A,C;0>A&&(A=-A);A++;for(C=A;0<
C;){var M=k.pos+(x?-1:1)*(A-C),P=z.ada.getItem(M);S(z,v,P,M);v&&=z.rowSibling(v,x);C--}}}else t&&!A[v]?S(z,k,1):(S(z,k,0),t||(z.sel=null));!t||wb&&g.shiftKey||Fa(k)}else g.ctrlKey||g.shiftKey||(k=Ka("ListView",g.target))&&h(k.salad)}
function zb(g,k){k=g.button;if(k==ja)if(g.clientX<2*B.body.clientWidth/3){if(k=f(g))g.r=k,Sa||kc(k),g.lv=k.lst,g.sy=g.lv.scrollTop,Aa=g}else Aa=0;else k==ha?Sa||kc():k!=ka||Sa||sc||Cd.md(g)}
function F(g){if(g.button==ja){var k=0,z=Aa;if(!z)return;var t=z.lv,v=z.r;v&&t&&(g.srcElement==z.srcElement&&t.scrollTop==z.sy&&z.clientX==z.clientX&&z.clientY==z.clientY&&ea(z,v)&&(k=1,chrome.tabs.create({url:v.lv.href||"about:blank",active:!1}),sa=t.scrollTop,t.onscroll=D,setTimeout(t.onclick=function(){t.onscroll=0;t.onclick=Ra},300),Date.now(),tc(),za(v)),Aa=0);
k||Sa||kc()}g.button==ka&&Sa&&(t=g.target,pb.contains(t)&&ob.d.type==Pa&&(uc(),V()))}
function D(g){g.srcElement.scrollTop=sa}
function Q(g){if(g.ctrlKey||g.shiftKey||Sa||sc)jc(g);else{var k=g.target.href;"add"==k&&(k="平典搜索");g.dataTransfer.setData("url",k);Ib&&(Ib.classList.remove("sorting"),Ib=0);Sa&&(Sa=0,Ob.hidden=1);if(g=f(g)){k=g.lst;var z=k.salad;z[g.data.id]||h(z);S(k,g,1);Ib=g;Fa(g);kc(g)}}}
function ia(g){if(g=f(g))Ob||(Ab=O(0,0,0,"position:absolute;height:25px;width:50px;background:#2196f3e3;color:#FFF;z-index:9;border-radius:30px;left:10px;text-align:center;z-index:10;pointer-events:none;"),Ob=O(0,0,0,"position:absolute;bottom:0;width:100%;height:39px;background-image:linear-gradient(rgba(0, 0, 0, 0), rgb(90 90 90 / 68%));color:#fff;z-index:9;pointer-events:none;"),O("P",Ob,0,"position:absolute;width:100%;font-size:1em;bottom:0;text-align:center;line-height:0;").innerHTML=K("8")),
Ab.innerText=Object.keys(g.lst.salad).length||1,Ob.hidden=0,Sa=g,g=Ca("tabs"),g.insertBefore(Ob,g.firstChild),g.insertBefore(Ab,g.firstChild),B.body.addEventListener("mousemove",U)}
function V(){Sa&&(Sa=0,Ob.remove(),Ab.remove(),B.body.removeEventListener("mousemove",U),Bb&&(Bb.classList.remove(vc),Bb=0),Ib.classList.remove("sorting"),Ib=0,kc())}
function U(g){if(!Nb(ob.d)){var k=B.elementFromPoint(g.clientX,g.clientY);if(k=f(k)){var z=k.getBoundingClientRect();z=g.clientY>z.y+z.height/2?"drag-below":"drag-above";if(Bb!=k||vc!=z)Bb&&Bb.classList.remove(vc),Bb=k;Bb.classList.add(vc=z)}}Ab.style.left=g.clientX-Ab.offsetWidth/2+"px";Ab.style.top=g.clientY-Ab.offsetHeight+"px"}
function fa(g,k,z){var t=g.tP;g.onmousedown=zb;g.onmouseup=F;var v={size:k.length,ni:t.ni,bifun:d,getItem:function(A){return k[this.ni?k.length-1-A:A]},
sort:function(A,x){for(var C=[],M=0;M<k.length;M++){var P=k[this.ni?k.length-1-M:M],L=A[P.id];if(L&&(L.pos=M,L.ver=g.ver,C.push(P.id),0>=--x))break}return C},
dPos:function(A){return this.ni?k.length-A:A},
rPos:function(A){return this.ni?k.length-1-A:A},
d4sa:function(A,x,C){var M=this.rPos(x.pos),P=k[M];if(P&&P.id==A)return P.pos=M;M=-1;if(!C)for(C=0;P=k[C++];)if(P.id==A)return x.pos=this.dPos(C),this.d4sa(A,x,1);return M}};
g.dVer=z;g.ver=v;g.arr=k;g.ada=v;I.resetLv=()=>{g.reset(v,t.pos||0,t.offset)};
g.reset||m.initListView(g,v,30,"px",I);g.reset(v,t.pos||0,t.offset);wc()}
var sa,Aa,na=-1,wb,Bd,Bb,vc,Sa,Ob,Ab,Nc=m.menuPageBkmk||0,Cd={};xc(Cd,1,1,f,g=>Ka("ListView",g.target,c));
Kb={init:function(g,k){function z(H,J){H=H.target;C.ni=!C.ni;null!=x.sel&&(x.sel=x.arr.length-1-x.sel,C.pos=x.sel);J&&(C.pos=0);C.offset=0;fa(x,x.arr);N(H,C,!0);x.scrollTop+5<x.scrollHeight-x.offsetHeight&&(x.scrollTop-=x.offsetHeight/2)}
var t=O(0,0,"UiTab"),v=O(0,O(0,t,"UiHead"),0,"display:flex;justify-content:space-between;"),A=O(0,t,"UITabo"),x=O(0,A,"ListView"),C=0;C||(A=yc(g),Ya(A,H=>{C=Db[g.id]=H||{};x.tP=C;N(P,C);k()}));
I.lv=x;A=O(0,v,"folder-icon","padding-left:5px;");O(0,A,"item-icon");A.style.opacity="0.5";var M=t.etLoca=O("INPUT",v,0,"width:100%");t.etSch=O("INPUT",v,0,"width:65%;margin-left:3px;");t.etSch.placeholder="consider donation to help development";v=O("DIV",v,"tools");var P=O("BUTTON",v,"btn");P.id="top";P.innerText="⇧";P.title=K("o");P=O("BUTTON",v,"btn");P.id="bottom";P.innerText="⇩";P.title=K("7");P=O("BUTTON",v,"btn star");P.innerText="☆";P.id="add";t.star=P;t.reStar=()=>{(H=>{setTimeout(()=>{H.title=
pa?.parentId==g.path?K("9"):pa?K("vm"):K("n3");y&&pa&&zc==Ac&&Bc(".btn.star{z-index:999}","stst");Ia(H,pa?"★":"☆")},200)})(t.star)};
t.reStar();x.act=H=>{C.pos=C.offset=0;for(var J=x.arr,Y=0;Y<J.length;Y++)if(J[Y].id==H){x.tada=x.ada.ni?J.length-1-Y:Y;C.pos=x.tada-2;break}fa(x,J)};
P.oncontextmenu=H=>{R(H);Wb(J=>{Cc(t,J)});
y&&Dc()};
P=O("BUTTON",v,"btn");P.id="sort";P.oncontextmenu=H=>{R(H);z(H,1)};
C&&N(P,C);v.onclick=function(H){var J=H.target;"sort"==J.id?z(H):"top"==J.id?(C.pos=C.offset=0,fa(x,x.arr)):"bottom"==J.id?(C.pos=C.offset=0,C.pos=x.arr.length-1,fa(x,x.arr)):"add"==J.id&&Wb(Y=>{u(Y||{url:la.url,title:la.title},x,Y?void 0:g.path)})};
M.reload=function(H,J){Tb(null,g);J&&(g.title=J);J=t.taEl;var Y=H.startsWith("q="),oa=Ga("title",J);Ia(oa,g.title||K("o8"));Ja(Ga("tabx",J),Y?"⌕&nbsp;":"★");Y||chrome.bookmarks.get(H,function(ca){ca&&ca.length&&(oa.innerText=ca[0].title)});
g.path=H;m.pullBkmk(H,function(ca){fa(t.lv,ca,Tb(ca,g,H))})};
M.onkeydown=function(H){if("Enter"==H.key){var J=M.value+"";if(J.startsWith("recent"))g.path=J,Tb(null,g),m.pullBkmk(J,function(oa){fa(t.lv,oa,Tb(oa,g,J))});
else if(H=null,H=J.startsWith("chrome://bookmarks/?id=")?parseInt(J.slice(J.indexOf("=")+1)):isNaN(J)?J.startsWith("chrome://bookmarks/?q=")||J.startsWith("q=")?decodeURIComponent(J.slice(J.indexOf("q="))):"q="+J:parseInt(J),null!==H){var Y=H+"";Y.startsWith("q=")?M.reload(Y,K("sk")+Y.slice(2)):chrome.bookmarks.get(Y,function(oa){oa&&oa.length&&M.reload(Y,oa[0].title)})}T.dirty()}};
t.lv=x;t.tD=g;t.tP=C;x.tabIndex=0;x.v=t;x.ver=0;x.tD=g;x.onclick=Ra;x.drop=wa;x.salad=[];I.listView=x;var L;t.onRemove=function(H){try{var J=x.fvp();J&&(C.pos=J.pos,C.offset=x.scrollTop-x.rowOffset(J),cb(yc(g),C));L=0}catch(Y){va(Y)}xa=0};
x.blue=function(){L&&clearTimeout(L);L=setTimeout(t.onRemove,350)};
t.onAttach=function(){t.lv.focus();t.onResume();xa=t.mu};
t.onResume=function(){var H=g.path,J=hb[H];J&&(!J.data&&J.stl||J.ver!=t.lv.dVer)&&m.pullBkmk(H,function(Y){fa(t.lv,Y,Tb(Y,g,H))})};
C&&k();t.mu=F;return t},
bind:fa}}();
var c=Kb.init(a,()=>{m.pullBkmk(b,function(d){if(d){var f=Tb(d,a,b);m.initListView?Kb.bind(c.lv,d,f):m.loadListView(function(){Kb.bind(c.lv,d,a,f)})}else chrome.bookmarks.search(a.title,h=>{h&&(h=h[0],a.path=h.id+"");
m.pullBkmk(a.path,function(n){var l=Tb(n,a,b);m.initListView?Kb.bind(c.lv,n,l):m.loadListView(function(){Kb.bind(c.lv,n,a,l)})})})})});
c.etLoca.value=Na(a);return c}
function Tb(a,b,c){c||(c=b.path);var d=hb[c];if(!d){if(!a)return;d=hb[c]={s:[],ver:0}}var f=d.s.indexOf(b),h=0<=f;h&&d.s.splice(f,1);if(a){if(d.s.push(b),d.data=a,d.stl=0,!h&&ub){a=[];var n=hb,l;for(l in n)if(c=n[l],c=c.s){f=!0;h=0;for(var p;f&&(p=c[h++]);)if(p.id!=b.id){var r=ub[p.id];void 0!=r&&8>=r&&(f=!1)}else f=!1;f&&a.push(l)}a.forEach(function(w){delete n[w]})}}else 0==d.s.length&&delete hb[c];
return d.ver}
function Ec(a,b){return((c,d)=>{function f(F){for(var D,Q=0,ia;ia=q.grid(1).el.children[Q++];)if(ia.data.url===F){D=!0;break}return D}
function h(F,D,Q){var ia=q.grid().el,V=Q.ctrlKey;-1==D?(D=la,Q=D.pendingUrl||D.url,!D||!V&&f(Q)||(q.layout([{url:Q,title:D.title,favIconUrl:D.favIconUrl,tabId:D.id}],0,ia,F),E=G.v)):-2!=D&&-3!=D||chrome.tabs.query(-2==D?{currentWindow:!0}:{},function(U){for(var fa=[],sa,Aa=0,na;na=U[Aa++];)sa=na.pendingUrl||na.url,!V&&f(sa)||fa.push({url:sa,title:na.title,favIconUrl:na.favIconUrl,tabId:na.id});fa.length&&(q.layout(fa,0,ia,F),E=G.v)});
q.dirty()}
function n(F){return F.session?(D=>function(Q){chrome.tabs.executeScript(Q.id,{code:`var ret=${D.session};
                            for (var key in ret) {
                                sessionStorage.setItem(key, ret[key]);
                            }
                            document.documentElement.scrollTop=ret.scrollTop`},function(ia){})})(F):void 0}
function l(F,D){return 1.25>Math.abs(F-D)}
function p(F,D){chrome.tabs.update(D.id,{active:!0},function(){});
F.tabId=D.id;eb.favTabs[D.id]=F;Fc(D.windowId)}
function r(F,D,Q){m.navPath=d;m.navCtx={idx:G.data.indexOf(F),tmp:S.tmp,same:S.same};m.navBkmk=0;if(d.startsWith("imp_tmp")){!S.tmp||D||zb&&y||(Gc()&&q.pref("del"),zb=1);var ia=F.url;S.same?chrome.tabs.update(la.id,{url:ia},n(F)):Xb(V=>{chrome.tabs.create({url:ia,active:!0,index:V.index+1},n(F))});
y&&window.close()}else chrome.tabs.update(F.tabId||0,{active:!0},function(V){V?(Fc(V.windowId),eb.favTabs[V.id]||(eb.favTabs[V.id]=F)):chrome.tabs.query({url:F.url},function(U){(U=U&&U[0])?p(F,U):(U=F.url.lastIndexOf("#"),0<U&&chrome.tabs.query({url:F.url.slice(0,U)},function(fa){fa&&(fa=fa&&fa[0])&&p(F,fa)}))})})}
function w(){setTimeout(()=>q.onAttach(),100)}
d=d||"imp_";var q=O(0,0,"UiTab");q.id=c.id;var u=0,E=0;q.dirty=function(){u=(G.v||0)+1};
q.f1=function(){};
q.onload=function(F){var D=eb.favPlus;D||(D=eb.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`,fixed:1,dyn:1});F.f0=q.layout([D],0,F,0);F.bin=q.bin;F.dirty=q.dirty};
q.onResume=function(){E<G.v&&(E=G.v,q.load())};
var G,N=d,ea,S,Fa;q.load=function(){$a(Fa=c.path.includes("tmp")?"opt_imp":"opt_tmp",F=>{S=F||{};void 0==S.tmp&&(S.tmp=c.path.includes("tmp"));void 0==S.same&&(S.same=c.path.includes("tmp"));Hc(yc(c),D=>{ea=D||{};m.pullImpt(N,Q=>{hb[N]=G=Q;q.impd=Q;u=Q.v||0;q.layout(Q.data);E=G.v;setTimeout(()=>{q.grid(1).el.parentElement.scrollTop=ea.top},10);
setTimeout(()=>{q.grid(1).el.parentElement.scrollTop=ea.top},100);
wc()})})})};
q.save=function(){var F=parseInt(q.grid(1).el.parentElement.scrollTop),D=ea.top!=F&&q.grid(1).el.children.length;ea.top=F;if(u>(G.v||0)){G.v=u;F=[];for(D=q.grid(1).el.firstElementChild;D;){var Q=D.data;Q&&!Q.dyn&&F.push(Q);D=D.nextElementSibling}G.data=F;m.log("saving::",N,F);m.saveImportabs(N,G);Ic(yc(c),ea);E=G.v}else D&&Ic(yc(c),ea);S.changed&&(delete S.changed,cb(Fa,S))};
q.bin=[];q.pref=function(F,D,Q,ia){var V=q.grid();Q=V.el;var U=W,fa=0,sa=U.data,Aa=n(sa);switch(F){case "del":W.classList.contains("selected")&&(fa=Jc(V,U));fa||=Kc(V,U,q.bin,V.el);break;case "delSel":fa=Jc(V,U);break;case "restore":fa=Lc(V,U);break;case "moveSel":fa=Mc(V,U);break;case "selAll":Oc(V);break;case "open":Xb(na=>{chrome.tabs.create({url:sa.url,index:na.index+1,active:!ia.ctrlKey},Aa)});
break;case "&addThis":h(!U||U.fixed?0:U.nextSibling,-1,ia);break;case "addWnd":h(!U||U.fixed?U:U.nextSibling,-2,ia);break;case "addAll":h(!U||U.fixed?U:U.nextSibling,-3,ia);break;case "saveSession":Xb(na=>{chrome.tabs.executeScript(na.id,{code:"var ret={};\n                                for (var i = 0,key; i < sessionStorage.length; i++) {\n                                    ret[key=sessionStorage.key(i)] = sessionStorage.getItem(key);\n                                }\n                                ret.scrollTop = parseInt(document.documentElement.scrollTop);\n                                JSON.stringify(ret)"},
function(wb){sa.session=wb[0];q.dirty()})});
break;case "restoreSession":ia?Aa(la):Ta(sa.session);break;case "uniImp":return Jb.uniImp=!D,1;case "tweak":return Jb.tkImp=D,1;case "topImp":return Jb.topImp=D,Q.f0&&(Q.f0.remove(),Q.f0=q.layout([Q.f0.data],0,Q,D?Q.firstChild:0)),1;case "isTmp":return S.tmp=!!D,S.changed=1;case "isSame":return S.same=!!D,S.changed=1;case "multi":return U&&V.els(U)||(Jb.mtImp=D),1;case "copyUrl":Ta(sa.url);Zb(sa.url);break;case "openInCurrent":Xb(na=>{chrome.tabs.update(na.id,{url:sa.url},function(){Aa&&Aa(na);y&&
void 0!=ia&&window.close()})});
break;case "openInNewTab":$b(sa.url,function(na){na&&0<na.length?(chrome.tabs.update(na[0].id,{active:!0}),Aa&&Aa(na[0])):chrome.tabs.create({url:sa.url},Aa)});
break;case "openInBackgroud":Xb(na=>{chrome.tabs.create({url:sa.url,index:na.index+1,active:!1},Aa)});
break;case "openInIframe":Q=m.newTab(Cb,sa.url,ac,T);Q.title=sa.title;cc(dc([Q],0,ob.nextSibling));T.dirty();break;case "topImp1":F=sa.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`};q.layout([F],0,Q,U.nextElementSibling);break;case "pinTop":fa=Pc(V,U,1);break;case "pinBot":fa=Pc(V,U);break;case "goTop":pb.grid(1).el.parentElement.scrollTop=0;break;case "goBot":pb.grid(1).el.parentElement.scrollTop=pb.grid(1).el.parentElement.scrollHeight}ec();
fa&&q.dirty();return 1};
var za=m.menuPageImp||0;q.oncontextmenu=function(F){for(var D=F.target,Q=D.S;!Q&&D&&!D.classList.contains("item-sqr");)D=D.parentNode;W=D;var ia=D.data;D||(Q=1);Q=q.grid();ia=0==za?["",[0,"open",[K("mt"),ia.url]],,[0,"&addThis",K("zm"),1,,[0,"addWnd",K("td")],[0,"addAll",K("t")]],[0,Qc(ia.url,la.url)||F.altKey?"saveSession":0,K("5e"),1,[0,ia.session?"restoreSession":0,K("t3")]],[0,"topImp1",K("w")],[0,"pinTop",K("2t")],[0,"pinBot",K("cy")],[0,"del",K("lv"),q.bin.length,[0,"restore",K("l")]],[0,
"multi",K("2w"),Jb.mtImp||Q.els(D),[0,"moveSel",K("cp")],[0,"delSel",K("ls")],[0,"selAll",K("bd")]],[1,c.path.includes("tmp")?"isTmp":0,K("m"),S.tmp],[1,c.path.includes("tmp")?"isSame":0,K("ol"),S.same]]:["",[0,"openInCurrent",K("ol")],[0,"openInNewTab",K("mt")],[0,"openInBackgroud",K("jb")],[0,"openInIframe",K("ln")],[0,"goTop",K("o")],[0,"goBot",K("7")],[0,"copyUrl",K("qs")]];nc(ia,q.pref,F,D,q.oncontextmenu,[K("p4"),K("g")],za,V=>{2>V&&(m.menuPageImp=za=V,q.oncontextmenu(F))});
Ub=F;if(qc()){D=rc();if(Rc=Ca("open",D))Rc.oncontextmenu=V=>{R(V);q.pref("openInCurrent")};
Rc=Ca("add&Sep",D);if(Rc=Ca("openInCurrent",D))Rc.title=K("wj"),Rc.oncontextmenu=V=>{R(V);q.pref(Rc.id)};
if(Rc=Ca("restoreSession",D))Rc.title=K("n"),Rc.oncontextmenu=V=>{R(V);q.pref(Rc.id)}}};
var ta,wa,Ra;La("mousedown",function(F){ta=F.clientX;wa=F.clientY;Ra=q.grid(1).el.parentNode.scrollTop},1,q);
var zb;La("mouseup",function(F){if(l(ta,F.clientX)&&l(wa,F.clientY)&&l(Ra,q.grid(1).el.parentNode.scrollTop)){for(var D=F.target,Q=D.S;!Q&&D&&!D.classList.contains("item-sqr");)D=D.parentNode;var ia=D.data;if(F.button==ja){var V=n(ia);Xb(U=>{chrome.tabs.create({url:ia.url,active:!1,index:U.index+1},V);!S.tmp||F.ctrlKey||zb&&y||(W=D,Gc()&&q.pref("del"),zb=1)});
tc()}}},1,q);
q.dblclick=function(F,D){F=D.data;"add"!=F.url&&chrome.tabs.create({active:!0,url:F.url,index:la.index+1},function(Q){})};
q.click=function(F,D){var Q=D.data;if("add"==Q.url)h(D,-1,D);else{for(F=F.target;F&&!F.classList.contains("item-sqr");)F=F.parentNode;W=F;r(Q)}};
I.initGridTab?(initGridTab(I,B,q),w()):gc("gridtab.js",function(){m.initSortable&&!Qb?(m.initSortable(B,I),initGridTab(I,B,q),w()):m.loadSortable(function(){m.initSortable(B,I);initGridTab(I,B,q);w()})});
return q})(a,b)}
function Sc(a,b){var c=a.firstChild;if(c)return c;for(;a&&a!=b;){if(c=a.nextSibling)return c;a=a.parentNode}}
function Tc(a){a=a.path;a.startsWith("sch:")&&(a=a.slice(4));return a}
function Uc(a,b,c,d,f){m.putSchKey(b);if(!d||b)a?(b=a.replace("%s",b),c?chrome.tabs.update(la.id,{url:b}):chrome.tabs.create({url:b,active:!f})):chrome.search.query({text:b,disposition:"NEW_TAB"}),y&&!f?window.close():Vc()}
var Wc;function Xc(a,b){function c(){p=Tc(a);h.schEng.innerText=p||K("e")}
function d(w,q){w=w.value.trim()||h["1"].value.trim()||h["2"].value.trim();w!=l.key&&(l.key=w,r&&cb(f,l));Uc(p,w,q)}
b=O(0,0,"UiTab");b.innerHTML='\n        <div class="UiHead">\n        \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div id="pasteIt" style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;" title="获取手机上的剪贴板数据，\n 当安卓无限词典处于前台无需复制只需选择，\n 当处于后台需要打开悬浮按钮。\n点击此处粘贴至浏览器内部的输入框">\n\t\t\t\t\t新的搜索&ensp;\n\t\t\t\t</div>\n                <textarea id=\'1\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="11" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="12" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n            \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;">当前页搜索&ensp;</div>\n                <textarea id=\'2\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="21" title="搜索">\ud83d\udd0d</button>\n                    <button class="btn" id="22" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="23" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n\t\t\t\n            <div class="divider">\n\t\t\t    <HR style=\'margin:15px;opacity:.8;\'>\n                <span class="dividerTitle" id="dt"></span>\n            </div>\n\t\t\t\n            <div style="height:18px;display:flex;flex-direction: row;position:fixed; bottom:0; width:100%; user-select:none; cursor: pointer;">\n                <div id="schEng" class="tools" style="height:30px;width: 100%;font-size:10px;padding-left:5px;color:#888">\n                    默认搜索引擎\n                </div>\n            </div>\n            \n        </div>\n        <div class="UITabo">\n            <div class="ListView" id="key"></div>\n        </div>';
for(var f="v_"+rb.id+"_"+a.id,h={},n=b,l={};n=Sc(n,b);)n.id&&(h[n.id]=n);var p;c();var r;b.et=h["1"];b.et1=h["2"];Ia(h.dt,a.title);O("SPAN",0,"tabx").innerText="";n=O(0,0,"item-icon");O(0,n,"img web").style.backgroundImage=Yc(a.path.slice(4));n.style="display: inline-block;transform: translateY(4px);";h.dt.insertBefore(n,h.dt.firstChild);h["11"].onclick=function(){d(h["1"])};
h["21"].onclick=function(){d(h["2"],!0)};
h["22"].onclick=function(){d(h["2"])};
h.schEng.onclick=function(){var w=prompt("输入搜索引擎地址，用%s代替关键词：",p);void 0!=w&&w!=p&&(a.path="sch:"+w,c(),T.dirty())};
La("keydown",function(w){"Enter"!==w.key||w.shiftKey||(R(w),d(w.target))},0,h["1"]);
La("keydown",function(w){"Enter"!==w.key||w.shiftKey||(R(w),d(w.target,!w.ctrlKey))},0,h["2"]);
La("input",function(w){Zc=h["1"].value},0,h["1"]);
La("input",function(w){$c=h["2"].value},0,h["2"]);
b.onAttach=function(){Fb==ad&&setTimeout(()=>{h.schEng.click()},250);
Wc||(Wc=O(0,0,"sch-pane"),Vc());h.key.append(Wc);bd(w=>{h["2"].value=w})};
b.onRemove=function(){};
Va(f,w=>{(w=w[f])&&r&&(l=w,h["1"].value=w.key||"");Hb&&(h["1"].focus(),h["1"].select());h["1"].value=Zc||"";bd(q=>{h["2"].value=q})});
return b}
function cd(a,b){a=O(0,0,"UiTab");var c=O("IFRAME",a);b.includes(":")||(b="https://"+b);c.src=b;c.style.width="100%";c.style.height="100%";return a}
function dd(a,b){return((c,d)=>{function f(){return p}
function h(q){q=q.src;l.shadow.innerHTML=q;n.s=l.shadow;var u=q.indexOf("<script>");0<=u&&(u=q.slice(u+8,q.lastIndexOf("</script>")),eval("(()=>{"+u.replace("_bg()",f.name+"()")+"})()"))}
var n=O(0,0,"UiTab disp0"),l=O(0,n);l.src=d;l.style.width="100%";l.style.height="100%";l.shadow||(l.shadow=l.attachShadow?l.attachShadow({mode:"open"}):O(0,l));n.d=c;var p,r=yc(c),w=ed(c);n.k=r;n.k1=w;n.tmps=m.d();n.toast=Zb;n.isPopup=y;n.dataToClipboard=Ta;n.onRemove=()=>{if(p.view.onSave)p.view.onSave();if(p.changed){var q={};Object.assign(q,p);delete p.changed;delete q.changed;delete q.view;delete q.src;cb(p.view.k,q)}};
n.reload=q=>{h(q)};
Va([r,w],q=>{n._bg=p=q[r]||{};p.view=n;p.src=q[w];p.getSelection=fd;delete p.changed;if(p.src)h(p);else if("百度高级搜索"==c.title||"baiduadv"==c.path){var u=new XMLHttpRequest;u.open("GET","assets/百度高级搜索.html",!!p);u.onreadystatechange=function(E){4===u.readyState&&200===u.status&&(p.src=u.responseText,h(p))};
u.send()}});
return n})(a,b)}
function Ta(a){function b(c){document.removeEventListener("copy",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("copy",b,!0);document.execCommand("copy")}
function gd(a){function b(c){document.removeEventListener("paste",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("paste",b,!0);document.execCommand("paste")}
function gc(a,b,c){c?b():(c=document.createElement("script"),c.type="text/javascript",c.onload=b,c.src=a,document.body.appendChild(c))}
var hd;function id(a){m.initSortable(B,I);hd=new Sortable(T,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabH",root:!0,forceFallback:!1,sort:!0,onMove(b){var c=300;1.5<Math.abs(T.dragScroll-T.scrollTop)&&(c=0,T.dragScroll=T.scrollTop);this.options.animation=c;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){hd.did(b)&&T.dirty();this.options.animation=300},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;I.disani=0;T.dragScroll=T.scrollTop},click(b){},trace:function(){console.log("trace"+Error().stack)}});
a&&(hd._onTapStart(a),a.constructor==DragEvent?hd._onDragStart(a):hd._onDrop(a),jd(a,1))}
var Qb=1;function jd(a,b){hd?a&&(b?T.lazyS=a.target.ondragstart=void 0:jd(a,1)):m.initSortable&&!Qb?id(a):m.loadSortable(function(){id(a)})}
kd();document.ondblclick=function(a){var b=a.target;b==T?hd&&hd.multiDrag._deselectMultiDrag(0,1):pb&&pb.contains(b)&&pb.dblclick&&pb.dblclick(a,b)};
var ld={};
function md(a){var b=a.key;if(!ld[b]){ld[b]=1;var c=a.target;"gridview"==c.id&&(c=c.parentElement.parentElement);c.grido&&(c=c.grido());if(c.S){var d=0;a.ctrlKey?"a"==b?(Oc(c.S),d=1):"z"==b&&(Lc(c.S),d=1):"Delete"==b&&(Jc(c.S,0),d=1);if(d){c.dirty();R(a);return}}if(Z){var f=0;if("Escape"==b)f=1;else if(1==a.key.length)for(b=Z.cards[0],c="&"+a.key.toLowerCase();b=Sc(b);)if(b.id&&b.id.toLowerCase().includes(c)){f=b;break}f&&(b=Z,ec(),R(a),Z=b,1!=f&&f.click())}else{c=" "==b&&a.ctrlKey;if(!(nd()&&!c||
zc||" "!=b&&(a.ctrlKey||a.shiftKey))){" "==b&&R(a);d=B.activeElement;var h=a.keyCode;(d?.ada||d==B.body)&&(65<=h&&90>=h||48<=h&&57>=h||"A"<=h&&"Z">=h||"a"<=h&&"z">=h)?f=1:" "==b&&(f=1)}if(f)if(R(a),f=" "!=b,Dc(1,0,f),f)etSearch.value=b,etSearch.dispatchEvent(new Event("input",{bubbles:!0}));else if((a=m.schTabKey)&&etSearch.value!=a||od)etSearch.value=a,etSearch.dispatchEvent(new Event("input",{bubbles:!0}));c&&R(a)}}}
function pd(a){ld[a.key]=0;if("d"==a.key&&a.altKey||"Enter"==a.key&&a.altKey)m.toggleDark(),qd(),R(a,1);"Alt"==a.key&&R(a,1)}
La("keydown",md,1,B);La("keyup",pd,1,B);var rd,sd;function td(a){m.initTabs(function(b,c,d){var f=!rd;Cb={};if(0==b.length){var h=0;function G(N,ea,S){void 0===S&&(S=ad);var Fa="v"==N;Fa&&(h+=100,N="");N=m.newTab(Cb,N,S,0,ea,924+h+b.length+1);Fa&&(N.br=1);b.push(N)}
if(c.name==K("tt")||2==c.t0){var n=new XMLHttpRequest;n.open("GET","assets/default_sch_engines.js",!1);n.onreadystatechange=function(N){4===n.readyState&&200===n.status&&eval(n.responseText.replaceAll("doit",G.name))};
n.send();c.t0=2}else if(c.name==K("lt")||3==c.t0)G("recent",0,Pa),G("",0,ud),G("",K("e"),ad),G("imp_tmp",K("4u"),Qa);else if("tabs1"==c.id||1==c.t0)G("0",0,Pa),G("1",0,Pa),G("2",0,Pa),G("recent",0,Pa)}if(c.type==vd&&d.bar){for(var l=[],p={},r=b.length-1;0<=r;r--){var w=b[r];w.pos=r;w.auto&&w.type==Pa&&(b.splice(r,1),p[w.path]=w);Cb[w.id]=w}function G(N){if(void 0!=N.dateGroupModified){N=N.id;var ea=p[N];ea?(delete p[N],delete Cb[N]):(ea=m.newTab(Cb,N,Pa,0,0,N),ea.auto=1);l.push(ea)}}
G({dateGroupModified:1,id:"1",title:K("rw")});for(r=0;r<d.bar.length;r++)G(d.bar[r]);for(r=0;r<b.length;r++)l.splice(b[r].pos||0,0,b[r]);b=l;for(var q in p)r=p[q],delete Cb[q],db(yc(r,c)),r.type==ud&&db(yc(r,c)+"_")}sb=0;tb=void 0===d.scroll?null:parseInt(d.scroll)||0;rb=c;ub=d.hots||{};vb=Jb.expTab=d.exp;xb=d.one;yb=d.rec;void 0===yb&&(yb=0);jb.innerText="";ob=pb=gb=0;qb=[];Db=c.tPs||{};var u=f?T:T.cloneNode();c=T;aa=vb?6:3;y&&(aa=vb?6:4);rd=Math.ceil(sd*aa);u.style.maxHeight=rd+"px";wd(u);u.bin=
xd;var E=0;u.dirty=function(){E=eb.tabsVer+1};
u.save=function(){if(E>eb.tabsVer){eb.tabsVer=E;fb.length=0;for(var G=u.firstElementChild;G;){var N=G.d;N&&fb.push(N);G=G.nextElementSibling}fb.now=gb.id;m.saveTabs(rb,fb,()=>{})}G=parseInt(xb?T.scrollLeft:T.scrollTop);
if(rb&&ub&&(sb||G!=tb&&y&&(yb||void 0!=tb))){N="v_"+rb.id+"__";sb=0;tb=yb?G:G=void 0;var ea=fb.indexOf(ob.d)||0;0>ea&&(ea=0);Ic(N,{tix:ea,hots:ub,scroll:G,exp:vb,rec:yb,one:xb})}};
fb=b;gb=0;d=dc(fb,d.tix,0,u);gb||(gb=b[0],d=u.firstElementChild,d==kb&&(d=d.nextElementSibling));u.append(kb);u.style.minHeight="";u.ada={};f||(yd.observe(u),u.style.position="absolute",u.style.visibility="hidden",lb.insertBefore(u,T),T=u,zd(),yd.unobserve(c));cc(d,1);kb.fixed=1;u.oncontextmenu=Ad;T.onclick||(hd=0,kd());Dd.dirty||Ed();f?setTimeout(()=>{sd=Math.max(kb.offsetHeight,T.firstElementChild.offsetHeight);rd=Math.ceil(sd*aa);u.style.maxHeight=rd+"px";u.MH=rd;zd();Fd()},1):Fd();
f||(u.style.position="",u.style.visibility="",c.remove())},y?0:window,a)}
td();function Gd(a){var b=Object.create(Object.getPrototypeOf(a));Object.getOwnPropertyNames(a).forEach(function(c){var d=Object.getOwnPropertyDescriptor(a,c);Object.defineProperty(b,c,d)});
return b}
function dc(a,b,c,d){var f=d||T;d||(c||=kb);for(var h=0,n=0;n<a.length;n++){var l=a[n];if(isNaN(l.type)||0>l.type)continue;d&&(a[n]=l=Gd(l));var p=l.type,r=l.title,w=l.ico;r||(p==Pa&&(r=l.path?.startsWith("recent")?K("jh"):K("o8")),p==Qa&&(r=l.path?.includes("tmp")?K("4u"):K("9m")),p==Hd&&(r="无限词典"),p==ud&&(r=K("ry")));w||(p==Pa&&(w=l.path.startsWith("q=")?"⌕&nbsp;":"★"),l.type==ac&&(w="\ud83c\udf10"),l.type==ad&&(w="\ud83c\udf10"));p=O("LI",0,"tab");l.type==Id&&(p.classList.add("tab-sep"),
l.path&&(p.style=l.path));if(w){var q=O("SPAN",p,"tabx");(1<w.length?Ja:Ia)(q,w)}l.type==ad&&l.path&&(q.innerText="",p.con=O(0,p,"item-icon"),p.icon=O(0,p.con,"img web"),p.icon.style.backgroundImage=Yc(l.path.slice(4)));let u=O("SPAN",p,"tabx title");(l.type==Id?Ja:Ia)(u,r);l.type!=Pa||Nb(l)||chrome.bookmarks.get(l.path,function(E){E&&E.length&&(u.innerText=E[0].title)});
l.type==Qa&&(p.title=l.path);p.ondblclick=Jd;p.oncontextmenu=Ad;p.id="tab_"+l.id;Cb[l.id]=l;hd||(p.draggable=!0,p.ondragstart=jd);p.d=l;d&&ub&&(r=1/(da+1),w=ub[l.id],void 0!=w&&(p.classList.add("tab-hot"),p.style.setProperty("--bg",Kd(132,175,255,255,255,255,999==w?.85:r*w)),p.lev1=w,999!=w&&qb.push(p)));c&&c.parentNode==f?f.insertBefore(p,c):f.append(p);l.type==Id&&l.br&&(r=O("div",0,"flex-break"),f.insertBefore(r,p),r.fixed=p.fixed=1,r.fix=p.fix=1,p.br=r);h||(void 0!=b?n==b&&(gb=l,h=p):h=p)}d&&
(qb.sort(function(u,E){return-u.lev1+E.lev1}),Ld());
return h}
const zd=a=>{a=T.scrollHeight>rd;var b=T.style;!a^"visible"==b.overflowY&&(b.overflowY=a?"scroll":"visible",b.minHeight&&(b.minHeight=""))},yd=new ResizeObserver(zd);
yd.observe(T);var xd=[];function Md(a){if(a.shiftKey||a.altKey||a.ctrlKey)T.lazyS&&T.lazyS(a);else{var b=Ka("tab",a.target,T);b?(cc(b),sb=1,clearTimeout(T.saving),T.saving=setTimeout(Nd,800)):hd&&a.target==T&&hd.multiDrag._deselectMultiDrag(0,1)}}
kb.onclick=function(a){W=0;Od(a)};
function Jd(a){if(!a.ctrlKey&&!a.shiftKey){for(a=a.srcElement;a&&!a.classList.contains("tab");)a=a.parentNode;vb=!vb;Pd(a)}}
function Qd(a){return a&&a.parentNode==T&&a!=kb}
function Pd(a){aa=vb?6:3;y&&(aa=vb?6:4);T.MH=rd=Math.ceil(sd*aa);T.style.maxHeight=rd+"px";zd()}
function Rd(a){if(Qd(a)){var b={};Object.assign(b,a.d);var c=a.cloneNode(1);c.onclick=Md;c.ondblclick=Jd;c.oncontextmenu=Ad;b.id=m.newTabid(Cb,T.children.length);hd||(c.draggable=!0,c.ondragstart=jd);c.d=b;T.insertBefore(c,a.nextSibling);cc(c)}}
function Kc(a,b,c,d){if(!b.fixed||b.fix){d=c?{e:b,idx:[].indexOf.call(d.children,b)}:{};var f=a?a.els().indexOf(b):-1;~f&&(a.els().splice(f,1),d.sel=1);b.remove();c&&c.push(d);return!0}}
function Jc(a,b,c){if(a&&(b=a.els(),b.length)){a.el.bin.push({es:b.concat(),idx:[].indexOf.call(a.el.children,b[0])});a=0;for(var d;d=b[a++];)if(d.remove(),d.br&&d.br.remove(),c)try{c(d)}catch(f){va(f)}b.length=0;return!0}}
function Pc(a,b,c){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var d=a.els();d.length||(d=[b]);if(d.length){b=0;for(var f;f=d[b++];)f.remove();for(b=0;f=d[b++];)c?a.el.insertBefore(f,a.el.firstElementChild):a.el.append(f);return!0}}}
function Mc(a,b){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var c=a.els();if(c.length&&-1==c.indexOf(b)){for(var d=0,f;f=c[d++];)f.remove();b=b.nextElementSibling;for(d=0;f=c[d++];)a.el.insertBefore(f,b),b=f.nextElementSibling;return!0}}}
function Lc(a,b){if(a){var c=a.el.bin.pop();if(c){var d=a.el,f=d.children[c.idx||0];if(b=c.e)d.insertBefore(b,f),c.sel&&a&&a.els().push(b);else{b=c.es;c=0;for(var h;h=b[c++];)d.insertBefore(h,f),a&&a.els().push(h);b=b[0]}return b}}}
function Oc(a){if(a){var b=a.els(),c=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||(b.push(d),d.classList.add("selected"))}}
function Sd(a){if(a){var b=a.els(),c=b.length=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||d.classList.remove("selected")}}
function nc(a,b,c,d,f,h,n,l){W=d;qc()?(Z=Td(0,a,b),Ud(c),h?setTimeout(()=>Vd(h,n,l),5):Wd&&Wd.remove()):gc("settings.js",function(){initSettings(I,B,"settings.css");
qc()&&f(c)});
jc(c)}
function Vb(){gb?.type==Pa&&Wb(()=>pb.reStar())}
function Xd(a,b){var c=a.d.path,d=function(n){Sb(a);if(a.d==gb&&pb&&pb.onResume)pb.onResume();Vb()};
if(Ib){var f=Ib.lst,h=b?.shiftKey;a={pos:h?0:void 0,lst:a.tabView?.lv,data:{parentId:c}};f.drop(a,!h,!b||!b.ctrlKey,!h)}else Wb(n=>{!n||b.ctrlKey?chrome.bookmarks.create({parentId:c,url:la.url,title:la.title,index:b.shiftKey?0:void 0},d):n.parentId!=c?chrome.bookmarks.move(n.id,{parentId:c,index:b.shiftKey?0:void 0},d):Zb("已经添加到该文件夹！<br>"+K("s4"))})}
function Yb(a,b){chrome.bookmarks.get(b.path,function(c){if(c=c?c[0]:0)ec(),Cc(a.tabView,c)})}
function Cc(a,b){if(b){if(b.parentId==a?.lv.tD.path)a.lv.act(b.id);else{for(var c,d=0,f;f=T.children[d++];)if(f.d?.path==b.parentId&&f.type==Pa){c=f;break}c?cc(c):(c=m.newTab(Cb,b.parentId,Pa,T),cc(dc([c],0,a.taEl.nextSibling)));sb=1;c&&(T.dirty(),setTimeout(()=>{pb.lv&&pb.lv.act(b.id)},500))}xb&&Fd(1)}}
function Od(a){var b=W,c=["",[0,["tabFav",0],[K("3")],1,,[0,"tabRec",K("jh"),1]],[0,["tabImp",0],[K("9m")],1,,[0,"tabTmp",K("4u"),1]],[0,"tabSch",K("e1"),1],[0,"tabWeb",K("ln"),1],[0,["tabCustomX",0],[K("j")],1,,[0,"tabBaidu",K("百度高级搜索"),1],[0,"tabCustom",K("ry"),1]]];nc(c,Yd,a,b,Od);if(qc()){a=rc();if(b=Ca("tabImp",a))b.title=K("右击保存到新的位置"),b.oncontextmenu=d=>{Yd("tabImp");R(d)};
if(b=Ca("tabTmp",a))b.title=K("右击保存到新的位置"),b.oncontextmenu=d=>{Yd("tabTmp");R(d)}}}
function Ad(a){hd||jd(a);if(window.oncontextmenu==jc)jc(a);else{for(var b=a.target,c=b==T;!c&&b&&!b.classList.contains("tab");)b=b.parentNode;c||kc(b);if(b==kb)b.onclick(a);else{c=b.d.type==Pa;var d=lc(b.d),f=b.d.type==ad,h=b.d.type==Qa,n=b.d.type==ac;c=["",[0,d?["&addFav",0]:0,[K("n3")],1,,[0,d?["newFavFolder",0]:0,[K("q")],1],[0,d?["openLocatedFoler",0]:0,[K("c")],1]],[0,f?["schNew",0]:0,K("6y"),1,[0,f?["schThis",0]:0,K("m2"),1]],[0,n||f||c?["openWeb",0]:0,K("mt"),1],[0,b.d.type==ud?["&editSrc",
0]:0,K("f1"),1],[0,h?["setTemp",0]:0,[K("d6")],1],[0,b.d.type==Id?["brSep",0]:0,[K("切换换行")],1],[0,["copyUrl",0],[K("c8")],1],[0,["&newTab",0],[K("mc")],1,,[0,["dupTab",0],[K("u")]],[0,["newSep",0],[K("f")]]],[0,["&closeTab",0],[K("5q")],xd.length,[0,["resumeTab",0],[K("p")]]],[0,["multiTab",0],[K("yy")],Jb.mt||hd&&hd.els(b),[0,["exportTabs",0],[K("导出")]],[0,["importTabs",0],[K("导入")]],[0,["moveTabs",0],[K("4")]],[0,["selTabs",0],[K("bd")]]],[1,"oneRow",[K("单行标签栏")],xb],[1,"expTab",[K("iu")],
vb],[1,y?"recPos":0,[K("3t")],yb]];d=0;xb||(d=vb?2:1);nc(c,Yd,a,b,Ad,[K("单行"),K("折叠"),K("展开")],d,l=>{0==l?xb=!0:(vb=2==l,xb=!1);sb=1;wd(T);0!=l&&Pd(W);setTimeout(()=>Fd(1),10);
ec()});
if(qc()){Z.e=a;a=rc();if(b=Ca("selTabs",a))b.title=K("a"),b.oncontextmenu=l=>{Sd(hd);R(l);ec()};
if(b=Ca("copyUrl",a))b.title=K("ke"),b.oncontextmenu=l=>{R(l);Zd()},b.onmousedown=l=>{1==l.button&&(R(l),$d())};
if(b=Ca("&addFav",a))b.title=K("s4");if(b=Ca("addImp",a))b.title=K("s4");if(b=Ca("schNew",a))b.oncontextmenu=l=>{Yd("schNew");R(l)};
if(b=Ca("schThis",a))b.oncontextmenu=l=>{Yd("schThis");R(l)};
if(b=Ca("newSep",a))b.title=K("右击换行"),b.oncontextmenu=l=>{Yd("newSep");R(l)}}}}}
function $d(){var a=W,b=a.d;if(lc(b))chrome.bookmarks.get(b.path,function(f){if(f=f?f[0]:0)ec(),gc("assets/dialog.js",function(){var h=showDialog(B,B.body);Ia(h.t,"Edit");Ja(h.t1,hc("NAME"));Ia(h.btn0,"Save");var n=Ea("TEXTAREA",h.t1);n[0].value=f.title;h.btn0.onclick=()=>{var l=n[0].value;chrome.bookmarks.update(b.path,{title:l},p=>{p&&(Ia(Ga("tabx title",a),l),h.x())})};
h.btn1.onclick=()=>{h.x()}},I.showDialog)});
else{var c=W.d.title,d=prompt("标题：",c);d!=c&&void 0!=d&&(ec(),T.dirty(),(b.type==Id?Ja:Ia)(Ga("tabx title",a),b.title=d),Sb(a))}}
function Zd(){var a=W,b=a.d,c=Na(W.d),d=prompt("请输入新地址（可以是书签url或者http网址）",c),f="v_"+rb.id+"_"+b.id,h=d!=c;if(d){ec();function l(p,r){Ua.remove(f);var w=b.id;Object.keys(b).forEach(function(q){delete b[q]});
b.id=w;b.type=n;b.title=p;n==Qa&&(d.startsWith("important://")&&(d=d.slice(12)),d.startsWith("imp_")||(d="imp_"+d));b.path=d;h&&T.dirty();p=a.nextElementSibling;Kc(hd,a,0,T);dc([b],0,p);a==ob&&cc(a);Sb(a,r)}
if(d.startsWith("chrome://bookmarks")||!isNaN(d)){var n=Pa;l(e[0].title,350)}else d.startsWith("imp")?(n=Qa,c=b.type==n?b.title:0,b.path.includes("tmp")!=d.includes("tmp")&&(c=0),l(c)):d.startsWith("custom")?(n=ud,c=b.type==n?b.title:0,l(c||K("ry"))):d.startsWith("sch:")?(n=ad,l(ae(d,!0)||K("e1"))):(n=ac,l(ae(d,!0)))}}
function ae(a,b){var c=a,d=c.indexOf(":");for(0<=d&&(c=c.slice(d+1));c.startsWith("/");)c=c.slice(1);d=c.indexOf(".");if(0<d){if(a=c.slice(0,d),"www"==a){var f=c.indexOf(".",d+1);0<f&&(a=c.slice(d+1,f))}}else a=c;b&&(a=a.toUpperCase());return a}
function be(a){a.delay?setTimeout(ec,10):ec()}
function Kd(a,b,c,d,f,h,n){a=Math.round(a*(1-n)+d*n);b=Math.round(b*(1-n)+f*n);c=Math.round(c*(1-n)+h*n);return"rgb("+a+" "+b+" "+c+")"}
const Pa=0,Qa=1,Hd=2,ac=4,ud=5,ad=6,Id=7;
function cc(a,b){if(Qd(a))if(a.d&&a.d.type!=Id){if(ob){ob.classList.remove("tab-now");var c=pb;c&&!c.hidden&&(c.hidden=1,ce(),c.style.display="none")}ob=a;if(ub){var d=da;c=1/(d+1);var f=qb.indexOf(a);0<f&&qb.splice(f,1);qb.push(a);qb.length>d&&(d=qb.shift(),delete ub[d.d.id],d.lev1=999,d.style.setProperty("--bg",Kd(132,175,255,255,255,255,.85)));a.classList.add("tab-hot");d=qb.length-1;for(f=d-1;0<=f;f--){var h=qb[f];ub[h.d.id]=h.lev1=d-f;h.style.setProperty("--bg",Kd(132,175,255,255,255,255,c*(d-
f)))}}a.classList.add("tab-now");d=gb=a.d;c=a.tabView;if(!c){c=d.type;try{c==Pa?(c=Pb(d,d.path,a),c.taEl=a):c=c==Qa?Ec(d,d.path):c==Hd?newTabPlainDict(d,d.path):c==ac?cd(d,d.path):c==ud?dd(d,d.path):c==ad?Xc(d,d.path):""}catch(l){console.error(l),c=""}c||=O(0,jb,0,"错误");a.tabView=c}(d=pb!==c)&&(pb=c);f=c.parentNode!=jb;if(c.hidden||f){if(c.hidden=0,c.style.display="",f&&jb.append(c),c.onAttach)try{c.onAttach()}catch(l){va(l)}}else if(d&&c.onResume)try{c.onResume()}catch(l){va(l)}if(xb)b?Fd():(b=a.offsetWidth,
c=a.offsetLeft,d=T.scrollLeft,f=T.clientWidth,h=null,d>c+b/2+9?h=a.offsetLeft:d+f<c+2*b/3+9&&(h=c-f+b),null!==h&&T.scrollTo({left:h,behavior:"auto"}));else{c=a.offsetHeight;d=a.offsetTop+c;f=T.scrollTop;h=T.clientHeight;var n=null;d<f+c/2+9?n=a.offsetTop:d>f+h&&(n=d-h);null!==n&&T.scrollTo({top:n,behavior:b?"auto":"smooth"})}}else cc(a.nextElementSibling)}
I.onfocus=function(a){ba!=m.dark&&qd();if(I._blr&&(I._blr=0,pb&&pb.onResume))pb.onResume()};
I.onblur=function(a){I._blr=1;ce(1);Nd();de();Jb.dirty&&eb.saveOpt()};
I.onbeforeunload=function(){ee();ce(1);T.save();de();y||delete m.bkWnds[la.id];Jb.dirty&&eb.saveOpt()};
function Yd(a,b,c,d){function f(){ec();if(n){var u=dc([n],0,W?.nextElementSibling);cc(u);sb=od=h=1;"tabCustom"==a&&setTimeout(()=>fe(W=u),100)}h&&T.dirty()}
var h=0,n=0,l=W?.d;switch(a){case "&addFav":Xd(W,d);break;case "newFavFolder":chrome.bookmarks.get(l.path,function(u){if(u=u?u[0]:0){var E=u.title||"",G=E.replace(/\d+$/g,function(N){return(parseInt(N)+1).toString()});
(E=prompt("新建文件夹",G!==E?G:E+" 1"))&&chrome.bookmarks.create({parentId:u.parentId,title:E,index:u.index+1},function(N){N&&(n=m.newTab(Cb,N.id,Pa,T),f(),T.save())})}});
return;case "openLocatedFoler":return Yb(W,l),1;case "&newTab":return Od(Z.e),1;case "tabFav":n=m.newTab(Cb,pa?pa.parentId:"0",Pa,T);break;case "tabRec":n=m.newTab(Cb,"recent=1000",Pa,T);break;case "tabImp":case "tabTmp":var p="tabImp"==a;if(d){b=p?K("9m"):K("4u");var r=p?"important://":"important://tmp";ge(u=>{var E=u[0].value;u=u[1].value;E=(p?"imp_":"imp_tmp")+(E.startsWith(r)?E.slice(r.length):"");n=m.newTab(Cb,E,Qa,T);n.title=u;f()},r,b)}else n=m.newTab(Cb,p?"imp_":"imp_tmp",Qa,T);
break;case "tabAll":n=m.newTab(Cb,"all",Qa,T);n.title="全部页面";break;case "tabSch":n=m.newTab(Cb,"sch:",Fb=ad,T);n.title=K("e1");setTimeout(()=>{Fb=0},250);
break;case "tabPDict":n=m.newTab(Cb,"",Hd,T);break;case "tabWeb":b=prompt("输入网址：","");if(void 0!=b)b=b||"about:blank",n=m.newTab(Cb,b,ac,T,ae(b,!0));else return;break;case "tabBaidu":n=m.newTab(Cb,"custom://baiduadv",ud,T,"百度高级搜索");break;case "tabCustom":b=K("ry");r="custom://";ge(u=>{var E=u[0].value;u=u[1].value;E=r+(E.startsWith(r)?E.slice(r.length):"");n=m.newTab(Cb,E,ud,T);n.title=u;f()},r,b);
return;case "schNew":case "schThis":bd(u=>Uc(Tc(W.d),u||pb.et1?.value||pb.et?.value,"T"==a[3],!0,!d));
break;case "setTemp":m.setTmpUrlPath(l.path,l.title);break;case "openWeb":var w=l.path;l.type==ad&&(w=(new URL(w.slice(4))).origin+"");l.type==Pa&&(w=Na(l));$b(w,function(u){u&&0<u.length&&!d.ctrlKey?chrome.tabs.update(u[0].id,{active:!0}):Xb(E=>{chrome.tabs.create({active:!d.ctrlKey,url:w,index:E.index+1})})});
break;case "copyUrl":c=Na(W.d);Ta(c);Zb(c);Sb(W);break;case "dupTab":Rd(W);h=1;break;case "&editSrc":fe(W);break;case "newSep":n=m.newTab(Cb,"",Id,T,"&emsp;&emsp;");d||(n.br=1);break;case "brSep":(b=!W.br)?(b=W.br=O("div",0,"flex-break"),T.insertBefore(b,W),b.fixed=W.fixed=1,b.fix=W.fix=1):W.br&&(W.br.remove(),W.br=W.fixed=W.fix=0);l.br=b;h=1;break;case "oneRow":xb=b;sb=1;wd(T);setTimeout(()=>Fd(1),10);
break;case "expTab":Jb[a]=vb=b;sb=1;Pd(W);break;case "recPos":yb=b;sb=1;break;case "&closeTab":if(W.classList.contains("selected"))h=Jc(hd,W,u=>{l=u.d;Ua.remove(yc(l));l.type==ud&&Ua.remove(yc(l)+"_")});
else if(b=hd&&ob==W?ob.previousElementSibling||T.firstElementChild:0,h=Kc(hd,W,xd,T))cc(b),Ua.remove(yc(l)),l.type==ud&&Ua.remove(yc(l)+"_"),W.br&&W.br.remove();od=1;break;case "resumeTab":(h=Lc(hd,W))&&cc(h);od=1;break;case "exportTabs":c=[];b=[];W.classList.contains("selected")&&hd&&hd.els().length?c=hd.els():c.push(W);for(var q=0;q<c.length;q++)(l=c[q].d)&&b.push(l);c=JSON.stringify(b);ra("复制::",b);Ta(Gb=c);Zb(`已导出${b.length}个标签页至剪贴板`);break;case "importTabs":he(u=>{var E=JSON.parse(u||Gb);u=T.children.length;
for(var G=0;G<E.length;G++)E[G].id=m.newTabid(Cb,T.children.length+G);E=dc(E,0,W.nextSibling);cc(E);sb=od=1;T.dirty();ec();Zb(`已导入${T.children.length-u}个标签页`)});
return;case "moveTabs":h=Mc(hd,W);break;case "selTabs":Oc(hd);break;case "multiTab":return jd(),W&&hd&&hd.els(W)||(Jb.mt=b),1;default:return Jb[a]=b,1}f();return 1}
var ie,Z,W,pc,Ub,Wd;
function Ud(a,b){if(b){if(window.e=a,qc()){b=Z.style;Z.p.style.display="block";b.visibility="";var c=a.clientX,d=a.clientY;b.maxHeight="";if(Z.revert)b.right=I.innerWidth-c+5+"px",b.bottom=I.innerHeight-d+5+"px";else{var f=Z.parentNode.offsetWidth,h=Z.parentNode.offsetHeight;c+Z.offsetWidth/2>f&&(c=f-Z.offsetWidth/2,d+=2);b.left=c+"px";d+Z.offsetHeight>=h+45&&Z.offsetHeight/2>h-d&&150>h-d?(b.bottom=h-d+5+"px",b.top=b.maxHeight="",c=Z.cards[0].style,c.display="flex",c.flexDirection="column-reverse",
b.maxHeight=Z.parentNode.offsetHeight-(h-d+5)+"px",setTimeout(()=>{Z.cards[0].firstElementChild.scrollIntoView()},5)):(b.maxHeight=Z.parentNode.offsetHeight-d-5+"px",b.top=d+"px")}}}else setTimeout(()=>{Ud(a,1)},5)}
function jc(a){R(a)}
function Td(a,b,c){if(ie){if(a&&ie.n===a)return ie.p.parentNode||document.body.append(ie.p),ie;ie.parentNode&&ie.remove()}var d=Ca("menup");d||(d=O(0,document.body),d.id="menup",d.onmousewheel=function(n){n.srcElement==d&&ec()},d.onmouseup=function(n){var l=n.target;
l===d?ec():1==f.type&&(R(n),2==n.button&&(I.oncontextmenu=jc),l.classList.contains("sep")||l==f||(n.delay=!0,be(n)),2==n.button&&uc())});
var f=O(0,d,"menu","max-width:35%;overflow:overlay;overflow-x:hidden;visibility:hidden"),h=f;h.cards&&(h.cards.forEach(function(n){n.remove()}),h.cards=0);
SettingsBuildCard(c,b,h);f.n=a;f.l=b;f.p=d;return ie=f}
function ec(){Z&&(Z.p.style.display="none",pc&&pc(Z),Z=null)}
if(y)chrome.tabs.query({active:!0,lastFocusedWindow:!0},function(a){if(la=a[0])Wb(b=>{}),ma&&ma()});
else{var Rc=document.title;document.title+=Math.random();chrome.tabs.query({title:document.title},function(a){if(la=a[0])Wb(b=>{}),m.bkWnds[la.id]=1;
document.title=Rc;la.title=Rc})}function wc(){}
setTimeout(function(){ib.remove();ib=0},95);
y||chrome.runtime.onMessage.addListener(function(a,b,c){if("focus"==a.name)I.onfocus();if("blur"==a.name)I.onblur()});
vb&&Pd();var Dd=Ca("tabgroup"),je,ke;function Ed(){Dd.dirty||(Dd.dirty=()=>{Dd._dirty=m.verTG+1;Dd._dirty<=m.verTG&&(m.verTG=0,Dd._dirty=1)},La("mousewheel",function(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;
(b=Math[1<=b?"floor":"ceil"](b))&&Dd.scrollTo({left:Dd.scrollLeft+80*b,behavior:"auto"});R(a)},1,Dd));
Ya("tab_groups",a=>{a&&a.constructor===Array||(a=[]);0==a.length&&(a.push({id:"tabs",name:K("rw"),type:vd}),a.push({id:"tabs1",name:K("cc85")}),a.push({id:"tabs2",name:K("tt"),t0:2}),a.push({id:"tabs3",name:K("lt"),t0:3}));je=a;le(je);ne()})}
function oe(a){de();a=a.target;a.d&&(a.d.id==rb.id?Fd(1):(ke&&ke.classList.remove("sel"),Nd(),pe(a.d),a.classList.add("sel"),ke=a,Hb=!1))}
function pe(a,b){b||(ce(1),Nd(),de());od=1;rb=a;ub=0;b?td(rb):Ic("sel_tab_gp",rb,()=>td())}
function Nd(){T.save()}
function Ic(a,b,c){y?cb(a,b,c):(sessionStorage.setItem(a,JSON.stringify(b)),c&&c())}
function Hc(a,b,c){if(y||c)Ya(a,b);else{c=sessionStorage.getItem(a,null);try{c=JSON.parse(c)}catch(d){c=0}c?b&&b(c):Hc(a,b,1)}}
function le(a){Dd.innerHTML="";O(0,Dd,"tgpd");for(var b=ke=0,c;c=a[b++];){var d=O(0,Dd,"tg");d.innerText=c.name;d.id="tg_"+c.id;d.d=c;d.onclick=oe;d.oncontextmenu=qe;re||(d.draggable=!0,d.ondragstart=se);c.id==rb.id&&(ke=d,rb=c,d.classList.add("sel"))}O(0,Dd,"tgpd");ke&&requestAnimationFrame(()=>{Dd.scrollLeft=ke.offsetLeft-(Dd.offsetWidth-ke.offsetWidth-45)/2})}
const te=0,vd=1;function ue(a,b,c){function d(w,q,u){r=je.indexOf(l);0>r?r=je.length:r++;for(var E=0,G=0,N;N=je[G++];)N=1+(parseInt(N.id.slice(4))||0),N>E&&(E=N);var ea=E;Ya("rcy_bin_tg",S=>{function Fa(Ra){if(!za[Ra]&&!Ca("tg_tabs"+(Ra||"")))return E=Ra,p={id:"tabs"+(E||""),name:w,type:u||te,t0:q},je.splice(r,0,p),pe(p),h(),1}
S=S||[];for(var za={},ta=0,wa;void 0!=(wa=S[ta++]);)wa=wa.id||wa,wa?.slice&&(wa=parseInt(wa.slice(4))||0,za[wa]=1);for(S=0;!Fa(E)&&S<ea+1024;)S++,E=S})}
function f(w){r=je.indexOf(l);n=1;if(w){je.splice(r,1);if(l.id==rb.id){(p=je[r])||(p=je[r-1]);if(!p){d(K("d"));return}pe(p)}Ya("rcy_bin_tg",q=>{q=q||[];if(25<=q.length+1)for(var u=q.splice(0,10),E=0;E<u.length;E++){var G=u[E].id||u[E]+"";Ca("tg_tabs"+(G||""))||(m._DEBUG&&(ra("delete tabgroup #"+G),Wa(G)),Ua.remove(G))}q.push(l);cb("rcy_bin_tg",q)});
Ya(l.id,q=>{"string"===typeof q&&(q=JSON.parse(q));if(q)for(var u=0,E;E=q[u++];)Ua.remove(yc(E,l))});
Ua.remove("v_"+l.id+"__");h()}else r++,Ya("rcy_bin_tg",q=>{q=q||[];p=q.pop();je.splice(r,0,p);pe(p);h();cb("rcy_bin_tg",q)})}
function h(){ec();if(n||p)Dd.dirty(),le(je)}
var n=0,l=W.d,p,r;switch(a){case "rename":if(a=prompt(K("e5"),l.name))l.name=a,n=1;break;case "newGroup":(a=prompt(K("5"),K("g2")))&&d(a,3);return;case "ngpEmpty":d(K("d"));return;case "ngpBar":d(K("rw"),0,vd);return;case "ngpBkmk":d("bookmarks",1);return;case "ngpSch":d(K("tt"),2);return;case "close":f(!0);return;case "restore":f(!1);return;default:return Jb[a]=b,1}h();return 1}
function qe(a){if(window.oncontextmenu==jc)jc(a);else{de();for(var b=a.target,c=b==Dd;!c&&b&&!b.classList.contains("tg");)b=b.parentNode;c=["",[0,["rename",0],[K("fu")],1],[0,["newGroup",0],[K("1")],1,,[0,["ngpEmpty",0],[K("d")]],[0,["ngpBar",0],[K("rw")]],[0,["ngpBkmk",0],[K("o8")]],[0,["ngpSch",0],[K("tt")]]],[0,["close",0],[K("x")],1,[0,["restore",0],[K("1q")]]]];nc(c,ue,a,b,qe);if(qc()){Z.e=a;if(a=Ca("selTabs",rc()))a.title=K("a"),a.oncontextmenu=d=>{Sd(hd);R(d);ec()};
if(a=Ca("rename",rc()))a.onmousedown=d=>{1==d.button&&(R(d),d.target.click())}}}}
function de(){if(Dd._dirty>m.verTG){for(var a=[],b=0,c;c=Dd.children[b++];)c.d&&void 0!=c.d.id&&a.push(c.d);cb("tab_groups",a,()=>{m.verTG=Dd._dirty})}}
var ve=-1,we;function xe(){clearTimeout(ve);var a=Ca("toastview");a.style.opacity=0;ve=setTimeout(function(){ve=-1;a.style.display="none"},300)}
function Zb(a,b,c,d,f){-1!=ve&&clearTimeout(ve);d||(d=B.body);var h=Ca("toastview");h||(h=O(0,d),h.id="toastview",O(0,h).id="toasttext");var n=h.parentNode;n!=d&&(n&&h.remove(),d.appendChild(h));d=h.firstChild;d.innerHTML=a;d.className=1<=b?"warn":"info";ve=setTimeout(xe,c||1E3);setTimeout(function(){h.style.opacity=1},16);
h.style.display="block";d.style.opacity=f||1}
function Sb(a,b){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},b||599)}
var Zc,$c;
function bd(a){if($c)a($c);else{var b=la.pendingUrl||la.url,c=(new URL(b)).searchParams,d=c.get("q")||c.get("wd")||c.get("search")||c.get("searchkey")||c.get("keyword")||c.get("query")||c.get("sokeytm")||c.get("char")||c.get("text")||c.get("queryField_a")||c.get("w")||c.get("q1")||c.get("terms")||c.get("term");null===d&&(c=b.indexOf("zdic.net/hans/"),0<c&&(d=b.slice(14)),0>c&&(c=b.indexOf("dictionary/"),0<c&&(d=b.slice(11))),0>c&&(c=b.indexOf("/zh/"),0<c&&(d=b.slice(4))),0>c&&(c=b.indexOf("/search/"),0<
c&&(d=b.slice(c+8))),d&&(c=d.indexOf("?"),0<c&&(d=d.slice(0,c))));null===d&&(d="");d=decodeURIComponent(d).replace(/\+/g," ");y?chrome.tabs.executeScript(la.id,{code:"window.getSelection().toString()"},function(f){f&&f[0]?a(f[0]):a(d)}):a(d)}}
function yc(a,b){return"v_"+(b||rb).id+"_"+a.id}
function Yc(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return'url("chrome://favicon/'+a+'")'}
function ye(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return"chrome://favicon/"+a}
function ze(a){for(var b=0,c=0,d=0,f=a.length/4,h=0;h<a.length;h+=4)b+=a[h],c+=a[h+1],d+=a[h+2];return"rgb("+Math.round(b/f)+","+Math.round(c/f)+","+Math.round(d/f)+")"}
function Ae(a){for(var b={},c=0,d=null,f=0;f<a.length;f+=4){var h=a[f],n=a[f+1],l=a[f+2];255==a[f+3]&&(h=h+","+n+","+l,b[h]?b[h]++:b[h]=1,b[h]>c&&(c=b[h],d=h))}return"rgb("+d+")"}
var re;function Be(a){m.initSortable(B,I);re=new Sortable(Dd,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabG",root:!0,forceFallback:!1,sort:!0,anisk:1,onMove(b){this.options.animation=300;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){re.did(b)&&Dd.dirty()},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;I.disani=0},click(b){oe(b)},trace:function(){console.log("trace"+Error().stack)}});
a&&(re._onTapStart(a),a.constructor==DragEvent?re._onDragStart(a):re._onDrop(a),se(a,1))}
function se(a,b){re?a&&(b?Dd.onclick=a.target.ondragstart=void 0:se(a,1)):m.initSortable&&!Qb?Be(a):m.loadSortable(function(){Be(a)})}
function hc(a){return`<div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">
            <div style="white-space:nowrap;font-size:.89em;padding-right:10px;text-align:center;padding-top:7.9px;">${a}</div>
            <textarea class='eta' style="flex:1;resize:vertical;min-height:30px;font-size: large;padding-left: 17px; padding-top: 10px;"></textarea>
        </div>`}
function lc(a){return a.type==Pa&&!a.path.startsWith("q=")&&!a.path.startsWith("recent")}
function Vd(a,b,c){function d(p){Ga("hot",Wd)?.classList.remove("hot");p.target.classList.add("hot");c(p.target.idx)}
var f=Z.style;if(!Wd){Wd=O(0,0,"tabG");var h=Wd.style;h.position="fixed";h.height="auto";h.background="white";h.borderRadius="4px";h.transform="scale(0.9)";h.transformOrigin="left";h.boxShadow=getComputedStyle(Z.cards[0]).boxShadow}h=Wd.style;Wd.innerText="";for(var n=0;n<a.length;n++){var l=O(0,Wd,"tg"+(b==n?" hot":""));l.idx=n;Ia(l,a[n]);l.onclick=d}h.left=parseInt(f.left)+1.5+"px";f.top?(h.bottom=Z.parentNode.offsetHeight-parseInt(f.top)-.75+"px",h.top=""):(h.top=Z.parentNode.offsetHeight-parseInt(f.bottom)+
"px",h.bottom="");Ca("menup").insertBefore(Wd,Z)}
function qc(){return!!I.SettingsBuildCard}
function rc(){return Z.shadowRoot||B}
function Sb(a){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},599)}
function Wb(a){chrome.bookmarks.search({url:la.url},function(b){a(pa=b?b[0]:0)})}
function Xb(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(la=b?b[0]:0)})}
function $b(a,b){chrome.tabs.query({url:a},b)}
function ee(){var a=eb.bkmks.indexOf(hb);0<=a&&eb.bkmks.splice(a,1)}
function Rb(a){return void 0!=a.dateGroupModified}
function Qc(a,b){try{return a=new URL(a),b=new URL(b),a.origin==b.origin&&a.pathname==b.pathname}catch(c){}}
function mc(a,b){try{return(new URL(a)).hostname===(new URL(b)).hostname}catch(c){}}
function Ce(a){pb.et.value=a.target.innerText}
function Vc(){m.getSchKeys(a=>{Wc.innerHTML="";for(var b=a.length-1;0<=b;b--){var c=a[b],d=O(0,Wc,"sch-item");d.onclick=Ce;Ia(d,c)}})}
function ge(a,b,c){gc("assets/dialog.js",function(){var d=showDialog(B,B.body);Ia(d.t,"Edit");Ja(d.t1,hc(K("路径").toUpperCase())+hc(K("ti").toUpperCase()));Ia(d.btn0,"Save");var f=Ea("TEXTAREA",d.t1),h=b,n=c;f[0].value=b;f[0].oninput=function(l){l=l.target;l.value.startsWith(h)?b=l.value:l.value=b;f[1].value==c&&(c=f[1].value=n+b.slice(h.length))};
f[1].value=c;d.btn0.onclick=()=>{a(f);d.x()};
d.btn1.onclick=()=>{d.x()}},I.showDialog)}
function fe(a){gc("assets/dialog.js",function(){var b=showDialog(B,B.body);Ia(b.t,"Edit");Ja(b.t1,hc("CODE"));Ia(b.btn0,"Save");var c=a.tabView,d=c?._bg,f=ed(a.d),h=Ea("TEXTAREA",b.t1);ic(h[0]);c?(h[0].value=d.src,b.btn0.onclick=()=>{var n=h[0].value;cb(f,n,l=>{d.src=n;c.reload(d);b.x()})}):Ya(f,n=>{h[0].value=n;
b.btn0.onclick=()=>{cb(f,h[0].value,l=>{b.x()})}});
b.btn1.onclick=()=>{b.x()}},I.showDialog)}
function he(a){gc("assets/dialog.js",function(){var b=showDialog(B,B.body);Ia(b.t,"Edit");Ja(b.t1,hc("CODE"));Ia(b.btn0,"Save");var c=Ea("TEXTAREA",b.t1);ic(c[0]);b.btn0.onclick=()=>{a(c[0].value);b.x()};
b.btn1.onclick=()=>{b.x()}},I.showDialog)}
function fc(){return navigator.userAgent.includes("Edg/")}
function De(a){var b=Ka("result",a.target),c=Ga("up",b);a.clientX>=c.getBoundingClientRect().left?Ee(Ga("title",b).innerText):(cc(b.el,1),sb=1,Dc(),xb?Fd(1):T.scrollTop=b.el.offsetTop-b.el.offsetHeight)}
function Fe(a){var b=Ka("result",a.target),c=Ga("up",b);a.clientX>=c.getBoundingClientRect().left?(Ee("t: "+Ga("tabx",b).innerText),Ge()):(chrome.tabs.update(b.d.id,{active:!0}),Fc(b.d.windowId))}
const He="/";function Ie(a){a=a.split(He);for(var b=[],c=I._py,d=0,f,h,n;d<a.length;d++)if(f=a[d].trim(),""==f&&0!=d)b.push({m:-1});else{h=0;if(":"==f[0])try{n=new RegExp(f.slice(1)),h=1,f=0}catch(l){}0==h&&(n=c&&/[a-z]/g.test(f))&&(n=I._py_cp(f),h=2);b.push({m:h,zh:n,v:f})}return b}
function Je(a,b){for(var c=0,d;c<a.length;c++){d=a[c];var f=d.m;if(!(0>f)&&(d=0==f?b.includes(d.v):1==f?d.zh.test(b):_py(b,d.zh)))return d}}
function Ac(a){m.schTabKey=a;od=0;var b=a,c=O(0,Ke);if("t"!=b[0]||":"!=b[1]&&" "!=b[1]){a=a.trim();l=Ie(a);a=0;var d;for(b=T.children;d=b[a++];)if(d!=kb){var f=Ga("title",d);if(f&&(f=f.innerText,Je(l,f))){f=O(0,c,"result tab");var h=O(0,f);h.style="display:flex;align-items:center;gap:1px;";h.style.flex="1";var n=d.cloneNode(1);f.el=d;f.d=d.d;[].slice.call(n.children).forEach(r=>{h.append(r)});
f.onclick=De;f.oncontextmenu=Ad;d=O(0,f,"up");d.innerText="︿";d.style="transform:translateY(-15%);"}}}else{a=a.slice(2).trim();var l=Ie(a);chrome.tabs.query({},function(r){for(var w=0,q;q=r[w++];){var u=q.title;if(Je(l,u)||Je(l,q.pendingUrl||q.url)){var E=O(0,c,"result tab"),G=O(0,E,"item-icon");O(0,G,"img small").style.backgroundImage="url("+q.favIconUrl+")";G=O(0,E);G.style="display:flex;align-items:center;gap:1px;";G.style.flex="1";O(0,G,"tabx").innerText=u;E.d=q;E.onclick=Fe;q=O(0,E,"up");q.innerText=
"︿";q.style="transform:translateY(-15%);"}}})}var p=Le;
p&&setTimeout(()=>p.remove(),1);
Le=c;Me(Le.firstElementChild)}
var Ne,Ke,Le,zc=Ac,Oe,od;zc=0;function Me(a){a!=Oe&&(Oe&&Oe.classList.remove("hot"),a&&a.classList.add("hot"),Oe=a)}
function Ee(a){etSearch.value=a;etSearch.dispatchEvent(new Event("input",{bubbles:!0}))}
function Ge(){etSearch.select();var a=etSearch.value;if("t"==a[0]&&(":"==a[1]||" "==a[1])){var b=" "==a[2];a=getSelection();a.modify("extend","backward","line");a.modify("move","forward","character");a.modify("move","forward","character");b&&a.modify("move","forward","character");a.modify("extend","forward","line")}}
function Dc(a,b,c){if(a){if(!Ne){Ne=Ca("search-box");Ke=Ga("results",Ne);Le=Ke.firstElementChild;La("input",f=>{var h=etSearch.value;/[a-z]/g.test(h)?gc("assets/pinyin.js",()=>zc(h),I._py):zc(h)},1,etSearch);
var d=Ne.parentNode;La("keydown",f=>{"Escape"==f.key&&Dc()&&R(f);"Enter"!=f.key||f.altKey||(Oe&&Oe.click(),R(f));"ArrowUp"==f.key&&(Me(Oe?.previousElementSibling||Oe),R(f));"ArrowDown"==f.key&&(Me(Oe?.nextElementSibling||Oe),R(f))},1,d);
La("mousemove",f=>{Me(Ka("result",f.target))},1,Ke);
Ga("icon-close",Ne).onclick=()=>etSearch.value="";
d.onclick=f=>{f.target==Ne.parentNode&&Dc()}}b||=Ac;
if(zc==b)return}else y&&pa&&Bc("","stst");d=Ne.parentNode.style;if(a||"none"!=d.display)return d.display=a?"":"none",a&&(etSearch.focus(),c||(etSearch.select(),setTimeout(()=>{Ge()},200))),zc=b,y&&(m.popSching=!!b),1}
function nd(){var a=B.activeElement;if(a&&(a.shadowRoot&&(a=a.shadowRoot.activeElement),a=a?.tagName,"INPUT"==a||"TEXTAREA"==a))return 1}
function Ld(){y&&m.popSching&&(Dc(1),etSearch.value=m.schTabKey,etSearch.dispatchEvent(new Event("input",{bubbles:!0})))}
y&&m.schTime&&(500>Date.now()-m.schTime&&(Hb=!0),m.schTime=0);function ne(){if(Hb&&2!=rb.t0){Zb("gotoSchPanel");for(var a=0,b;b=Dd.children[a++];)if(b.d&&2==b.d.t0){pe(b.d,!0);le(je);break}}m.schTime=0}
function Fc(a){chrome.windows.update(a,{focused:!0},function(b){})}
var Pe,Qe,Re,Se,Te=-1,Ue,sc,Ve={},We,Xe,Ye,Ze;
function xc(a,b,c,d,f){return(()=>{function h(p){if(void 0!=p.clientX){Pe=p;var r=d(p)}else p=Pe,r=d(document.elementFromPoint(p.clientX,p.clientY));r?sc||=r:(c&&(r=n(p)),r||=sc);if(r){-1==Te&&(Te=l(sc));if(-1==We&&(b&&r.pos!=Te||3<Math.abs(Ve.y0-p.clientY))){Qe.lazyS&&T.lazyS(p,1);c?(We=l(r),Qe=r.lst||f(p),Ze=Qe.topPos()):(We=-100,Xe=r);var w=Qe,q=w.append;Se||=O(0,0,"BoxSel");q.call(w,Se);Qe.style.position="relative";La("scroll",h,Ba,Qe)}if(-1!=We){var u=Qe;q=Ve.x;var E=p.clientX;w=Ve.y;var G=u.scrollTop+
p.clientY-Ye;p=E-q;var N=G-w;0>N&&(N=-N,w=G);0>p&&(p=-p,q=E);c&&(We=l(r),u.topPos()!=Ze&&(Te<r.pos?(w=0,N=G):(w=G,N=u.scrollHeight+5)));u=Se.style;q+=Qe.scrollLeft;u.top=w+"px";u.left=q+"px";u.height=N+"px";u.width=p+"px";kc(r)}}}
var n=p=>{},l=b?p=>p.pos:p=>99;
c&&(n=p=>{if(p=f(p)){var r=p.findRow(p.ada.size-1);if(r&&r.offsetTop<p.scrollTop+p.offsetHeight)return r}});
a.mv=h;a.md=function(p){if(p.button==ka&&!Z){var r=d(p),w=r;r?Ue=0:(r=n(p),Ue=!!r);if(r||!c)w&&(sc=r),Qe=w=r?.lst||f(p),La("mousemove",h,Ba,B.body),We=Te=-1,Ve.x=p.clientX,Ye=w.getBoundingClientRect().y,Ve.y0=p.clientY,Ve.y=w.scrollTop+Ve.y0-Ye,kc(r),I.box=a}};
a.mu=function(p){if(p.button==ka&&Qe){var r=p.altKey;if(-1!=We){Ue&&sc==Re&&!d(Pe)&&(sc=0);if(sc)try{var w=Qe;if(c){var q=Te,u=We;Te>We&&(q=u,u=Te);var E;p=0;var G=1,N=w.topPos(),ea=w.salad;r=r?0:1;for(E=q;E<=u;E++){var S=w.ada.getItem(E);G&&E>=N&&(p=w.findRow(E),G=0);p&&(p.pos==E?Mb(p,"selecting",r):p=0);r?ea[S.id]={pos:E,id:S.id,e:p}:delete ea[S.id];p&&=w.rowSibling(p)}}else{q=T.S.els();u=parseInt(Se.style.left);G=parseInt(Se.style.top);var Fa=u+Se.offsetWidth,za=G+Se.offsetHeight;E=0;for(var ta;ta=
w.children[E++];){var wa=ta.offsetLeft,Ra=ta.offsetTop,zb=wa+ta.offsetWidth,F=Ra+ta.offsetHeight;if(ta.d&&!(zb<=u||wa>=Fa||F<=G||Ra>=za)&&r^!ta.classList.contains("selected")){var D=q.indexOf(ta);r?0<=D&&q.splice(D,1):0>D&&q.push(ta);Mb(ta,"selected",!r)}}}}catch(Q){va(Q)}We=-1;uc();Ma("scroll",h,Ba,Qe);kc();Se.remove()}Ma("mousemove",h,Ba,B.body);sc=0;Te=-1;Qe=0}}})()}
function uc(){I.oncontextmenu=jc;setTimeout(function(){I.oncontextmenu=0},20)}
var $e;function kd(){$e||($e={},xc($e,0,0,a=>Ka("tab",a.target||a,T),a=>T));
T.lazyS=function(a,b){if(b||a.ctrlKey||a.shiftKey)(b||a.target!=T)&&jd(a),T.lazyS=0};
T.onclick=Md;T.onmousedown=$e.md}
function kc(a){Re!=a&&(Mb(Re,"hot"),Re=a,Mb(Re,"hot",null!=a))}
function af(a){I.box&&I.box.mu(a);xa&&xa(a)}
function ce(a){if(pb?.onRemove)try{pb.onRemove(a)}catch(b){va(b)}}
La("mouseup",af,1,B);function bf(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;(b=Math[1<=b?"floor":"ceil"](b))&&T.scrollTo({left:T.scrollLeft+80*b,behavior:"auto"});R(a)}
function wd(a){var b=a.style;xb?(b.overflowX="auto",b.flexFlow="nowrap",a.classList.add("r1"),Ma("mousewheel",bf,1,a),La("mousewheel",bf,1,a)):(b.overflowX="",b.flexFlow="wrap",a.classList.remove("r1"),Ma("mousewheel",bf,1,a))}
function Fd(a,b){if(xb){b||setTimeout(()=>Fd(a,1),5);
if(!a&&null!==tb&&y&&yb)try{T.scrollLeft=tb;return}catch(c){}try{T.scrollLeft=ob.offsetLeft-I.innerWidth/3}catch(c){}}else{if(!a&&null!==tb&&y&&yb)try{T.scrollTop=tb;return}catch(c){}try{T.scrollTop=ob.offsetTop-aa/3*sd}catch(c){}}}
function tc(){y||(m.fakePP=Date.now(),chrome.browserAction.openPopup(function(a){a&&a.close();chrome.runtime.lastError}))}
function Gc(){var a=Date.now();if(250<=a-ya)return ya=a,1}
function ic(a){a.wrap="off";a.style.minHeight=parseInt(pb.clientHeight/4)+"px";setTimeout(()=>{a.focus();a.select()},35)}
function Bc(a,b,c){var d=0;b&&(d=Ca(b));d?c&&c!=d.parentNode&&c.append(d):(d=B.createElement("STYLE"),b&&(d.id=b),(c||B.head).append(d));d.innerText=a}
function ed(a){var b=a.path;return"custom://"!=b?(b.startsWith("custom://")&&(b=b.slice(9)),"pagelet_"+b):yc(a)+"_"}
function qd(){(ba=m.dark)?Bc("html{-webkit-filter:invert(100%);background:#fff","dark"):Bc("","dark")}
qd();function oc(){Jb.wrapBT?Bc("","wrapBT"):Bc(".item-title{text-wrap:nowrap;}","wrapBT")}
oc();B.addEventListener("scroll",a=>{B.documentElement.scrollTop&&(B.documentElement.scrollTop=0)});
function fd(a){chrome.tabs.executeScript(la.id,{code:'getSelection()+""'},b=>{a(b?b[0]:b)})}
;