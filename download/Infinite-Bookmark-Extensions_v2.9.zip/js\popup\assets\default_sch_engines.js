doit('v', '常用', 7);
doit('sch:https://www.douyin.com/search/%s?publish_time=0&sort_type=0&source=switch_tab&type=video', '抖音搜索');
doit('sch:https://search.bilibili.com/all?keyword=%s&from_source=webtop_search&spm_id_from=333.1007&search_source=5', 'B站视频');
doit('sch:https://www.baidu.com/s?ie=utf-8&wd=%s', '百度搜索');
doit('sch:https://www.baidu.com/s?ie=utf-8&medium=0&rtt=1&bsst=1&rsv_dl=news_t_sk&cl=2&wd=%s&tn=news', '百度资讯');
doit('sch:https://www.google.com/search?q=%s', '谷歌搜索');
doit('sch:https://cn.bing.com/search?q=%s', 'Bing 搜索');
doit('sch:https://emojixd.com/search?q=%s', '表情搜索');
doit('sch:https://emojicombos.com/%s', 'Emoji搜索');
doit('sch:https://icp.chinaz.com/%s', '备案查询');

doit('v', '汉语', 7);
doit('sch:https://hanyu.baidu.com/s?wd=%s', '百度汉语');
doit('sch:https://www.zdic.net/hans/%s', '汉典');
doit('sch:http://www.guoxuedashi.net/so.php?sokeytm=%s', '国学大师');
doit('sch:https://www.wu-chinese.com/minidict/search.php?searchkey=%s&searchlang=zaonhe&category=', '吴音小字典');
doit('sch:https://www.wugniu.com/search?char=%s&table=shanghai', '吴语学堂');


doit('v', '外语翻译', 7);
doit('sch:https://www.bing.com/dict/search?q=%s', 'Bing 词典');
doit('sch:https://en.wiktionary.org/w/index.php?search=%s&title=Special%3ASearch&go=Go&ns0=1', '维基词典');
doit('sch:https://www.vocabulary.com/dictionary/%s', 'Vocabulary');
doit('sch:https://fanyi.baidu.com/?aldtype=16047#auto/zh/%s', '百度翻译');
doit('sch:https://translate.google.com/?sl=auto&text=%s&op=translate', '谷歌翻译');


doit('v', '搜狗', 7);
doit('sch:https://www.sogou.com/web?query=%s', '搜狗搜索');
doit('sch:https://www.sogou.com/sogou?pid=sogou-wsse-ff111e4a5406ed40&insite=zhihu.com&ie=utf8&p=73351201&query=%s&ie=utf8&p=73351201&query=test', '知乎搜索');
doit('sch:https://weixin.sogou.com/weixin?p=01030402&query=%s&type=2&ie=utf8', '微信');


doit('v', '学术搜索', 7);
doit('sch:https://www.sciengine.com/search/search?queryField_a=%s', '科学通报');
doit('sch:https://xueshu.baidu.com/s?wd=%s&ie=utf-8', '百度学术');
doit('sch:https://www.semanticscholar.org/search?q=%s&sort=relevance', 'SEMANTIC SCHOLAR');
doit('sch:https://www.aminer.cn/search/pub?t=b&q=%s', 'AMiner');
doit('sch:https://oaister.worldcat.org/search?q=%s&qt=sort&se=yr&sd=desc&qt=sort_yr_desc', 'OAIster');
doit('sch:https://scholar.google.com/scholar?q=%s&btnG=&lr=', 'Google Scholar');
doit('sch:https://www.google.com/search?tbm=bks&q=%s', 'Google Books');
doit('sch:https://archive.org/search?query=%s', 'INTERNET ARCHIVE');



doit('v', '千寻', 7);
doit('sch:https://www.chinaso.com/newssearch/all/allResults?q=%s', '中国搜索');
doit('sch:https://so.toutiao.com/search?dvpf=pc&source=input&keyword=%s', '头条搜索');
doit('sch:https://www.so.com/s?ie=utf-8&q=%s', '360搜索');
// doit('sch:http://www.baidu.com/s?wd=%s', '百度简单搜索');
doit('sch:https://quark.sm.cn/s?q=%s', '神马AI引擎');
doit('sch:http://www.yz.sm.cn/s?q=', '神马搜索');
doit('sch:https://www.wuzhuiso.com/s?ie=utf-8&fr=no_query&src=home_no_query&q=%s', '无追');
doit('sch:https://www.mijisou.com/?q=%s', '秘迹搜索');
doit('sch:https://search.yahoo.com/search?p=%s', '雅虎搜索');
doit('sch:https://www.jianshu.com/search?q=%s', '简书搜索');
doit('sch:https://www.sogou.com/web?query=%s+百科', '百科');



doit('v', '国际', 7);
doit('sch:https://yandex.com/search/?text=%s', 'Yandex');
doit('sch:https://www.qwant.com/?q=%s', 'Qwant');
doit('sch:https://www.ecosia.org/search?method=index&q=%s', 'Ecosia');
doit('sch:https://duckduckgo.com/?va=f&t=hj&q=%s', 'DuckDuckGo');
doit('sch:https://search.naver.com/search.naver?query=%s', 'Never搜索');
doit('sch:https://www.wikihow.com/wikiHowTo?search=%s', 'WikiHow');
doit('sch:https://en.wikipedia.org/w/index.php?search=%s&title=Special:Search&profile=advanced&fulltext=1&ns0=1', '维基百科');


doit('v', '技术搜索', 7);
doit('sch:https://stackoverflow.com/search?q=%s', 'StackOverflow');
doit('sch:https://www.google.com/search?q=%s', 'Google');
doit('sch:https://kaifa.baidu.com/searchPage?wd=%s', '百度IT');
doit('sch:https://juejin.cn/search?query=%s&type=0', '稀土掘金');
doit('sch:https://so.csdn.net/so/search?q=%s', 'CSDN');
doit('sch:https://search.gitee.com/?skin=rec&type=repository&q=%s', 'Gitee');
doit('sch:https://www.sqlite.org/search?s=d&q=%s', 'sqlite');
doit('sch:https://developer.mozilla.org/en-US/search?q=%s', 'MDN');
doit('sch:https://learn.microsoft.com/en-us/search/?terms=%s', 'MSDN');
doit('sch:https://github.com/search?q=%s', 'Github');