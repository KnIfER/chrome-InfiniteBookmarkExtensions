'use strict';var p=chrome.extension.getBackgroundPage(),ba=4;if(p.fakePP){if(400>(new Date).getTime()-p.fakePP)throw setTimeout(function(){window.close()},200),1;
p.fakePP=0}const ca=15,da=0,fa=1,ha=2;var ia,la,sa,ua=location.href==`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html?popup=1`,ya=console.log,za=console.log,Aa=console.error,w=document,A=window,Ba,Ca=0,Da=void 0;A.isPopup=ua;function H(a,b){return(b||w).getElementById(a)}
function Ea(a,b){return(b||w).getElementByTagName(a)[0]}
function Fa(a,b){return(b||w).getElementsByTagName(a)}
function Ga(a,b){return(b||w).getElementsByClassName(a)[0]}
function Ha(a,b){return(b||w).getElementsByClassName(a)}
function K(a){return chrome.i18n.getMessage(a)||a}
function Ia(a,b){a.innerText=b}
function Ja(a,b){a.innerHTML=b}
function La(a,b,c){for(;b;){if(b.classList&&b.classList.contains(a))return b;if(c&&b==c)break;b=b.parentNode}}
function Ma(a,b,c,d){d||=win;d.addEventListener(a,b,c)}
function Na(a,b,c,d){d||=win;d.removeEventListener(a,b,c)}
function Oa(a){var b=a.path||"";a=a.type;a==Ra?b.startsWith("recent")||(/^\d+$/g.test(b)?b="chrome://bookmarks/?id="+b:(b.startsWith("q=")&&(b=b.slice(2)),b="chrome://bookmarks/?q="+b)):a==Sa&&(b.startsWith("recent")||(b="important://"+b.slice(4)));return b}
function N(a,b,c,d){a=w.createElement(a||"DIV");c&&(a.className=c);d&&(a.style=d);b&&b.appendChild(a);return a}
function T(a,b){try{b?a.stopImmediatePropagation():a.stopPropagation(),a.preventDefault()}catch(c){Aa(c)}}
function Ma(a,b,c,d){(d||A).addEventListener(a,b,c)}
function Ta(a){navigator.clipboard.writeText(a)}
const Ua=chrome.storage.local;function Va(a,b){Ua.get(a,b)}
function Wa(a){Ua.get(a,b=>{console.log(b[a])})}
function Ya(a,b){Va(a,c=>{b(c[a])})}
var Za={};function ab(a,b){Za[a]?b(Za[a]):Ya(a,c=>{b(Za[a]=c)})}
function bb(a,b){Ua.set(a,b)}
function cb(a,b,c){var d={};d[a]=b;bb(d,c)}
function db(a,b){Ua.remove(a,b)}
var eb=p.d(),fb,gb,hb={},ib=N("style",document.head);hb.reload=()=>{setTimeout(()=>{location.reload()},350)};
eb.bkmks.push(hb);N("style",document.head).innerText=`.folder-icon > .item-icon{-webkit-mask-image:url("chrome-extension://${chrome.runtime.id}/images/folder_open.svg")}`;ib.innerText=".img,IMG,.fico{display:none!important}";var jb=H("tabos"),lb=H("tabNew"),W=lb.parentNode,mb=W.parentNode,nb,X,ob=[],pb,rb,sb,vb,wb,xb,yb,zb={},Ab={},Bb={},Cb,Db=eb.opt;Db||(eb.opt=Db={autoExp:1,mcTab:1,tkImp:0,topImp:0,uniImp:1});w.title=K("fc");var Fb,Gb;
function Ib(a,b,c){if(a){a=a.classList;var d=a.contains(b);if(void 0===c||d^!!c)d?a.remove(b):a.add(b)}}
function Jb(a){return a.path.startsWith("recent")}
function Kb(a,b){p.initListView&&!Lb||p.loadListView();Fb||function(){function d(f,k,x){if(!k.t){var u=k._=k;u.classList.add("item-wrap");k.dot=N("P",u,"dot");k.con=N(0,u,"item-icon");k.icon=N(0,k.con,"img");k.lv=N("DIV",u,"item-tlv");k.t=N("P",k.lv,"item-title");k.st=N("P",k.lv,"item-subtitle");k.lv.draggable=!0;k.lv.ondragstart=z;k.lv.ondragend=L;k.ondblclick=pa;k.oncontextmenu=I;k.lst=f}u=f.ada.getItem(x);var v=f.salad;u||={title:""};k.data=u;var y=u.title||" ";if(y.startsWith("(")){var t=y.indexOf(")");
0<t&&(y=y.slice(t+1).trim())}k.t.innerText=y;y=u.url;t=k.icon;k.lv.href=y;Mb(u)^k.folder&&(k.folder=!k.folder,k.folder?(k._.classList.add("folder-icon"),t.style.backgroundImage=""):k._.classList.remove("folder-icon"));var F=v&&v[u.id];Ib(k._,"selecting",F||null);F&&F.e!=k._&&(v[u.id].e=k._);qa==u.id&&ma!=k&&Xa(ma);y?(k.st.innerText=y,k.folder||("javascript:"==y||y.startsWith("javascript:&tm=")||y.startsWith("https://separator")?t.style.backgroundImage="":(u=t.style,v=y,y=v.indexOf("/",v.indexOf(":")+
3),0<y&&(v=v.slice(0,y)),u.backgroundImage='url("chrome://favicon/'+v+'")'))):t.style.backgroundImage="";f.tada===x&&(Nb(k,15),f.tada=void 0)}
function g(f){f=f.target||f;for(var k=0;f;){if(f.data&&f.classList.contains("item")){k=f;break}if(f==w.body||f.classList.contains("ListView"))break;f=f.parentNode}return k}
function h(f){Object.keys(f).forEach(x=>{(x=f[x])&&Ib(x.e,"selecting",0)});
for(var k in f)delete f[k]}
function q(f){if(f){var k=f.tD,x=k.path;hb[x]&&(hb[x].data=0);p.pullBkmk(x,function(u){f.v.onRemove();Fb.bind(f,u,Ob(u,k,x))},ua,!0)}}
function n(f){f=f.ada.dPos(Y.pos+1);1==f&&Pb&&Pb.clientY-X.lv.getBoundingClientRect().y<Y.offsetHeight/2-5&&(f=0);return f}
function l(f,k,x,u){var v=Y.data;k=v.url;var y=Y.lst,t=y.salad,F=function(R){R&&q(y);Qb()};
switch(f){case "fold":var M=prompt(K("16"),K("lg"));y=Y.lst;if(M){var O=n(y);chrome.bookmarks.create({parentId:v.parentId,title:M,index:O},F)}break;case "addThis":O=n(y);1==O&&Pb&&Pb.clientY-X.lv.getBoundingClientRect().y<Y.offsetHeight/2-5&&(O=0);Rb(R=>{!R||u.ctrlKey?chrome.bookmarks.create({parentId:v.parentId,url:ia.url,title:ia.title,index:O},F):chrome.bookmarks.move(R.id,{parentId:v.parentId,index:O},F)});
break;case "newFav":!u||u.ctrlKey?D(v,y,v.parentId,0,v.index+(y.ada.ni?-1:1),!0):Sb(R=>D(v,y,v.parentId,R,v.index+(y.ada.ni?-1:1)));
break;case "addSep":r(u,v,y);break;case "&edit":D(v,y);break;case "replace":D(v,y,void 0,ia);break;case "delete":B(v,y);break;case "openFolder":Tb(nb,{path:v.id});break;case "pinTop":(()=>{function R(ta,ea,Pa,wa){Eb.length?(ea&&(wa=ra[ea.pos],ea.id==ta.id&&(ea.title=ta.title),wa==ea&&(ta=ra.splice(ea.pos,1)[0],ea.pos<Pa&&Pa--,ea.pos=Pa,ra.splice(Pa,0,ta))),G(Eb.shift())):F(ta||1)}
function G(ta){var ea=0,Pa=(ta.title||"").startsWith(ja);if(!J)for(var wa;wa=ra[ea];){if(Pa&&!qb&&wa==ta){Q="";ea=0;break}if(!(wa.title||"").startsWith(ja))break;ea++}chrome.bookmarks.move(ta.id,{parentId:ta.parentId,index:ea},Yb=>{Q&&Yb&&!Pa&&!J?chrome.bookmarks.update(ta.id,{title:Q+ta.title},Gc=>{R(Gc,ta,ea)}):R(Yb,ta,ea)})}
var J=!u||u.ctrlKey||u.shiftKey,Q="\ud83d\udccc ",ja=Q.trim(),ra=listView.arr,qb=C(v,t),Eb=m(v,t,qb,y);qb=1<Eb.length;R()})();
break;case "pinBot":(()=>{function R(ja){var ra=G.length,qb=(ja.title||"").startsWith("\ud83d\udccc ");chrome.bookmarks.move(ja.id,{parentId:ja.parentId,index:ra},Eb=>{qb&&chrome.bookmarks.update(ja.id,{title:ja.title.slice(3)});Q.length?R(Q.shift()):F(Eb||1)})}
var G=listView.arr,J=C(v,t),Q=m(v,t,J,y);J=1<Q.length;Q.length?R(Q.shift()):F(1)})();
break;case "openAll":f="";for(M in t)f+=y.arr[t[M].pos].url+"{BKMKBK}";chrome.runtime.sendMessage({urls:f,type:"openAll"},function(R){});
break;case "copyUrl":Ta(v.url);Ub(v.url);break;case "openInCurrent":Mb(v)?X.etLoca.reload(v.id,v.title):k.startsWith("javascript:")?chrome.tabs.executeScript(ia.id,{code:decodeURIComponent(k.slice(11))},function(R){ua&&window.close()}):chrome.tabs.update(ia.id,{url:k},function(R){ua&&window.close()});
xa();break;case "openInNewTab":Vb(v.url,function(R){R&&0<R.length?chrome.tabs.update(R[0].id,{active:!0}):chrome.tabs.create({url:v.url})});
xa();break;case "openInBackgroud":Sb(R=>{chrome.tabs.create({url:v.url,index:R.index+1,active:!1})});
xa();break;case "openInTmp":(()=>{var R=C(v,t),G=m(v,t,R,y);R=1<G.length;for(var J=0;R=G[J];J++)p.addToTmpUrls(R.url,R.title||"",0,()=>{G[J+1]||Nb(Y)})})();
break;case "openInIframe":M=p.newTab(zb,v.url,Wb,W);M.title=v.title;Xb(Zb([M],0,nb.nextSibling));W.dirty();break;default:return 1}$b();return 1}
function r(f,k,x,u){u=u?"https://separator.mayastudios.com/index.php?t=horz":"javascript:";ac()&&(u+="&tm="+Date.now());chrome.bookmarks.create({parentId:k.parentId,url:u,title:"───────────",index:x.ada.dPos(Y.pos+1)},function(v){v&&(q(x),$b(),(f.ctrlKey||1==f.button)&&D(v,x))})}
function C(f,k){return k[f.id]&&1<Object.keys(k).length}
function m(f,k,x,u){var v=u.arr,y=[],t=!1;if(x){for(var F in k)if(x=u.ada.d4sa(F,k[F]),x=v[x])t||x!=f||(t=!0),y.push(x);y.sort(function(M,O){return M.pos-O.pos})}t||y.push(f);
return y}
function D(f,k,x,u,v,y){bc("assets/dialog.js",function(){var t=showDialog(w,w.body);Ia(t.t,K("d"));Ja(t.t1,cc(K("lx").toUpperCase())+cc(K("q8").toUpperCase()));var F=void 0!==x;Ia(t.btn0,F?K("ww"):K("9"));Ia(t.btn1,K("q"));var M=Fa("TEXTAREA",t.t1);M[0].value=u?.title||f.title;var O=u?.pendingUrl||u?.url||f.url||"",R=O.startsWith("javascript:");R&&(O=decodeURIComponent(O));M[1].value=O;R&&dc(M[1]);t._kd=G=>{if("Enter"==G.key&&!G.ctrlKey&&(G=t.s.shadow.activeElement,G?.wrap&&"TEXTAREA"==G.tagName&&
G.value.startsWith("javascript:")))return 1};
t.btn0.onclick=()=>{var G=M[1].value;y&&ac()&&(G+=(G.includes("?")?"&":"?")+"tm="+Date.now());G.startsWith("javascript:")&&(G="javascript:"+encodeURIComponent(G.slice(11)));var J=Q=>{Q&&(q(k),t.x());Qb()};
G={url:G,title:M[0].value};F?(G.parentId=x,G.index=v,chrome.bookmarks.create(G,J)):chrome.bookmarks.update(f.id,G,J)};
t.btn1.onclick=()=>{t.x()}},A.showDialog)}
function B(f,k){var x=k.salad,u=C(f,x),v=m(f,x,u,k);bc("assets/dialog.js",function(){var y=showDialog(w,w.body);Ja(y.t,K("ns"));Ja(y.t1,K("aa").replace("size",v.length));Ia(y.btn0,K("6q"));Ia(y.btn1,K("q"));y.btn0.onclick=()=>{var t=()=>{chrome.bookmarks.remove(v.shift().id,function(){0==v.length?q(k):t();Qb()})};
t();y.x()};
y.btn1.onclick=()=>{y.x()}},A.showDialog)}
function I(f){if(window.oncontextmenu==ec)ec(f);else{var k=g(f);if(k)if(f.target==k.icon)pa(f,1),T(f);else{fc(k);var x=k.data,u=k.lst,v=C(x,u.salad),y=gc(u.tD),t=hc(x.url,ia.url);v=0==Ic?["",[0,y?"addThis":0,K("62"),1,,[0,"addSep",K("s")],[0,"fold",K("16"),1],[0,"newFav",K("l"),1]],[0,y?0:"openFolder",K("j"),1],[0,v?"openAll":0,K("jx")],[0,"&edit",K("z"),1],[0,"delete",K("t")],[0,t||f.altKey?"replace":0,K("2259")],[0,"pinTop",K("bo"),1],[0,"pinBot",K("fm")]]:["",[0,"openInCurrent",K("k4")],[0,
"openInNewTab",K("m")],[0,"openInBackgroud",K("tb")],[0,"openInTmp",K("e")],[0,"openInIframe",K("fb")],[0,"copyUrl",K("jk")]];ic(v,l,f,k,I,[K("7l"),K("h")],Ic,F=>{p.menuPageBkmk=Ic=F;I(f)});
Pb=f;jc=function(){fc()};
if(kc()){v=lc();if(k=H("addSep",v))k.title=K("a3"),k.oncontextmenu=F=>{T(F);r(F,x,u,!0)},k.onmousedown=F=>{1==F.button&&(T(F),r(F,x,u,!0))};
if(k=H("openInCurrent",v))k.title=K("右键不关闭弹窗"),k.oncontextmenu=F=>{chrome.tabs.update(ia.id,{url:x.url},function(M){$b()});
T(F);xa()};
if(k=H("newFav",v))k.title=K("7p"),k.oncontextmenu=F=>{l("newFav");T(F)};
if(k=H("pinTop",v))k.oncontextmenu=F=>{l("pinTop");T(F)}}}}}
function U(f,k,x){f.innerText=k.ni?"⇈":"⇊";f.title=k.ni?K("sb"):K("qe");x&&(x=f.title,x=k.ni?"⇈&emsp;"+x:x+"⇊",Ub(x))}
function na(f,k){k=k.icon;return f.clientX>k.offsetLeft+k.offsetWidth}
function S(f,k,x,u){var v=f.ver;f=f.salad;k?(Ib(k,"selecting",x),x?f[k.data.id]={pos:k.pos,e:k,ver:v}:delete f[k.data.id]):void 0!=u&&(f[x.id]={pos:u,ver:v})}
function Xa(f){ma=f;f.lst.sel=qc=f.pos;qa=f.id}
function xa(f){f||=Y;p.navPath=f.lst.tD.path;p.navCtx={idx:f.pos,ni:f.lst.ada.ni};p.navBkmk=f.data.id}
function pa(f,k){if(!mc){var x=g(f);if(x){fc(x);xa(x);var u=f.target==x.icon;if(na(f,x)||u){var v=x.data;if(x=v.url)u||f.shiftKey||f.ctrlKey?Sb(F=>{u||f.shiftKey?chrome.tabs.update(F.id,{url:v.url},function(){!ua||f.ctrlKey||k||window.close()}):f.ctrlKey&&Vb(v.url,M=>{M&&0<M.length?chrome.tabs.update(M[0].id,{active:!0}):chrome.tabs.create({url:v.url,
active:!1,index:F.index+1})})}):window.open(x);
else if(v.dateGroupModified){if(!f.ctrlKey){x=0;for(var y;y=W.children[x++];)if(y.d?.path==v.id&&y.type==Ra){var t=y;break}}t?Xb(t):(t=p.newTab(zb,v.id,0,W),t.title=v.title,Xb(Zb([t],0,nb.nextSibling)));W.dirty()}}}}}
function va(f){if(!mc)if(Ka){if(f.button==da){var k=g(f);k||(k=f.target,k=k.classList.contains("ListView")?{pos:k.ada.size,lst:k,data:{parentId:k.tD.path},getBoundingClientRect:function(){}}:0);
if(k){if(Jb(k.lst.tD))return;var x=k.getBoundingClientRect()||{};x=f.clientY>x.y+x.height/2;var u=k.data,v=$a.data;f=$a.pos-k.pos;var y=$a.lst==k.lst?0:k.lst;if(f||y){f=k.pos+1;x||f--;X.onRemove();var t=$a.lst,F=t.v,M=t.salad;k=Object.keys(M);var O=F.tP.pos,R=k[0].ver,G=0;x=t.ada.ni;try{k=k.sort(function(ea,Pa){if(M[ea].ver!=R)throw G=1,1;return M[ea].pos-M[Pa].pos})}catch(ea){}G&&(k=t.ada.sort(M,k.length));
x&&k.reverse();f<=O&&(O=0);function ta(ea,Pa){chrome.bookmarks.move(ea[ea.nxt],{index:Pa,parentId:u.parentId},function(wa){ea.nxt++;if(wa){var Yb=M[wa.id],Gc=Yb.pos;O&&Gc<O&&F.tP.pos--;y&&(v.parentId==wa.parentId||Jb(t.tD)||delete M[wa.id],y.salad[wa.id]={id:Yb.id});ea.nxt<ea.length?ta(ea,wa.index+1):wa=0}if(!wa){var od=nb.d.path;p.pullBkmk(od,function(pd){P(X.lv,pd,Ob(pd,nb.d,od))})}})}
k.nxt=0;t=y||t;f=t.ada.dPos(f);ta(k,f)}}aa()}}else if(k=g(f))if(f.target==k.icon)pa(f);else{t=k.lst;var J=k.data.id;M=t.salad;f.ctrlKey||h(M);x=na(f,k);if(f.shiftKey){if(S(t,k,1),ma&&ma.lst==t){J=k;var Q=k.pos-qc,ja=0<Q,ra;0>Q&&(Q=-Q);Q++;for(ra=Q;0<ra;){var qb=k.pos+(ja?-1:1)*(Q-ra),Eb=t.ada.getItem(qb);S(t,J,Eb,qb);J&&=t.rowSibling(J,ja);ra--}}}else x&&!M[J]?S(t,k,1):(S(t,k,0),x||(t.sel=null));!x||ma&&f.shiftKey||Xa(k)}else f.ctrlKey||f.shiftKey||(k=La("ListView",f.target))&&h(k.salad)}
function Qa(f,k){k=f.button;if(k==fa)if(f.clientX<2*w.body.clientWidth/3){if(k=g(f))f.r=k,Ka||fc(k),f.lv=k.lst,f.sy=f.lv.scrollTop,oa=f}else oa=0;else k==da?Ka||fc():k!=ha||Ka||mc||qd.md(f)}
function kb(f){if(f.button==fa){var k=0,x=oa;if(!x)return;var u=x.lv,v=x.r;v&&u&&(f.srcElement==x.srcElement&&u.scrollTop==x.sy&&x.clientX==x.clientX&&x.clientY==x.clientY&&na(x,v)&&(k=1,chrome.tabs.create({url:v.lv.href||"about:blank",active:!1}),ka=u.scrollTop,u.onscroll=E,setTimeout(u.onclick=function(){u.onscroll=0;u.onclick=va},300),Date.now(),nc(),xa(v)),oa=0);
k||Ka||fc()}Ka&&f.button==ha&&(oc(),aa())}
function E(f){f.srcElement.scrollTop=ka}
function z(f){if(f.ctrlKey||f.shiftKey||Ka||mc)ec(f);else{var k=f.target.href;"add"==k&&(k="平典搜索");f.dataTransfer.setData("url",k);$a&&($a.classList.remove("sorting"),$a=0);Ka&&(Ka=0,Hb.hidden=1);if(f=g(f)){k=f.lst;var x=k.salad;x[f.data.id]||h(x);S(k,f,1);$a=f;Xa(f);fc(f)}}}
function L(f){if(f=g(f))Hb||(tb=N(0,0,0,"position:absolute;height:25px;width:50px;background:#2196f3e3;color:#FFF;z-index:9;border-radius:30px;left:10px;text-align:center;z-index:10;pointer-events:none;"),Hb=N(0,0,0,"position:absolute;bottom:0;width:100%;height:39px;background-image:linear-gradient(rgba(0, 0, 0, 0), rgb(90 90 90 / 68%));color:#fff;z-index:9;pointer-events:none;"),N("P",Hb,0,"position:absolute;width:100%;font-size:1em;bottom:0;text-align:center;line-height:0;").innerHTML=K("i")),tb.innerText=
Object.keys(f.lst.salad).length||1,Hb.hidden=0,Ka=f,f=H("tabs"),f.insertBefore(Hb,f.firstChild),f.insertBefore(tb,f.firstChild),w.body.addEventListener("mousemove",V)}
function aa(){Ka&&(Ka=0,Hb.remove(),tb.remove(),w.body.removeEventListener("mousemove",V),ub&&(ub.classList.remove(rc),ub=0),$a.classList.remove("sorting"),$a=0,fc())}
function V(f){if(!Jb(nb.d)){var k=w.elementFromPoint(f.clientX,f.clientY);if(k=g(k)){var x=k.getBoundingClientRect();x=f.clientY>x.y+x.height/2?"drag-below":"drag-above";if(ub!=k||rc!=x)ub&&ub.classList.remove(rc),ub=k;ub.classList.add(rc=x)}}tb.style.left=f.clientX-tb.offsetWidth/2+"px";tb.style.top=f.clientY-tb.offsetHeight+"px"}
function P(f,k,x){var u=f.tP;f.onmousedown=Qa;f.onmouseup=kb;var v={size:k.length,ni:u.ni,bifun:d,getItem:function(y){return k[this.ni?k.length-1-y:y]},
sort:function(y,t){for(var F=[],M=0;M<k.length;M++){var O=k[this.ni?k.length-1-M:M],R=y[O.id];if(R&&(R.pos=M,R.ver=f.ver,F.push(O.id),0>=--t))break}return F},
dPos:function(y){return this.ni?k.length-y:y},
rPos:function(y){return this.ni?k.length-1-y:y},
d4sa:function(y,t,F){var M=this.rPos(t.pos),O=k[M];if(O&&O.id==y)return O.pos=M;M=-1;if(!F)for(F=0;O=k[F++];)if(O.id==y)return t.pos=this.dPos(F),this.d4sa(y,t,1);return M}};
f.dVer=x;f.ver=v;f.arr=k;f.ada=v;A.resetLv=()=>{f.reset(v,u.pos||0,u.offset)};
f.reset||p.initListView(f,v,30,"px",A);f.reset(v,u.pos||0,u.offset);pc()}
var ka,oa,qa=-1,ma,qc,$a,ub,rc,Ka,Hb,tb,Ic=p.menuPageBkmk||0,qd={};sc(qd,1,1,g,f=>La("ListView",f.target,c));
Fb={init:function(f,k){function x(G,J){G=G.target;F.ni=!F.ni;null!=t.sel&&(t.sel=t.arr.length-1-t.sel,F.pos=t.sel);J&&(F.pos=0);F.offset=0;P(t,t.arr);U(G,F,!0);t.scrollTop+5<t.scrollHeight-t.offsetHeight&&(t.scrollTop-=t.offsetHeight/2)}
var u=N(0,0,"UiTab"),v=N(0,N(0,u,"UiHead"),0,"display:flex;justify-content:space-between;"),y=N(0,u,"UITabo"),t=N(0,y,"ListView"),F=0;F||(y=tc(f),Ya(y,G=>{F=Ab[f.id]=G||{};t.tP=F;U(O,F);k()}));
A.lv=t;y=N(0,v,"folder-icon","padding-left:5px;");N(0,y,"item-icon");y.style.opacity="0.5";var M=u.etLoca=N("INPUT",v,0,"width:100%");u.etSch=N("INPUT",v,0,"width:65%;margin-left:3px;");u.etSch.placeholder="consider donation to help development";v=N("DIV",v,"tools");var O=N("BUTTON",v,"btn");O.id="top";O.innerText="⇧";O.title=K("6");O=N("BUTTON",v,"btn");O.id="bottom";O.innerText="⇩";O.title=K("1o");O=N("BUTTON",v,"btn");O.innerText="☆";O.id="add";u.star=O;u.reStar=()=>{(G=>{setTimeout(()=>{G.title=
sa?.parentId==f.path?K("v"):sa?K("ap"):K("qk");Ia(G,sa?"★":"☆")},200)})(u.star)};
u.reStar();t.act=G=>{F.pos=F.offset=0;for(var J=t.arr,Q=0;Q<J.length;Q++)if(J[Q].id==G){t.tada=t.ada.ni?J.length-1-Q:Q;F.pos=t.tada-2;break}P(t,J)};
O.oncontextmenu=G=>{T(G);Rb(J=>{uc(u,J)})};
O=N("BUTTON",v,"btn");O.id="sort";O.oncontextmenu=G=>{T(G);x(G,1)};
F&&U(O,F);v.onclick=function(G){var J=G.target;"sort"==J.id?x(G):"top"==J.id?(F.pos=F.offset=0,P(t,t.arr)):"bottom"==J.id?(F.pos=F.offset=0,F.pos=t.arr.length-1,P(t,t.arr)):"add"==J.id&&Rb(Q=>{D(Q||{url:ia.url,title:ia.title},t,Q?void 0:f.path)})};
M.reload=function(G,J){Ob(null,f);J&&(f.title=J);J=u.taEl;var Q=G.startsWith("q="),ja=Ga("title",J);Ia(ja,f.title||K("ij"));Ja(Ga("tabx",J),Q?"⌕&nbsp;":"★");Q||chrome.bookmarks.get(G,function(ra){ra&&ra.length&&(ja.innerText=ra[0].title)});
f.path=G;p.pullBkmk(G,function(ra){P(u.lv,ra,Ob(ra,f,G))})};
M.onkeydown=function(G){if("Enter"==G.key){var J=M.value+"";if(J.startsWith("recent"))f.path=J,Ob(null,f),p.pullBkmk(J,function(ja){P(u.lv,ja,Ob(ja,f,J))});
else if(G=null,G=J.startsWith("chrome://bookmarks/?id=")?parseInt(J.slice(J.indexOf("=")+1)):isNaN(J)?J.startsWith("chrome://bookmarks/?q=")||J.startsWith("q=")?decodeURIComponent(J.slice(J.indexOf("q="))):"q="+J:parseInt(J),null!==G){var Q=G+"";Q.startsWith("q=")?M.reload(Q,K("a6")+Q.slice(2)):chrome.bookmarks.get(Q,function(ja){ja&&ja.length&&M.reload(Q,ja[0].title)})}W.dirty()}};
u.lv=t;u.tD=f;u.tP=F;t.tabIndex=0;t.v=u;t.ver=0;t.tD=f;t.onclick=va;t.salad=[];A.listView=t;var R;u.onRemove=function(G){try{var J=t.fvp();J&&(F.pos=J.pos,F.offset=t.scrollTop-t.rowOffset(J),cb(tc(f),F));R=0}catch(Q){Aa(Q)}Ba=0};
t.blue=function(){R&&clearTimeout(R);R=setTimeout(u.onRemove,350)};
u.onAttach=function(){u.lv.focus();u.onResume();Ba=u.mu};
u.onResume=function(){var G=f.path,J=hb[G];J&&(!J.data&&J.stl||J.ver!=u.lv.dVer)&&p.pullBkmk(G,function(Q){P(u.lv,Q,Ob(Q,f,G))})};
F&&k();u.mu=kb;return u},
bind:P}}();
var c=Fb.init(a,()=>{p.pullBkmk(b,function(d){if(d){var g=Ob(d,a,b);p.initListView?Fb.bind(c.lv,d,g):p.loadListView(function(){Fb.bind(c.lv,d,a,g)})}else chrome.bookmarks.search(a.title,h=>{h&&(h=h[0],a.path=h.id+"");
p.pullBkmk(a.path,function(q){var n=Ob(q,a,b);p.initListView?Fb.bind(c.lv,q,n):p.loadListView(function(){Fb.bind(c.lv,q,a,n)})})})})});
c.etLoca.value=Oa(a);return c}
function Ob(a,b,c){c||(c=b.path);var d=hb[c];if(!d){if(!a)return;d=hb[c]={s:[],ver:0}}var g=d.s.indexOf(b),h=0<=g;h&&d.s.splice(g,1);if(a){if(d.s.push(b),d.data=a,d.stl=0,!h&&vb){a=[];var q=hb,n;for(n in q)if(c=q[n],c=c.s){g=!0;h=0;for(var l;g&&(l=c[h++]);)if(l.id!=b.id){var r=vb[l.id];void 0!=r&&8>=r&&(g=!1)}else g=!1;g&&a.push(n)}a.forEach(function(C){delete q[C]})}}else 0==d.s.length&&delete hb[c];
return d.ver}
function vc(a,b){return((c,d)=>{function g(E){for(var z,L=0,aa;aa=m.grid(1).el.children[L++];)if(aa.data.url===E){z=!0;break}return z}
function h(E,z,L){var aa=m.grid().el,V=L.ctrlKey;-1==z?(z=ia,L=z.pendingUrl||z.url,!z||!V&&g(L)||(m.layout([{url:L,title:z.title,favIconUrl:z.favIconUrl,tabId:z.id}],0,aa,E),B=I.v)):-2!=z&&-3!=z||chrome.tabs.query(-2==z?{currentWindow:!0}:{},function(P){for(var ka=[],oa=0,qa;qa=P[oa++];)!V&&g(qa.url)||ka.push({url:qa.url,title:qa.title,favIconUrl:qa.favIconUrl,tabId:qa.id});ka.length&&(m.layout(ka,0,aa,E),B=I.v)});
m.dirty()}
function q(E){return E.session?(z=>function(L){chrome.tabs.executeScript(L.id,{code:`var ret=${z.session};
                            for (var key in ret) {
                                sessionStorage.setItem(key, ret[key]);
                            }
                            document.documentElement.scrollTop=ret.scrollTop`},function(aa){})})(E):void 0}
function n(E,z){return 1.25>Math.abs(E-z)}
function l(E,z){chrome.tabs.update(z.id,{active:!0},function(){});
E.tabId=z.id;eb.favTabs[z.id]=E;wc(z.windowId)}
function r(E,z,L){L.navPath=d;L.navCtx={idx:I.data.indexOf(E),tmp:S.tmp,same:S.same};L.navBkmk=0;if(d.startsWith("imp_tmp")){!S.tmp||z||kb&&ua||(xc()&&m.pref("del"),kb=1);var aa=E.url;S.same?chrome.tabs.update(ia.id,{url:aa},q(E)):Sb(V=>{chrome.tabs.create({url:aa,active:!0,index:V.index+1},q(E))});
ua&&window.close()}else chrome.tabs.update(E.tabId||0,{active:!0},function(V){V?(wc(V.windowId),eb.favTabs[V.id]||(eb.favTabs[V.id]=E)):chrome.tabs.query({url:E.url},function(P){(P=P&&P[0])?l(E,P):(P=E.url.lastIndexOf("#"),0<P&&chrome.tabs.query({url:E.url.slice(0,P)},function(ka){ka&&(ka=ka&&ka[0])&&l(E,ka)}))})})}
function C(){setTimeout(()=>m.onAttach(),100)}
d=d||"imp_";var m=N(0,0,"UiTab");m.id=c.id;var D=0,B=0;m.dirty=function(){D=(I.v||0)+1};
m.f1=function(){};
m.onload=function(E){var z=eb.favPlus;z||(z=eb.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`,fixed:1,dyn:1});E.f0=m.layout([z],0,E,0);E.bin=m.bin;E.dirty=m.dirty};
m.onResume=function(){B<I.v&&(B=I.v,m.load())};
var I,U=d,na,S,Xa;m.load=function(){ab(Xa=c.path.includes("tmp")?"opt_imp":"opt_tmp",E=>{S=E||{};void 0==S.tmp&&(S.tmp=c.path.includes("tmp"));void 0==S.same&&(S.same=c.path.includes("tmp"));yc(tc(c),z=>{na=z||{};p.pullImpt(U,L=>{hb[U]=I=L;m.impd=L;D=L.v||0;m.layout(L.data);B=I.v;setTimeout(()=>{m.grid(1).el.parentElement.scrollTop=na.top},10);
setTimeout(()=>{m.grid(1).el.parentElement.scrollTop=na.top},100);
pc()})})})};
m.save=function(){var E=parseInt(m.grid(1).el.parentElement.scrollTop),z=na.top!=E&&m.grid(1).el.children.length;na.top=E;if(D>(I.v||0)){I.v=D;E=[];for(z=m.grid(1).el.firstElementChild;z;){var L=z.data;L&&!L.dyn&&E.push(L);z=z.nextElementSibling}I.data=E;p.log("saving::",U,E);p.saveImportabs(U,I);zc(tc(c),na);B=I.v}else z&&zc(tc(c),na);S.changed&&(delete S.changed,cb(Xa,S))};
m.bin=[];m.pref=function(E,z,L,aa){var V=m.grid();L=V.el;var P=Y,ka=0,oa=P.data,qa=q(oa);switch(E){case "del":Y.classList.contains("selected")&&(ka=Ac(V,P));ka||=Bc(V,P,m.bin,V.el);break;case "delSel":ka=Ac(V,P);break;case "restore":ka=Cc(V,P);break;case "moveSel":ka=Dc(V,P);break;case "selAll":Ec(V);break;case "open":Sb(ma=>{chrome.tabs.create({url:oa.url,index:ma.index+1,active:!aa.ctrlKey},qa)});
break;case "addThis":h(!P||P.fixed?0:P.nextSibling,-1,aa);break;case "addWnd":h(!P||P.fixed?P:P.nextSibling,-2,aa);break;case "addAll":h(!P||P.fixed?P:P.nextSibling,-3,aa);break;case "saveSession":Sb(ma=>{chrome.tabs.executeScript(ma.id,{code:"var ret={};\n                                for (var i = 0,key; i < sessionStorage.length; i++) {\n                                    ret[key=sessionStorage.key(i)] = sessionStorage.getItem(key);\n                                }\n                                ret.scrollTop = parseInt(document.documentElement.scrollTop);\n                                JSON.stringify(ret)"},
function(qc){oa.session=qc[0];m.dirty()})});
break;case "restoreSession":aa?qa(ia):Ta(oa.session);break;case "uniImp":return Db.uniImp=!z,1;case "tweak":return Db.tkImp=z,1;case "topImp":return Db.topImp=z,L.f0&&(L.f0.remove(),L.f0=m.layout([L.f0.data],0,L,z?L.firstChild:0)),1;case "isTmp":return S.tmp=!!z,S.changed=1;case "isSame":return S.same=!!z,S.changed=1;case "multi":return P&&V.els(P)||(Db.mtImp=z),1;case "copyUrl":Ta(oa.url);Ub(oa.url);break;case "openInCurrent":Sb(ma=>{chrome.tabs.update(ma.id,{url:oa.url},function(){qa&&qa(ma);ua&&
void 0!=aa&&window.close()})});
break;case "openInNewTab":Vb(oa.url,function(ma){ma&&0<ma.length?(chrome.tabs.update(ma[0].id,{active:!0}),qa&&qa(ma[0])):chrome.tabs.create({url:oa.url},qa)});
break;case "openInBackgroud":Sb(ma=>{chrome.tabs.create({url:oa.url,index:ma.index+1,active:!1},qa)});
break;case "openInIframe":L=p.newTab(zb,oa.url,Wb,W);L.title=oa.title;Xb(Zb([L],0,nb.nextSibling));W.dirty();break;case "topImp1":E=oa.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`};m.layout([E],0,L,P.nextElementSibling);break;case "pinTop":ka=Fc(V,P,1);break;case "pinBot":ka=Fc(V,P);break;case "goTop":X.grid(1).el.parentElement.scrollTop=0;break;case "goBot":X.grid(1).el.parentElement.scrollTop=X.grid(1).el.parentElement.scrollHeight}$b();
ka&&m.dirty();return 1};
var xa=p.menuPageImp||0;m.oncontextmenu=function(E){for(var z=E.target,L=z.S;!L&&z&&!z.classList.contains("item-sqr");)z=z.parentNode;Y=z;var aa=z.data;z||(L=1);L=m.grid();aa=0==xa?["",[0,"open",[K("m"),aa.url]],,[0,"addThis",K("62"),1,,[0,"addWnd",K("my")],[0,"addAll",K("7")]],[0,hc(aa.url,ia.url)?"saveSession":0,K("bz"),1,[0,aa.session?"restoreSession":0,K("eb")]],[0,"topImp1",K("n")],[0,"pinTop",K("bo")],[0,"pinBot",K("fm")],[0,"del",K("rx"),m.bin.length,[0,"restore",K("4")]],[0,"multi",K("66"),
Db.mtImp||L.els(z),[0,"moveSel",K("qg")],[0,"delSel",K("i9")],[0,"selAll",K("56")]],[1,c.path.includes("tmp")?"isTmp":0,K("y"),S.tmp],[1,c.path.includes("tmp")?"isSame":0,K("k4"),S.same]]:["",[0,"openInCurrent",K("k4")],[0,"openInNewTab",K("m")],[0,"openInBackgroud",K("tb")],[0,"openInIframe",K("fb")],[0,"goTop",K("6")],[0,"goBot",K("1o")],[0,"copyUrl",K("jk")]];ic(aa,m.pref,E,z,m.oncontextmenu,[K("7l"),K("h")],xa,V=>{p.menuPageImp=xa=V;m.oncontextmenu(E)});
Pb=E;if(kc()){z=lc();if(Hc=H("open",z))Hc.oncontextmenu=V=>{T(V);m.pref("openInCurrent")};
Hc=H("addSep",z);if(Hc=H("openInCurrent",z))Hc.title=K("aape"),Hc.oncontextmenu=V=>{T(V);m.pref(Hc.id)};
if(Hc=H("restoreSession",z))Hc.title=K("2"),Hc.oncontextmenu=V=>{T(V);m.pref(Hc.id)}}};
var pa,va,Qa;Ma("mousedown",function(E){pa=E.clientX;va=E.clientY;Qa=m.grid(1).el.parentNode.scrollTop},1,m);
var kb;Ma("mouseup",function(E){if(n(pa,E.clientX)&&n(va,E.clientY)&&n(Qa,m.grid(1).el.parentNode.scrollTop)){for(var z=E.target,L=z.S;!L&&z&&!z.classList.contains("item-sqr");)z=z.parentNode;var aa=z.data;if(E.button==fa){var V=q(aa);Sb(P=>{chrome.tabs.create({url:aa.url,active:!1,index:P.index+1},V);!S.tmp||E.ctrlKey||kb&&ua||(Y=z,xc()&&m.pref("del"),kb=1)});
nc()}}},1,m);
m.dblclick=function(E,z){E=z.data;"add"!=E.url&&chrome.tabs.create({active:!0,url:E.url,index:ia.index+1},function(L){})};
m.click=function(E,z){var L=z.data;if("add"==L.url)h(z,-1,z);else{for(E=E.target;E&&!E.classList.contains("item-sqr");)E=E.parentNode;Y=E;r(L)}};
A.initGridTab?(initGridTab(A,w,m),C()):bc("gridtab.js",function(){p.initSortable&&!Lb?(p.initSortable(w,A),initGridTab(A,w,m),C()):p.loadSortable(function(){p.initSortable(w,A);initGridTab(A,w,m);C()})});
return m})(a,b)}
function Jc(a,b){var c=a.firstChild;if(c)return c;for(;a&&a!=b;){if(c=a.nextSibling)return c;a=a.parentNode}}
function Kc(a){a=a.path;a.startsWith("sch:")&&(a=a.slice(4));return a}
function Lc(a,b,c,d,g){p.putSchKey(b);if(!d||b)a?(b=a.replace("%s",b),c?chrome.tabs.update(ia.id,{url:b}):chrome.tabs.create({url:b,active:!g})):chrome.search.query({text:b,disposition:"NEW_TAB"}),ua&&!g?window.close():Mc()}
var Nc;function Oc(a,b){function c(){l=Kc(a);h.schEng.innerText=l||K("c")}
function d(r,C){r=r.value.trim()||h["1"].value.trim()||h["2"].value.trim();r!=n.key&&(n.key=r,cb(g,n));Lc(l,r,C)}
b=N(0,0,"UiTab");b.innerHTML='\n        <div class="UiHead">\n        \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div id="pasteIt" style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;" title="获取手机上的剪贴板数据，\n 当安卓无限词典处于前台无需复制只需选择，\n 当处于后台需要打开悬浮按钮。\n点击此处粘贴至浏览器内部的输入框">\n\t\t\t\t\t新的搜索&ensp;\n\t\t\t\t</div>\n                <textarea id=\'1\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="11" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="12" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n            \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;">当前页搜索&ensp;</div>\n                <textarea id=\'2\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="21" title="搜索">\ud83d\udd0d</button>\n                    <button class="btn" id="22" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="23" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n\t\t\t\n            <div class="divider">\n\t\t\t    <HR style=\'margin:15px;opacity:.8;\'>\n                <span class="dividerTitle" id="dt"></span>\n            </div>\n\t\t\t\n            <div style="height:18px;display:flex;flex-direction: row;position:fixed; bottom:0; width:100%; user-select:none; cursor: pointer;">\n                <div id="schEng" class="tools" style="height:30px;width: 100%;font-size:10px;padding-left:5px;color:#888">\n                    默认搜索引擎\n                </div>\n            </div>\n            \n        </div>\n        <div class="UITabo">\n            <div class="ListView" id="key"></div>\n        </div>';
for(var g="v_"+pb.id+"_"+a.id,h={},q=b,n={};q=Jc(q,b);)q.id&&(h[q.id]=q);var l;c();b.et=h["1"];b.et1=h["2"];Ia(h.dt,a.title);N("SPAN",0,"tabx").innerText="";q=N(0,0,"item-icon");N(0,q,"img web").style.backgroundImage=Pc(a.path.slice(4));q.style="display: inline-block;transform: translateY(4px);";h.dt.insertBefore(q,h.dt.firstChild);h["11"].onclick=function(){d(h["1"])};
h["21"].onclick=function(){d(h["2"],!0)};
h["22"].onclick=function(){d(h["2"])};
h.schEng.onclick=function(){var r=prompt("输入搜索引擎地址，用%s代替关键词：",l);void 0!=r&&r!=l&&(a.path="sch:"+r,c(),W.dirty())};
Ma("keydown",function(r){"Enter"!==r.key||r.shiftKey||(T(r),d(r.target))},0,h["1"]);
Ma("keydown",function(r){"Enter"!==r.key||r.shiftKey||(T(r),d(r.target,!0))},0,h["2"]);
Ma("input",function(r){Qc=h["2"].value},0,h["2"]);
b.onAttach=function(){Cb==Rc&&setTimeout(()=>{h.schEng.click()},250);
Nc||(Nc=N(0,0,"sch-pane"),Mc());h.key.append(Nc);Sc(r=>{h["2"].value=r})};
b.onRemove=function(){};
Va(g,r=>{if(r=r[g])n=r,h["1"].value=r.key||"";Sc(C=>{h["2"].value=C})});
return b}
function Tc(a,b){a=N(0,0,"UiTab");var c=N("IFRAME",a);b.includes(":")||(b="https://"+b);c.src=b;c.style.width="100%";c.style.height="100%";return a}
function Uc(a,b){return((c,d)=>{function g(){return l}
function h(m){m=m.src;n.shadow.innerHTML=m;q.s=n.shadow;var D=m.indexOf("<script>");0<=D&&(D=m.slice(D+8,m.lastIndexOf("</script>")),eval("(()=>{"+D.replace("_bg()",g.name+"()")+"})()"))}
var q=N(0,0,"UiTab disp0"),n=N(0,q);n.src=d;n.style.width="100%";n.style.height="100%";n.shadow||(n.shadow=n.attachShadow?n.attachShadow({mode:"open"}):N(0,n));q.d=c;var l,r=tc(c),C=r+"_";q.k=r;q.tmps=p.d();q.toast=Ub;q.isPopup=ua;q.dataToClipboard=Ta;q.onRemove=()=>{if(l.view.onSave)l.view.onSave();if(l.changed){var m={};Object.assign(m,l);delete l.changed;delete m.changed;delete m.view;delete m.src;cb(l.view.k,m)}};
q.reload=m=>{h(m)};
Va([r,C],m=>{q._bg=l=m[r]||{};l.view=q;l.src=m[C];delete l.changed;if(l.src)h(l);else if("百度高级搜索"==c.title){var D=new XMLHttpRequest;D.open("GET","assets/百度高级搜索.html",!!l);D.onreadystatechange=function(B){4===D.readyState&&200===D.status&&(l.src=D.responseText,h(l))};
D.send()}});
return q})(a,b)}
function Ta(a){function b(c){document.removeEventListener("copy",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("copy",b,!0);document.execCommand("copy")}
function Vc(a){function b(c){document.removeEventListener("paste",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("paste",b,!0);document.execCommand("paste")}
function bc(a,b,c){c?b():(c=document.createElement("script"),c.type="text/javascript",c.onload=b,c.src=a,document.body.appendChild(c))}
var Wc;function Xc(a){p.initSortable(w,A);Wc=new Sortable(W,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabH",root:!0,forceFallback:!1,sort:!0,onMove(b){var c=300;1.5<Math.abs(W.dragScroll-W.scrollTop)&&(c=0,W.dragScroll=W.scrollTop);this.options.animation=c;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){Wc.did(b)&&W.dirty();this.options.animation=300},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;A.disani=0;W.dragScroll=W.scrollTop},click(b){},trace:function(){console.log("trace"+Error().stack)}});
a&&(Wc._onTapStart(a),a.constructor==DragEvent?Wc._onDragStart(a):Wc._onDrop(a),Yc(a,1))}
var Lb=1;function Yc(a,b){Wc?a&&(b?W.lazyS=a.target.ondragstart=void 0:Yc(a,1)):p.initSortable&&!Lb?Xc(a):p.loadSortable(function(){Xc(a)})}
Zc();document.ondblclick=function(a){var b=a.target;b==W?Wc&&Wc.multiDrag._deselectMultiDrag(0,1):X&&X.contains(b)&&X.dblclick&&X.dblclick(a,b)};
var $c={};
document.onkeydown=function(a){var b=a.key;if(!$c[b]){$c[b]=1;var c=a.target;"gridview"==c.id&&(c=c.parentElement.parentElement);c.grido&&(c=c.grido());if(c.S){var d=0;a.ctrlKey?"a"==b?(Ec(c.S),d=1):"z"==b&&(Cc(c.S),d=1):"Delete"==b&&(Ac(c.S,0),d=1);if(d){c.dirty();h(a);return}}var g;if(Z){var h=0;if("Escape"==b)h=1;else if(1==a.key.length)for(b=Z.cards[0],g="&"+a.key.toLowerCase();b=Jc(b);)if(b.id&&b.id.includes(g)){b.click();h=1;break}h&&($b(),T(a))}else if(ad()||bd||a.ctrlKey||a.shiftKey||(c=
w.activeElement,d=a.keyCode,(c?.ada||c==w.body)&&(65<=d&&90>=d||48<=d&&57>=d||"A"<=d&&"Z">=d||"a"<=d&&"z">=d)?g=1:" "==b&&(g=1)),g)if(h(a),a=" "!=b,cd(1,0,a),a)etSearch.value=b,etSearch.dispatchEvent(new Event("input",{bubbles:!0}));else if((a=p.schTabKey)&&etSearch.value!=a||dd)etSearch.value=a,etSearch.dispatchEvent(new Event("input",{bubbles:!0}))}};
document.onkeyup=function(a){$c[a.key]=0};
var ed,fd;function gd(){p.initTabs(function(a,b,c){var d=!ed;zb={};if(0==a.length){var g=0;function B(I,U,na){void 0===na&&(na=Rc);var S="v"==I;S&&(g+=100,I="");I=p.newTab(zb,I,na,0,U,924+g+a.length+1);S&&(I.br=1);a.push(I)}
if(b.name==K("ts")||2==b.t0){var h=new XMLHttpRequest;h.open("GET","assets/default_sch_engines.js",!1);h.onreadystatechange=function(I){4===h.readyState&&200===h.status&&eval(h.responseText.replaceAll("doit",B.name))};
h.send();b.t0=2}else if(b.name==K("sk")||3==b.t0)B("recent",0,Ra),B("",0,hd),B("",K("c"),Rc),B("imp_tmp",K("ja"),Sa);else if("tabs1"==b.id||1==b.t0)B("0",0,Ra),B("1",0,Ra),B("2",0,Ra),B("recent",0,Ra)}if(b.type==id&&c.bar){for(var q=[],n={},l=a.length-1;0<=l;l--){var r=a[l];r.pos=l;r.auto&&r.type==Ra&&(a.splice(l,1),n[r.path]=r);zb[r.id]=r}function B(I){if(void 0!=I.dateGroupModified){I=I.id;var U=n[I];U?(delete n[I],delete zb[I]):(U=p.newTab(zb,I,Ra,0,0,I),U.auto=1);q.push(U)}}
B({dateGroupModified:1,id:"1",title:K("r4")});for(l=0;l<c.bar.length;l++)B(c.bar[l]);for(l=0;l<a.length;l++)q.splice(a[l].pos||0,0,a[l]);a=q;for(var C in n)l=n[C],delete zb[C],db(tc(l,b)),l.type==hd&&db(tc(l,b)+"_")}rb=0;sb=void 0===c.scroll?null:parseInt(c.scroll)||0;pb=b;vb=c.hots||{};wb=Db.expTab=c.exp;xb=c.one;yb=c.rec;void 0===yb&&(yb=0);jb.innerText="";nb=X=gb=0;ob=[];Ab=b.tPs||{};var m=d?W:W.cloneNode();b=W;ba=wb?6:3;ua&&(ba=wb?6:4);ed=Math.ceil(fd*ba);m.style.maxHeight=ed+"px";jd(m);m.bin=
kd;var D=0;m.dirty=function(){D=eb.tabsVer+1};
m.save=function(){if(D>eb.tabsVer){eb.tabsVer=D;fb.length=0;for(var B=m.firstElementChild;B;){var I=B.d;I&&fb.push(I);B=B.nextElementSibling}fb.now=gb.id;p.saveTabs(pb,fb,()=>{})}B=parseInt(xb?W.scrollLeft:W.scrollTop);
if(pb&&vb&&(rb||B!=sb&&ua&&(yb||void 0!=sb))){I="v_"+pb.id+"__";rb=0;sb=yb?B:B=void 0;var U=fb.indexOf(nb.d)||0;0>U&&(U=0);zc(I,{tix:U,hots:vb,scroll:B,exp:wb,rec:yb,one:xb})}};
fb=a;gb=0;c=Zb(fb,c.tix,0,m);gb||(gb=a[0],c=m.firstElementChild,c==lb&&(c=c.nextElementSibling));m.append(lb);m.style.minHeight="";m.ada={};d||(ld.observe(m),m.style.position="absolute",m.style.visibility="hidden",mb.insertBefore(m,W),W=m,md(),ld.unobserve(b));Xb(c,1);lb.fixed=1;m.oncontextmenu=nd;W.onclick||(Wc=0,Zc());rd.dirty||sd();d?setTimeout(()=>{fd=Math.max(lb.offsetHeight,W.firstElementChild.offsetHeight);ed=Math.ceil(fd*ba);m.style.maxHeight=ed+"px";m.MH=ed;md();td()},1):td();
d||(m.style.position="",m.style.visibility="",b.remove())},ua?0:window)}
gd();function ud(a){var b=Object.create(Object.getPrototypeOf(a));Object.getOwnPropertyNames(a).forEach(function(c){var d=Object.getOwnPropertyDescriptor(a,c);Object.defineProperty(b,c,d)});
return b}
function Zb(a,b,c,d){var g=d||W;d||(c||=lb);for(var h=0,q=0;q<a.length;q++){var n=a[q];d&&(a[q]=n=ud(n));var l=n.type,r=n.title,C=n.ico;r||(l==Ra&&(r=n.path?.startsWith("recent")?K("8867"):K("ij")),l==Sa&&(r=n.path?.includes("tmp")?K("ja"):K("zk")),l==vd&&(r="无限词典"),l==hd&&(r=K("be")));C||(l==Ra&&(C=n.path.startsWith("q=")?"⌕&nbsp;":"★"),n.type==Wb&&(C="\ud83c\udf10"),n.type==Rc&&(C="\ud83c\udf10"));l=N("LI",0,"tab");n.type==wd&&(l.classList.add("tab-sep"),n.path&&(l.style=n.path));if(C){var m=
N("SPAN",l,"tabx");(1<C.length?Ja:Ia)(m,C)}n.type==Rc&&n.path&&(m.innerText="",l.con=N(0,l,"item-icon"),l.icon=N(0,l.con,"img web"),l.icon.style.backgroundImage=Pc(n.path.slice(4)));let D=N("SPAN",l,"tabx title");(n.type==wd?Ja:Ia)(D,r);n.type!=Ra||Jb(n)||chrome.bookmarks.get(n.path,function(B){B&&B.length&&(D.innerText=B[0].title)});
l.ondblclick=xd;l.oncontextmenu=nd;l.id="tab_"+n.id;zb[n.id]=n;Wc||(l.draggable=!0,l.ondragstart=Yc);l.d=n;d&&vb&&(r=1/(ca+1),C=vb[n.id],void 0!=C&&(l.classList.add("tab-hot"),l.style.setProperty("--bg",yd(132,175,255,255,255,255,999==C?.85:r*C)),l.lev1=C,999!=C&&ob.push(l)));c&&c.parentNode==g?g.insertBefore(l,c):g.append(l);n.type==wd&&n.br&&(r=N("div",0,"flex-break"),g.insertBefore(r,l),r.fixed=l.fixed=1,r.fix=l.fix=1,l.br=r);h||(void 0!=b?q==b&&(gb=n,h=l):h=l)}d&&(ob.sort(function(D,B){return-D.lev1+
B.lev1}),zd());
return h}
const md=a=>{a=W.scrollHeight>ed;var b=W.style;!a^"visible"==b.overflowY&&(b.overflowY=a?"scroll":"visible",b.minHeight&&(b.minHeight=""))},ld=new ResizeObserver(md);
ld.observe(W);var kd=[];function Ad(a){if(a.shiftKey||a.altKey||a.ctrlKey)W.lazyS&&W.lazyS(a);else{var b=La("tab",a.target,W);b?(Xb(b),rb=1,clearTimeout(W.saving),W.saving=setTimeout(Bd,800)):Wc&&a.target==W&&Wc.multiDrag._deselectMultiDrag(0,1)}}
lb.onclick=function(a){Y=0;Cd(a)};
function xd(a){if(!a.ctrlKey&&!a.shiftKey){for(a=a.srcElement;a&&!a.classList.contains("tab");)a=a.parentNode;wb=!wb;Dd(a)}}
function Ed(a){return a&&a.parentNode==W&&a!=lb}
function Dd(a){ba=wb?6:3;ua&&(ba=wb?6:4);W.MH=ed=Math.ceil(fd*ba);W.style.maxHeight=ed+"px";md()}
function Fd(a){if(Ed(a)){var b={};Object.assign(b,a.d);var c=a.cloneNode(1);c.onclick=Ad;c.ondblclick=xd;c.oncontextmenu=nd;b.id=p.newTabid(zb,W.children.length);Wc||(c.draggable=!0,c.ondragstart=Yc);c.d=b;W.insertBefore(c,a.nextSibling);Xb(c)}}
function Bc(a,b,c,d){if(!b.fixed||b.fix){d=c?{e:b,idx:[].indexOf.call(d.children,b)}:{};var g=a?a.els().indexOf(b):-1;~g&&(a.els().splice(g,1),d.sel=1);b.remove();c&&c.push(d);return!0}}
function Ac(a,b,c){if(a&&(b=a.els(),b.length)){a.el.bin.push({es:b.concat(),idx:[].indexOf.call(a.el.children,b[0])});a=0;for(var d;d=b[a++];)if(d.remove(),d.br&&d.br.remove(),c)try{c(d)}catch(g){Aa(g)}b.length=0;return!0}}
function Fc(a,b,c){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var d=a.els();d.length||(d=[b]);if(d.length){b=0;for(var g;g=d[b++];)g.remove();for(b=0;g=d[b++];)c?a.el.insertBefore(g,a.el.firstElementChild):a.el.append(g);return!0}}}
function Dc(a,b){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var c=a.els();if(c.length&&-1==c.indexOf(b)){for(var d=0,g;g=c[d++];)g.remove();b=b.nextElementSibling;for(d=0;g=c[d++];)a.el.insertBefore(g,b),b=g.nextElementSibling;return!0}}}
function Cc(a,b){if(a){var c=a.el.bin.pop();if(c){var d=a.el,g=d.children[c.idx||0];if(b=c.e)d.insertBefore(b,g),c.sel&&a&&a.els().push(b);else{b=c.es;c=0;for(var h;h=b[c++];)d.insertBefore(h,g),a&&a.els().push(h);b=b[0]}return b}}}
function Ec(a){if(a){var b=a.els(),c=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||(b.push(d),d.classList.add("selected"))}}
function Gd(a){if(a){var b=a.els(),c=b.length=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||d.classList.remove("selected")}}
function ic(a,b,c,d,g,h,q,n){Y=d;kc()?(Z=Hd(0,a,b),Id(c),h?setTimeout(()=>Jd(h,q,n),5):Kd&&Kd.remove()):bc("settings.js",function(){initSettings(A,w,"settings.css");
kc()&&g(c)});
ec(c)}
function Qb(){gb?.type==Ra&&Rb(()=>X.reStar())}
function Ld(a,b){var c=a.d.path,d=function(g){Nb(a);if(a.d==gb&&X&&X.onResume)X.onResume();Qb()};
Rb(g=>{!g||b.ctrlKey?chrome.bookmarks.create({parentId:c,url:ia.url,title:ia.title,index:b.shiftKey?0:void 0},d):g.parentId!=c?chrome.bookmarks.move(g.id,{parentId:c,index:b.shiftKey?0:void 0},d):Ub("已经添加到该文件夹！<br>"+K("4e"))})}
function Tb(a,b){chrome.bookmarks.get(b.path,function(c){if(c=c?c[0]:0)$b(),uc(a.tabView,c)})}
function uc(a,b){if(b){if(b.parentId==a?.lv.tD.path)a.lv.act(b.id);else{for(var c,d=0,g;g=W.children[d++];)if(g.d?.path==b.parentId&&g.type==Ra){c=g;break}c?Xb(c):(c=p.newTab(zb,b.parentId,Ra,W),Xb(Zb([c],0,a.taEl.nextSibling)));rb=1;c&&(W.dirty(),setTimeout(()=>{X.lv&&X.lv.act(b.id)},500))}xb&&td(1)}}
function Cd(a){var b=Y,c=["",[0,["tabFav",0],[K("1")],1,,[0,"tabRec",K("8867"),1]],[0,["tabImp",0],[K("zk")],1,,[0,"tabTmp",K("ja"),1]],[0,"tabSch",K("ax"),1],[0,"tabWeb",K("fb"),1],[0,["tabCustomX",0],[K("p")],1,,[0,"tabBaidu",K("百度高级搜索"),1],[0,"tabCustom",K("be"),1]]];ic(c,Md,a,b,Cd);if(kc()){a=lc();if(b=H("tabImp",a))b.title=K("右击保存到新的位置"),b.oncontextmenu=d=>{Md("tabImp");T(d)};
if(b=H("tabTmp",a))b.title=K("右击保存到新的位置"),b.oncontextmenu=d=>{Md("tabTmp");T(d)}}}
function nd(a){Wc||Yc(a);if(window.oncontextmenu==ec)ec(a);else{for(var b=a.target,c=b==W;!c&&b&&!b.classList.contains("tab");)b=b.parentNode;c||fc(b);if(b==lb)b.onclick(a);else{c=b.d.type==Ra;var d=gc(b.d),g=b.d.type==Rc,h=b.d.type==Sa,q=b.d.type==Wb;c=["",[0,d?["addFav",0]:0,[K("qk")],1,,[0,d?["newFavFolder",0]:0,[K("g")],1],[0,d?["openLocatedFoler",0]:0,[K("j")],1]],[0,g?["schNew",0]:0,K("9v"),1,[0,g?["schThis",0]:0,K("r7"),1]],[0,q||g||c?["openWeb",0]:0,K("m"),1],[0,b.d.type==hd?["&editSrc",
0]:0,K("qy"),1],[0,h?["setTemp",0]:0,[K("bg")],1],[0,b.d.type==wd?["brSep",0]:0,[K("切换换行")],1],[0,["copyUrl",0],[K("z2")],1],[0,["newTab",0],[K("cv")],1,,[0,["dupTab",0],[K("r")]],[0,["newSep",0],[K("s")]]],[0,["closeTab",0],[K("un")],kd.length,[0,["resumeTab",0],[K("o")]]],[0,["multiTab",0],[K("u3")],Db.mt||Wc&&Wc.els(b),[0,["moveTabs",0],[K("3")]],[0,["selTabs",0],[K("56")]]],[1,"oneRow",[K("单行标签栏")],xb],[1,"expTab",[K("xe")],wb],[1,ua?"recPos":0,[K("25")],yb]];ic(c,Md,a,b,nd);if(kc()){Z.e=a;a=
lc();if(b=H("selTabs",a))b.title=K("u"),b.oncontextmenu=n=>{Gd(Wc);T(n);$b()};
if(b=H("copyUrl",a))b.title=K("3w"),b.oncontextmenu=n=>{T(n);Nd()},b.onmousedown=n=>{1==n.button&&(T(n),Od())};
if(b=H("addFav",a))b.title=K("4e");if(b=H("addImp",a))b.title=K("4e");if(b=H("schNew",a))b.oncontextmenu=n=>{Md("schNew");T(n)};
if(b=H("schThis",a))b.oncontextmenu=n=>{Md("schThis");T(n)};
if(b=H("newSep",a))b.title=K("右击换行"),b.oncontextmenu=n=>{Md("newSep");T(n)}}}}}
function Od(){var a=Y,b=a.d;if(gc(b))chrome.bookmarks.get(b.path,function(g){if(g=g?g[0]:0)$b(),bc("assets/dialog.js",function(){var h=showDialog(w,w.body);Ia(h.t,"Edit");Ja(h.t1,cc("NAME"));Ia(h.btn0,"Save");var q=Fa("TEXTAREA",h.t1);q[0].value=g.title;h.btn0.onclick=()=>{var n=q[0].value;chrome.bookmarks.update(b.path,{title:n},l=>{l&&(Ia(Ga("tabx title",a),n),h.x())})};
h.btn1.onclick=()=>{h.x()}},A.showDialog)});
else{var c=Y.d.title,d=prompt("标题：",c);d!=c&&void 0!=d&&($b(),W.dirty(),(b.type==wd?Ja:Ia)(Ga("tabx title",a),b.title=d),Nb(a))}}
function Nd(){var a=Y,b=a.d,c=Oa(Y.d),d=prompt("请输入新地址（可以是书签url或者http网址）",c),g="v_"+pb.id+"_"+b.id,h=d!=c;if(d){$b();function n(l,r){Ua.remove(g);var C=b.id;Object.keys(b).forEach(function(m){delete b[m]});
b.id=C;b.type=q;b.title=l;q==Sa&&(d.startsWith("important://")&&(d=d.slice(12)),d.startsWith("imp_")||(d="imp_"+d));b.path=d;h&&W.dirty();l=a.nextElementSibling;Bc(Wc,a,0,W);Zb([b],0,l);a==nb&&Xb(a);Nb(a,r)}
if(d.startsWith("chrome://bookmarks")||!isNaN(d)){var q=Ra;n(e[0].title,350)}else d.startsWith("imp")?(q=Sa,c=b.type==q?b.title:0,b.path.includes("tmp")!=d.includes("tmp")&&(c=0),n(c)):d.startsWith("custom")?(q=hd,c=b.type==q?b.title:0,n(c||K("be"))):d.startsWith("sch:")?(q=Rc,n(Pd(d,!0)||K("ax"))):(q=Wb,n(Pd(d,!0)))}}
function Pd(a,b){var c=a,d=c.indexOf(":");for(0<=d&&(c=c.slice(d+1));c.startsWith("/");)c=c.slice(1);d=c.indexOf(".");if(0<d){if(a=c.slice(0,d),"www"==a){var g=c.indexOf(".",d+1);0<g&&(a=c.slice(d+1,g))}}else a=c;b&&(a=a.toUpperCase());return a}
function Qd(a){a.delay?setTimeout($b,10):$b()}
function yd(a,b,c,d,g,h,q){a=Math.round(a*(1-q)+d*q);b=Math.round(b*(1-q)+g*q);c=Math.round(c*(1-q)+h*q);return"rgb("+a+" "+b+" "+c+")"}
const Ra=0,Sa=1,vd=2,Wb=4,hd=5,Rc=6,wd=7;
function Xb(a,b){if(Ed(a))if(a.d&&a.d.type!=wd){if(nb){nb.classList.remove("tab-now");var c=X;c&&!c.hidden&&(c.hidden=1,Rd(),c.style.display="none")}nb=a;if(vb){var d=ca;c=1/(d+1);var g=ob.indexOf(a);0<g&&ob.splice(g,1);ob.push(a);ob.length>d&&(d=ob.shift(),delete vb[d.d.id],d.lev1=999,d.style.setProperty("--bg",yd(132,175,255,255,255,255,.85)));a.classList.add("tab-hot");d=ob.length-1;for(g=d-1;0<=g;g--){var h=ob[g];vb[h.d.id]=h.lev1=d-g;h.style.setProperty("--bg",yd(132,175,255,255,255,255,c*(d-
g)))}}a.classList.add("tab-now");d=gb=a.d;c=a.tabView;if(!c){c=d.type;try{c==Ra?(c=Kb(d,d.path,a),c.taEl=a):c=c==Sa?vc(d,d.path):c==vd?newTabPlainDict(d,d.path):c==Wb?Tc(d,d.path):c==hd?Uc(d,d.path):c==Rc?Oc(d,d.path):""}catch(n){console.error(n),c=""}c||=N(0,jb,0,"错误");a.tabView=c}(d=X!==c)&&(X=c);g=c.parentNode!=jb;if(c.hidden||g){if(c.hidden=0,c.style.display="",g&&jb.append(c),c.onAttach)try{c.onAttach()}catch(n){Aa(n)}}else if(d&&c.onResume)try{c.onResume()}catch(n){Aa(n)}if(xb)b?td():(b=a.offsetWidth,
c=a.offsetLeft,d=W.scrollLeft,g=W.clientWidth,h=null,d>c+b/2+9?h=a.offsetLeft:d+g<c+2*b/3+9&&(h=c-g+b),null!==h&&W.scrollTo({left:h,behavior:"auto"}));else{c=a.offsetHeight;d=a.offsetTop+c;g=W.scrollTop;h=W.clientHeight;var q=null;d<g+c/2+9?q=a.offsetTop:d>g+h&&(q=d-h);null!==q&&W.scrollTo({top:q,behavior:b?"auto":"smooth"})}}else Xb(a.nextElementSibling)}
A.onfocus=function(a){if(A._blr&&(A._blr=0,X&&X.onResume))X.onResume()};
A.onblur=function(a){A._blr=1;Rd(1);Bd();Sd()};
A.onbeforeunload=function(){Td();Rd(1);W.save();Sd();ua||delete p.bkWnds[ia.id]};
function Md(a,b,c,d){function g(){$b();if(q){var m=Zb([q],0,Y?.nextElementSibling);Xb(m);rb=dd=h=1;"tabCustom"==a&&Ud(Y=m)}h&&W.dirty()}
var h=0,q=0,n=Y?.d;switch(a){case "addFav":Ld(Y,d);break;case "newFavFolder":chrome.bookmarks.get(n.path,function(m){if(m=m?m[0]:0){var D=m.title||"",B=D.replace(/\d+$/g,function(I){return(parseInt(I)+1).toString()});
(D=prompt("新建文件夹",B!==D?B:D+" 1"))&&chrome.bookmarks.create({parentId:m.parentId,title:D,index:m.index+1},function(I){I&&(q=p.newTab(zb,I.id,Ra,W),g(),W.save())})}});
return;case "openLocatedFoler":return Tb(Y,n),1;case "newTab":return Cd(Z.e),1;case "tabFav":q=p.newTab(zb,sa?sa.parentId:"0",Ra,W);break;case "tabRec":q=p.newTab(zb,"recent=1000",Ra,W);break;case "tabImp":case "tabTmp":var l="tabImp"==a;if(d)q=p.newTab(zb,l?"imp_":"imp_tmp",Sa,W);else{b=l?K("zk"):K("ja");var r=l?"important://":"important://tmp";Vd(m=>{var D=m[0].value;m=m[1].value;D=(l?"imp_":"imp_tmp")+(D.startsWith(r)?D.slice(r.length):"");q=p.newTab(zb,D,Sa,W);q.title=m;g()},r,b)}break;
case "tabAll":q=p.newTab(zb,"all",Sa,W);q.title="全部页面";break;case "tabSch":q=p.newTab(zb,"sch:",Cb=Rc,W);q.title=K("ax");setTimeout(()=>{Cb=0},250);
break;case "tabPDict":q=p.newTab(zb,"",vd,W);break;case "tabWeb":b=prompt("输入网址：","");if(void 0!=b)b=b||"about:blank",q=p.newTab(zb,b,Wb,W,Pd(b,!0));else return;break;case "tabBaidu":q=p.newTab(zb,"custom://",hd,W,"百度高级搜索");break;case "tabCustom":q=p.newTab(zb,"custom://",hd,W,K("be"));break;case "schNew":case "schThis":Sc(m=>Lc(Kc(Y.d),m||X.et1?.value||X.et?.value,"T"==a[3],!0,!d));
break;case "setTemp":p.setTmpUrlPath(n.path);break;case "openWeb":var C=n.path;n.type==Rc&&(C=(new URL(C.slice(4))).origin+"");n.type==Ra&&(C=Oa(n));Vb(C,function(m){m&&0<m.length&&!d.ctrlKey?chrome.tabs.update(m[0].id,{active:!0}):Sb(D=>{chrome.tabs.create({active:!d.ctrlKey,url:C,index:D.index+1})})});
break;case "copyUrl":b=Oa(Y.d);Ta(b);Ub(b);Nb(Y);break;case "dupTab":Fd(Y);h=1;break;case "&editSrc":Ud(Y);break;case "newSep":q=p.newTab(zb,"",wd,W,"&emsp;&emsp;");d||(q.br=1);break;case "brSep":(b=!Y.br)?(b=Y.br=N("div",0,"flex-break"),W.insertBefore(b,Y),b.fixed=Y.fixed=1,b.fix=Y.fix=1):Y.br&&(Y.br.remove(),Y.br=Y.fixed=Y.fix=0);n.br=b;h=1;break;case "oneRow":xb=b;rb=1;jd(W);setTimeout(()=>td(1),10);
break;case "expTab":Db[a]=wb=b;rb=1;Dd(Y);break;case "recPos":yb=b;rb=1;break;case "closeTab":if(Y.classList.contains("selected"))h=Ac(Wc,Y,m=>{n=m.d;Ua.remove(tc(n));n.type==hd&&Ua.remove(tc(n)+"_")});
else if(b=Wc&&nb==Y?nb.previousElementSibling||W.firstElementChild:0,h=Bc(Wc,Y,kd,W))Xb(b),Ua.remove(tc(n)),n.type==hd&&Ua.remove(tc(n)+"_"),Y.br&&Y.br.remove();dd=1;break;case "resumeTab":(h=Cc(Wc,Y))&&Xb(h);dd=1;break;case "moveTabs":h=Dc(Wc,Y);break;case "selTabs":Ec(Wc);break;case "multiTab":return Yc(),Y&&Wc&&Wc.els(Y)||(Db.mt=b),1;default:return Db[a]=b,1}g();return 1}
var Wd,Z,Y,jc,Pb,Kd;
function Id(a,b){if(b){if(window.e=a,kc()){b=Z.style;Z.p.style.display="block";b.visibility="";var c=a.clientX,d=a.clientY;b.maxHeight="";if(Z.revert)b.right=A.innerWidth-c+5+"px",b.bottom=A.innerHeight-d+5+"px";else{var g=Z.parentNode.offsetWidth,h=Z.parentNode.offsetHeight;c+Z.offsetWidth/2>g&&(c=g-Z.offsetWidth/2,d+=2);b.left=c+"px";d+Z.offsetHeight>=h+45&&Z.offsetHeight/2>h-d&&150>h-d?(b.bottom=h-d+5+"px",b.top=b.maxHeight="",c=Z.cards[0].style,c.display="flex",c.flexDirection="column-reverse",
b.maxHeight=Z.parentNode.offsetHeight-(h-d+5)+"px",setTimeout(()=>{Z.cards[0].firstElementChild.scrollIntoView()},5)):(b.maxHeight=Z.parentNode.offsetHeight-d-5+"px",b.top=d+"px")}}}else setTimeout(()=>{Id(a,1)},5)}
function ec(a){T(a)}
function Hd(a,b,c){if(Wd){if(a&&Wd.n===a)return Wd.p.parentNode||document.body.append(Wd.p),Wd;Wd.parentNode&&Wd.remove()}var d=H("menup");d||(d=N(0,document.body),d.id="menup",d.onmousewheel=function(q){q.srcElement==d&&$b()},d.onmouseup=function(q){var n=q.target;
n===d?$b():1==g.type&&(T(q),2==q.button&&(A.oncontextmenu=ec),n.classList.contains("sep")||n==g||(q.delay=!0,Qd(q)),2==q.button&&oc())});
var g=N(0,d,"menu","max-width:35%;overflow:overlay;overflow-x:hidden;visibility:hidden"),h=g;h.cards&&(h.cards.forEach(function(q){q.remove()}),h.cards=0);
SettingsBuildCard(c,b,h);g.n=a;g.l=b;g.p=d;return Wd=g}
function $b(){Z&&(Z.p.style.display="none",jc&&jc(Z),Z=null)}
if(ua)chrome.tabs.query({active:!0,lastFocusedWindow:!0},function(a){if(ia=a[0])Rb(b=>{}),la&&la()});
else{var Hc=document.title;document.title+=Math.random();chrome.tabs.query({title:document.title},function(a){if(ia=a[0])Rb(b=>{}),p.bkWnds[ia.id]=1;
document.title=Hc;ia.title=Hc})}function pc(){}
setTimeout(function(){ib.remove();ib=0},95);
ua||chrome.runtime.onMessage.addListener(function(a,b,c){if("focus"==a.name)A.onfocus();if("blur"==a.name)A.onblur()});
wb&&Dd();var rd=H("tabgroup"),Xd,Yd;function sd(){rd.dirty||(rd.dirty=()=>{rd._dirty=p.verTG+1;rd._dirty<=p.verTG&&(p.verTG=0,rd._dirty=1)},Ma("mousewheel",function(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;
(b=Math[1<=b?"floor":"ceil"](b))&&rd.scrollTo({left:rd.scrollLeft+80*b,behavior:"auto"});T(a)},1,rd));
Ya("tab_groups",a=>{a&&a.constructor===Array||(a=[]);0==a.length&&(a.push({id:"tabs",name:K("r4"),type:id}),a.push({id:"tabs1",name:K("fz")}),a.push({id:"tabs2",name:K("ts"),t0:2}),a.push({id:"tabs3",name:K("sk"),t0:3}));Xd=a;Zd(Xd)})}
function $d(a){Sd();a=a.target;a.d&&(a.d.id==pb.id?td(1):(Yd&&Yd.classList.remove("sel"),Bd(),ae(a.d),a.classList.add("sel"),Yd=a))}
function ae(a){Rd(1);Bd();Sd();pb=a;vb=0;zc("sel_tab_gp",pb,()=>gd())}
function Bd(){W.save()}
function zc(a,b,c){ua?cb(a,b,c):(sessionStorage.setItem(a,JSON.stringify(b)),c&&c())}
function yc(a,b,c){if(ua||c)Ya(a,b);else{c=sessionStorage.getItem(a,null);try{c=JSON.parse(c)}catch(d){c=0}c?b&&b(c):yc(a,b,1)}}
function Zd(a){rd.innerHTML="";N(0,rd,"tgpd");for(var b=Yd=0,c;c=a[b++];){var d=N(0,rd,"tg");d.innerText=c.name;d.id="tg_"+c.id;d.d=c;d.onclick=$d;d.oncontextmenu=be;ce||(d.draggable=!0,d.ondragstart=de);c.id==pb.id&&(Yd=d,pb=c,d.classList.add("sel"))}N(0,rd,"tgpd");Yd&&requestAnimationFrame(()=>{rd.scrollLeft=Yd.offsetLeft-(rd.offsetWidth-Yd.offsetWidth-45)/2})}
const ee=0,id=1;function fe(a,b,c){function d(C,m,D){r=Xd.indexOf(n);0>r?r=Xd.length:r++;for(var B=0,I=0,U;U=Xd[I++];)U=1+(parseInt(U.id.slice(4))||0),U>B&&(B=U);var na=B;Ya("rcy_bin_tg",S=>{function Xa(Qa){if(!xa[Qa]&&!H("tg_tabs"+(Qa||"")))return B=Qa,l={id:"tabs"+(B||""),name:C,type:D||ee,t0:m},Xd.splice(r,0,l),ae(l),h(),1}
S=S||[];for(var xa={},pa=0,va;void 0!=(va=S[pa++]);)va=va.id||va,va?.slice&&(va=parseInt(va.slice(4))||0,xa[va]=1);for(S=0;!Xa(B)&&S<na+1024;)S++,B=S})}
function g(C){r=Xd.indexOf(n);q=1;if(C){Xd.splice(r,1);if(n.id==pb.id){(l=Xd[r])||(l=Xd[r-1]);if(!l){d(K("w"));return}ae(l)}Ya("rcy_bin_tg",m=>{m=m||[];if(25<=m.length+1)for(var D=m.splice(0,10),B=0;B<D.length;B++){var I=D[B].id||D[B]+"";H("tg_tabs"+(I||""))||(p._DEBUG&&(za("delete tabgroup #"+I),Wa(I)),Ua.remove(I))}m.push(n);cb("rcy_bin_tg",m)});
Ya(n.id,m=>{"string"===typeof m&&(m=JSON.parse(m));if(m)for(var D=0,B;B=m[D++];)Ua.remove(tc(B,n))});
Ua.remove("v_"+n.id+"__");h()}else r++,Ya("rcy_bin_tg",m=>{m=m||[];l=m.pop();Xd.splice(r,0,l);ae(l);h();cb("rcy_bin_tg",m)})}
function h(){$b();if(q||l)rd.dirty(),Zd(Xd)}
var q=0,n=Y.d,l,r;switch(a){case "rename":if(a=prompt(K("qqef"),n.name))n.name=a,q=1;break;case "newGroup":(a=prompt(K("b"),K("86")))&&d(a,3);return;case "ngpEmpty":d(K("w"));return;case "ngpBar":d(K("r4"),0,id);return;case "ngpBkmk":d("bookmarks",1);return;case "ngpSch":d(K("ts"),2);return;case "close":g(!0);return;case "restore":g(!1);return;default:return Db[a]=b,1}h();return 1}
function be(a){if(window.oncontextmenu==ec)ec(a);else{Sd();for(var b=a.target,c=b==rd;!c&&b&&!b.classList.contains("tg");)b=b.parentNode;c=["",[0,["rename",0],[K("ye")],1],[0,["newGroup",0],[K("x")],1,,[0,["ngpEmpty",0],[K("w")]],[0,["ngpBar",0],[K("r4")]],[0,["ngpBkmk",0],[K("ij")]],[0,["ngpSch",0],[K("ts")]]],[0,["close",0],[K("5")],1,[0,["restore",0],[K("u1")]]]];ic(c,fe,a,b,be);if(kc()){Z.e=a;if(a=H("selTabs",lc()))a.title=K("u"),a.oncontextmenu=d=>{Gd(Wc);T(d);$b()};
if(a=H("rename",lc()))a.onmousedown=d=>{1==d.button&&(T(d),d.target.click())}}}}
function Sd(){if(rd._dirty>p.verTG){for(var a=[],b=0,c;c=rd.children[b++];)c.d&&void 0!=c.d.id&&a.push(c.d);cb("tab_groups",a,()=>{p.verTG=rd._dirty})}}
var ge=-1,he;function ie(){clearTimeout(ge);var a=H("toastview");a.style.opacity=0;ge=setTimeout(function(){ge=-1;a.style.display="none"},300)}
function Ub(a,b,c,d,g){-1!=ge&&clearTimeout(ge);d||(d=w.body);var h=H("toastview");h||(h=N(0,d),h.id="toastview",N(0,h).id="toasttext");var q=h.parentNode;q!=d&&(q&&h.remove(),d.appendChild(h));d=h.firstChild;d.innerHTML=a;d.className=1<=b?"warn":"info";ge=setTimeout(ie,c||1E3);setTimeout(function(){h.style.opacity=1},16);
h.style.display="block";d.style.opacity=g||1}
function Nb(a,b){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},b||599)}
var Qc;
function Sc(a){if(Qc)a(Qc);else{var b=ia.pendingUrl||ia.url,c=(new URL(b)).searchParams,d=c.get("q")||c.get("wd")||c.get("search")||c.get("searchkey")||c.get("keyword")||c.get("query")||c.get("sokeytm")||c.get("char")||c.get("text")||c.get("queryField_a")||c.get("w")||c.get("q1")||c.get("terms")||c.get("term");null===d&&(c=b.indexOf("zdic.net/hans/"),0<c&&(d=b.slice(14)),0>c&&(c=b.indexOf("dictionary/"),0<c&&(d=b.slice(11))),0>c&&(c=b.indexOf("/zh/"),0<c&&(d=b.slice(4))),0>c&&(c=b.indexOf("/search/"),0<
c&&(d=b.slice(c+8))),d&&(c=d.indexOf("?"),0<c&&(d=d.slice(0,c))));null===d&&(d="");d=decodeURIComponent(d).replace(/\+/g," ");ua?chrome.tabs.executeScript(ia.id,{code:"window.getSelection().toString()"},function(g){g&&g[0]?a(g[0]):a(d)}):a(d)}}
function tc(a,b){return"v_"+(b||pb).id+"_"+a.id}
function Pc(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return'url("chrome://favicon/'+a+'")'}
function je(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return"chrome://favicon/"+a}
function ke(a){for(var b=0,c=0,d=0,g=a.length/4,h=0;h<a.length;h+=4)b+=a[h],c+=a[h+1],d+=a[h+2];return"rgb("+Math.round(b/g)+","+Math.round(c/g)+","+Math.round(d/g)+")"}
function le(a){for(var b={},c=0,d=null,g=0;g<a.length;g+=4){var h=a[g],q=a[g+1],n=a[g+2];255==a[g+3]&&(h=h+","+q+","+n,b[h]?b[h]++:b[h]=1,b[h]>c&&(c=b[h],d=h))}return"rgb("+d+")"}
var ce;function me(a){p.initSortable(w,A);ce=new Sortable(rd,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabG",root:!0,forceFallback:!1,sort:!0,anisk:1,onMove(b){this.options.animation=300;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){ce.did(b)&&rd.dirty()},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;A.disani=0},click(b){$d(b)},trace:function(){console.log("trace"+Error().stack)}});
a&&(ce._onTapStart(a),a.constructor==DragEvent?ce._onDragStart(a):ce._onDrop(a),de(a,1))}
function de(a,b){ce?a&&(b?rd.onclick=a.target.ondragstart=void 0:de(a,1)):p.initSortable&&!Lb?me(a):p.loadSortable(function(){me(a)})}
function cc(a){return`<div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">
            <div style="white-space:nowrap;font-size:.89em;padding-right:10px;text-align:center;padding-top:7.9px;">${a}</div>
            <textarea class='eta' style="flex:1;resize:vertical;min-height:30px;font-size: large;padding-left: 17px; padding-top: 10px;"></textarea>
        </div>`}
function gc(a){return a.type==Ra&&!a.path.startsWith("q=")&&!a.path.startsWith("recent")}
function Jd(a,b,c){function d(l){Ga("hot",Kd)?.classList.remove("hot");l.target.classList.add("hot");c(l.target.idx)}
var g=Z.style;if(!Kd){Kd=N(0,0,"tabG");var h=Kd.style;h.position="fixed";h.height="auto";h.background="white";h.borderRadius="4px";h.transform="scale(0.9)";h.transformOrigin="left";h.boxShadow=getComputedStyle(Z.cards[0]).boxShadow}h=Kd.style;Kd.innerText="";for(var q=0;q<a.length;q++){var n=N(0,Kd,"tg"+(b==q?" hot":""));n.idx=q;Ia(n,a[q]);n.onclick=d}h.left=parseInt(g.left)+1.5+"px";g.top?(h.bottom=Z.parentNode.offsetHeight-parseInt(g.top)-.75+"px",h.top=""):(h.top=Z.parentNode.offsetHeight-parseInt(g.bottom)+
"px",h.bottom="");H("menup").insertBefore(Kd,Z)}
function kc(){return!!A.SettingsBuildCard}
function lc(){return Z.shadowRoot||w}
function Nb(a){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},599)}
function Rb(a){chrome.bookmarks.search({url:ia.url},function(b){a(sa=b?b[0]:0)})}
function Sb(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(ia=b?b[0]:0)})}
function Vb(a,b){chrome.tabs.query({url:a},b)}
function Td(){var a=eb.bkmks.indexOf(hb);0<=a&&eb.bkmks.splice(a,1)}
function Mb(a){return void 0!=a.dateGroupModified}
function hc(a,b){try{return(new URL(a)).hostname===(new URL(b)).hostname}catch(c){}}
function ne(a){X.et.value=a.target.innerText}
function Mc(){p.getSchKeys(a=>{Nc.innerHTML="";for(var b=a.length-1;0<=b;b--){var c=a[b],d=N(0,Nc,"sch-item");d.onclick=ne;Ia(d,c)}})}
function Vd(a,b,c){bc("assets/dialog.js",function(){var d=showDialog(w,w.body);Ia(d.t,"Edit");Ja(d.t1,cc(K("路径").toUpperCase())+cc(K("lx").toUpperCase()));Ia(d.btn0,"Save");var g=Fa("TEXTAREA",d.t1),h=b,q=c;g[0].value=b;g[0].oninput=function(n){n=n.target;n.value.startsWith(h)?b=n.value:n.value=b;g[1].value==c&&(c=g[1].value=q+b.slice(h.length))};
g[1].value=c;d.btn0.onclick=()=>{h="xyz";a(g);d.x()};
d.btn1.onclick=()=>{d.x()}},A.showDialog)}
function Ud(a){bc("assets/dialog.js",function(){var b=showDialog(w,w.body);Ia(b.t,"Edit");Ja(b.t1,cc("CODE"));Ia(b.btn0,"Save");var c=a.tabView,d=c?._bg,g=Fa("TEXTAREA",b.t1);dc(g[0]);c?(g[0].value=d.src,b.btn0.onclick=()=>{var h=g[0].value;cb(c.k+"_",h,q=>{d.src=h;c.reload(d);b.x()})}):Ya(tc(a.d)+"_",h=>{g[0].value=h;
b.btn0.onclick=()=>{var q=g[0].value;cb(tc(a.d)+"_",q,n=>{b.x()})}});
b.btn1.onclick=()=>{b.x()}},A.showDialog)}
function ac(){return navigator.userAgent.includes("Edg/")}
function oe(a){var b=La("result",a.target),c=Ga("up",b);a.clientX>=c.getBoundingClientRect().left?pe(Ga("title",b).innerText):(Xb(b.el,1),cd(),W.scrollTop=b.el.offsetTop-b.el.offsetHeight)}
function qe(a){var b=La("result",a.target),c=Ga("up",b);a.clientX>=c.getBoundingClientRect().left?(pe("t: "+Ga("tabx",b).innerText),re()):(chrome.tabs.update(b.d.id,{active:!0}),wc(b.d.windowId))}
function se(a){p.schTabKey=a;dd=0;var b=a;if("t"!=b[0]||":"!=b[1]&&" "!=b[1]){a=a.trim();(n=A._py&&/[a-z]/g.test(a))&&(n=A._py_cp(a));b=0;for(var c,d=W.children;c=d[b++];)if(c!=lb){var g=Ga("title",c).innerText;if(n&&_py(g,n)||!n&&g.includes(a)){g=N(0,te,"result tab");var h=N(0,g);h.style="display:flex;align-items:center;gap:1px;";h.style.flex="1";var q=c.cloneNode(1);g.el=c;g.d=c.d;[].slice.call(q.children).forEach(l=>{h.append(l)});
g.onclick=oe;g.oncontextmenu=nd;c=N(0,g,"up");c.innerText="︿";c.style="transform:translateY(-15%);"}}}else{a=a.slice(2).trim();var n=A._py&&/[a-z]/g.test(a);n&&=A._py_cp(a);chrome.tabs.query({},function(l){for(var r=0,C;C=l[r++];){var m=C.title;if(n&&_py(m,n)||!n&&m.includes(a)){var D=N(0,te,"result tab"),B=N(0,D);B.style="display:flex;align-items:center;gap:1px;";B.style.flex="1";N(0,B,"tabx").innerText=m;D.d=C;D.onclick=qe;C=N(0,D,"up");C.innerText="︿";C.style="transform:translateY(-15%);"}}})}ue(te.firstElementChild)}
var ve,te,bd=se,we,dd;bd=0;function ue(a){a!=we&&(we&&we.classList.remove("hot"),a&&a.classList.add("hot"),we=a)}
function pe(a){etSearch.value=a;etSearch.dispatchEvent(new Event("input",{bubbles:!0}))}
function re(){etSearch.select();var a=etSearch.value;if("t"==a[0]&&(":"==a[1]||" "==a[1])){var b=" "==a[2];a=getSelection();a.modify("extend","backward","line");a.modify("move","forward","character");a.modify("move","forward","character");b&&a.modify("move","forward","character");a.modify("extend","forward","line")}}
function cd(a,b,c){if(a){if(!ve){ve=H("search-box");te=Ga("results",ve);te.innerHTML="";Ma("input",g=>{var h=etSearch.value;te.innerHTML="";/[a-z]/g.test(h)?bc("assets/pinyin.js",()=>bd(h),A._py):bd(h)},1,etSearch);
var d=ve.parentNode;Ma("keydown",g=>{"Escape"==g.key&&cd()&&T(g);"Enter"==g.key&&(we&&we.click(),T(g));"ArrowUp"==g.key&&(ue(we?.previousElementSibling||we),T(g));"ArrowDown"==g.key&&(ue(we?.nextElementSibling||we),T(g))},1,d);
Ma("mousemove",g=>{ue(La("result",g.target))},1,te);
Ga("icon-close",ve).onclick=()=>etSearch.value="";
d.onclick=g=>{g.target==ve.parentNode&&cd()}}b||=se;
if(bd==b)return}d=ve.parentNode.style;if(a||"none"!=d.display)return d.display=a?"":"none",a&&(etSearch.focus(),c||(etSearch.select(),setTimeout(()=>{re()},200))),bd=b,ua&&(p.popSching=!!b),1}
function ad(){var a=w.activeElement;if(a&&(a.shadowRoot&&(a=a.shadowRoot.activeElement),a=a?.tagName,"INPUT"==a||"TEXTAREA"==a))return 1}
function zd(){ua&&p.popSching&&(cd(1),etSearch.value=p.schTabKey,etSearch.dispatchEvent(new Event("input",{bubbles:!0})))}
function wc(a){chrome.windows.update(a,{focused:!0},function(b){})}
var xe,ye,ze,Ae,Be=-1,Ce,mc,De={},Ee,Fe,Ge,He;
function sc(a,b,c,d,g){return(()=>{function h(l){if(void 0!=l.clientX){xe=l;var r=d(l)}else l=xe,r=d(document.elementFromPoint(l.clientX,l.clientY));r?mc||=r:(c&&(r=q(l)),r||=mc);if(r){-1==Be&&(Be=n(mc));if(-1==Ee&&(b&&r.pos!=Be||3<Math.abs(De.y0-l.clientY))){ye.lazyS&&W.lazyS(l,1);c?(Ee=n(r),ye=r.lst||g(l),He=ye.topPos()):(Ee=-100,Fe=r);var C=ye,m=C.append;Ae||=N(0,0,"BoxSel");m.call(C,Ae);ye.style.position="relative";Ma("scroll",h,Da,ye)}if(-1!=Ee){var D=ye;m=De.x;var B=l.clientX;C=De.y;var I=D.scrollTop+
l.clientY-Ge;l=B-m;var U=I-C;0>U&&(U=-U,C=I);0>l&&(l=-l,m=B);c&&(Ee=n(r),D.topPos()!=He&&(Be<r.pos?(C=0,U=I):(C=I,U=D.scrollHeight+5)));D=Ae.style;m+=ye.scrollLeft;D.top=C+"px";D.left=m+"px";D.height=U+"px";D.width=l+"px";fc(r)}}}
var q=l=>{},n=b?l=>l.pos:l=>99;
c&&(q=l=>{if(l=g(l)){var r=l.findRow(l.ada.size-1);if(r&&r.offsetTop<l.scrollTop+l.offsetHeight)return r}});
a.mv=h;a.md=function(l){if(l.button==ha&&!Z){var r=d(l),C=r;r?Ce=0:(r=q(l),Ce=!!r);if(r||!c)C&&(mc=r),ye=C=r?.lst||g(l),Ma("mousemove",h,Da,w.body),Ee=Be=-1,De.x=l.clientX,Ge=C.getBoundingClientRect().y,De.y0=l.clientY,De.y=C.scrollTop+De.y0-Ge,fc(r),A.box=a}};
a.mu=function(l){if(l.button==ha&&ye){var r=l.altKey;if(-1!=Ee){Ce&&mc==ze&&!d(xe)&&(mc=0);if(mc)try{var C=ye;if(c){var m=Be,D=Ee;Be>Ee&&(m=D,D=Be);var B;l=0;var I=1,U=C.topPos(),na=C.salad;r=r?0:1;for(B=m;B<=D;B++){var S=C.ada.getItem(B);I&&B>=U&&(l=C.findRow(B),I=0);l&&(l.pos==B?Ib(l,"selecting",r):l=0);r?na[S.id]={pos:B,id:S.id,e:l}:delete na[S.id];l&&=C.rowSibling(l)}}else{m=W.S.els();D=parseInt(Ae.style.left);I=parseInt(Ae.style.top);var Xa=D+Ae.offsetWidth,xa=I+Ae.offsetHeight;B=0;for(var pa;pa=
C.children[B++];){var va=pa.offsetLeft,Qa=pa.offsetTop,kb=va+pa.offsetWidth,E=Qa+pa.offsetHeight;if(pa.d&&!(kb<=D||va>=Xa||E<=I||Qa>=xa)&&r^!pa.classList.contains("selected")){var z=m.indexOf(pa);r?0<=z&&m.splice(z,1):0>z&&m.push(pa);Ib(pa,"selected",!r)}}}}catch(L){Aa(L)}Ee=-1;oc();Na("scroll",h,Da,ye);fc();Ae.remove()}Na("mousemove",h,Da,w.body);mc=0;Be=-1;ye=0}}})()}
function oc(){A.oncontextmenu=ec;setTimeout(function(){A.oncontextmenu=0},20)}
var Ie;function Zc(){Ie||(Ie={},sc(Ie,0,0,a=>La("tab",a.target||a,W),a=>W));
W.lazyS=function(a,b){if(b||a.ctrlKey||a.shiftKey)(b||a.target!=W)&&Yc(a),W.lazyS=0};
W.onclick=Ad;W.onmousedown=Ie.md}
function fc(a){ze!=a&&(Ib(ze,"hot"),ze=a,Ib(ze,"hot",null!=a))}
function Je(a){A.box&&A.box.mu(a);Ba&&Ba(a)}
function Rd(a){if(X?.onRemove)try{X.onRemove(a)}catch(b){Aa(b)}}
Ma("mouseup",Je,1,w);function Ke(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;(b=Math[1<=b?"floor":"ceil"](b))&&W.scrollTo({left:W.scrollLeft+80*b,behavior:"auto"});T(a)}
function jd(a){var b=a.style;xb?(b.overflowX="auto",b.flexFlow="nowrap",a.classList.add("r1"),Ma("mousewheel",Ke,1,a)):(b.overflowX="",b.flexFlow="wrap",a.classList.remove("r1"),Na("mousewheel",Ke,1,a))}
function td(a,b){if(xb){b||setTimeout(()=>td(a,1),5);
if(!a&&null!==sb&&ua&&yb)try{W.scrollLeft=sb;return}catch(c){}try{W.scrollLeft=nb.offsetLeft-A.innerWidth/3}catch(c){}}else{if(!a&&null!==sb&&ua&&yb)try{W.scrollTop=sb;return}catch(c){}try{W.scrollTop=nb.offsetTop-ba/3*fd}catch(c){}}}
function nc(){ua||(p.fakePP=Date.now(),chrome.browserAction.openPopup(function(a){a&&a.close();chrome.runtime.lastError}))}
function xc(){var a=Date.now();if(250<=a-Ca)return Ca=a,1}
function dc(a){a.wrap="off";a.style.minHeight=parseInt(X.clientHeight/4)+"px";setTimeout(()=>{a.focus();a.select()},35)}
;