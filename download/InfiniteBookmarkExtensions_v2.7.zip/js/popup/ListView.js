'use strict';(function(){function B(d,g,n){d=document.createElement(d);n&&(d.className=n);g&&g.appendChild(d);return d}
function t(d,g){d.hidden!=g&&(d.hidden=g,g^"none"===d.style.display&&(g?d.style.display="none":d.style.removeProperty("display")))}
function N(d,g,n){d.init=1;for(var p=0;p<n;p++)B("DIV",d,"page").style.height=g}
function D(d,g){d=B("DIV",d,"item");d.style.minHeight=g;return d}
function z(d){var g=d.nextElementSibling;return g?g.hidden?z(g):g:(d=d.parentNode.nextElementSibling)&&d.firstElementChild}
function O(d,g){var n=g?d.previousSibling:d.nextSibling;if(!n){d=d.parentNode;var p=g?d.previousSibling:d.nextSibling;p?n=g?p.lastChild:p.firstChild:(d=d.parentNode,(d=g?d.previousSibling:d.nextSibling)&&d.bk&&(p=g?d.lastChild:d.firstChild)&&(n=g?p.lastChild:p.firstChild))}return n}
window.initListView=function(d,g,n,p,E){n||=1.5;p||="em";(function(P){function F(a,c){E.select=function(){F(a)};
for(var e=b.children[0].children[0],f=q;e&&!e.hidden&&!(f+30>a);)f+=30,e=z(e);e&&(0==e.children.length&&G(e,f),b.scrollTop=H(e.children[a-f])+Math.max(5,c))}
function H(a){return a.offsetTop-(a.offsetParent==b?0:b.offsetTop)}
function C(){var a=b.firstElementChild;return b.scrollTop+(a&&a.offsetParent==b?0:b.offsetTop)}
function I(a,c,e){e?q-=c:u+=c;if(a.size!==c){a.size=c;for(var f=0;10>f;f++){var h=a.children[f],m=30*f>=c;t(h,m);if(e&&!m&&h.hide){for(m=0;30>m;m++)t(h.children[m],0);h.hide=0}}}}
function x(a){var c=b.scrollTop;if(v.size>u&&c>=.9*b.scrollHeight){a=b.children[0];for(var e=b.lastElementChild;!a.bk;)a=a.nextSibling;for(;!e.bk;)e=e.previousSibling;b.insertBefore(a,e.nextElementSibling);q+=a.size;I(a,Math.min(300,v.size-u))}else if(0<q&&c<=.2*b.clientHeight){for(a=b.children[2];!a.bk;)a=a.previousSibling;u-=a.size||0;b.insertBefore(a,b.children[0]);I(a,Math.min(300,q),1);a=a.offsetHeight+c;b.scrollTop=a}a=C();if(!r||a<r.offsetTop-10||w&&a+b.clientHeight>w.offsetTop+w.offsetHeight){e=
b.fvp();a=0;if(e){e=e.nextSibling||e;a=e.offsetTop-c;var f=e.pos}c=0;for(var h=C(),m=h+b.offsetHeight,k=0;3>k;k++){var l=b.children[k];if(l.offsetTop+l.offsetHeight>h){c=k;break}}k=0;c=q+300*c+k;l=l.children[k];for(var y=r=w=0,A=0;l&&!l.hidden;){!r&&l.offsetTop+l.offsetHeight>h&&(y=l.offsetTop,r=l);if(r)if(A)t(l,1),l.parentNode.size-=30;else if(A|=G(l,c),y+=Math.min(J,l.offsetHeight),y>m){w=l;break}c+=30;l=z(l);k++}e&&e.pos==f&&(b.scrollTop=e.offsetTop-a)}E._blr&&b.blue&&b.blue()}
function G(a,c){if(!a.init){var e=K;a.init=1;a.hide=0;a.style.height="auto";for(var f=0;30>f;f++)D(a,e)}for(e=a.hide=0;30>e;e++)f=a.children[e],c>=v.size?(t(f,1),a.hide=1):(t(f,0),f.pos=c,v.bifun(b,f,c)),c++;return a.hide}
var b=P,v=g,K=n+p,Q=30*n+p,L,J,M,q,u,r,w;b.reset=function(a,c,e){void 0!==a&&(v=a,"number"===typeof a&&(v={size:a,bifun:function(l,y,A){y.innerText=A+""}}));
var f=D(b,K);M=f.offsetHeight;f.remove();a=v.size;var h=[];b.onsroll&&b.removeEventListener("scroll",b.onsroll);b.innerHTML="";for(var m=q=u=r=w=b.scrollTop=0;3>m;m++){var k=B("DIV",b,"block");k.bk=1;0==m&&0!=k.offsetTop&&(b.ot=1);N(k,Q,10);h.push(k);f=300*m;if(f>=a)t(k,1);else if(f+300>=a)for(k.size=a-300*m,f=0;10>f;f++)t(k.children[f],30*f>=k.size);else k.size=300;u+=k.size}L=h[0].offsetHeight;J=L/10;h=c;0<h&&1>h&&(h=Math.ceil(a*c));0<c&&(c=0,c=h,900<h&&(c=300,q=Math.ceil(h/c)*c,c=h-q,u=q+900),
c*=M);x();b.addEventListener("scroll",b.onsroll=x);if(q||c)b.scrollTop+=c,r=w=0,x(),F(h,e)};
b.findRow=function(a){var c=q,e=0;if(c<=a)for(var f=0,h;3>f;f++){h=b.children[f];if(c+h.size>=a){e=h;break}c+=h.size}return e&&(c=a-c,a=Math.floor(c/30),e=e.children[a])?e.children[c-30*a]:0};
b.fvp=function(){for(var a=r,c=C()+5;a&&!a.hidden&&!(a.offsetTop+a.offsetHeight>c);)a=z(a);if(a)for(a=a.firstElementChild;a&&!(a.offsetTop+a.offsetHeight>c);)a=a.nextElementSibling;return a};
b.rowSibling=O;b.topPos=function(){return q};
b.rowOffset=H;b.addEventListener("scroll",b.onsroll=x);addEventListener("resize",function(a){b.onsroll&&x(a)})})(d)}})();