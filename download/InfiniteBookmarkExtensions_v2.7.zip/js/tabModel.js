'use strict';function newTabid(b,a){a||=0;var c=55<a?555<a?1015:110:15,d=10*Math.floor(a/10);var f=c+3;do if(a=d+Math.floor(Math.random()*c),0>--f){a=-1;break}while(b[a]);if(-1==a){do a=Math.floor(1E10*Math.random());while(b[a])}return a}
function newTab(b,a,c,d,f,e){var g={};g.type=c||0;g.path=a;void 0!=f&&(g.title=f);if(void 0==e||void 0!=b[e])e=newTabid(b,d?d.children.length:0);return b[g.id=e]=g}
var tabsLoaded=!1,popupCache={};function reinitTabs(b){popupCache={};return initTabs(b)}
function pullTabsByGroup(b,a,c){var d=a.id===popupCache.sel_id;d&&(a.tPs=popupCache.tPs,a.tPs||(a.tPs=popupCache.tPs={}));getVal([a.id],function(f){var e=f;try{e=JSON.parse(f)}catch(g){}e&&e.constructor===Array||(e=[]);e.now=a.tid||0;d&&(popupCache.tabs=e);b(e,a,c)})}
function getTabGroupSpec(b,a,c){if(b){b=b.sessionStorage.getItem(a,null);try{b=JSON.parse(b)}catch(d){b=0}b?c&&c(b):getTabGroupSpec(0,a,c)}else getVal(a,function(d){c&&c(d)})}
function initTabs(b,a){getTabGroupSpec(a,"sel_tab_gp",c=>{c&&void 0!==c.id||(c={id:"tabs",tid:0,type:1});getTabGroupSpec(a,"v_"+c.id+"__",d=>{d=d||{};1==c.type?chrome.bookmarks.getChildren("1",function(f){d.bar=f;pullTabsByGroup(b,c,d)}):pullTabsByGroup(b,c,d)})})}
reinitTabs(()=>{});
function saveTabs(b,a,c){a&&setVal(b.id||"tabs",a,function(d){c()})}
;