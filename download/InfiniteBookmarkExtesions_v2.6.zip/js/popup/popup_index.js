'use strict';var l=chrome.extension.getBackgroundPage(),ca=4;if(l.fakePP){if(400>(new Date).getTime()-l.fakePP)throw setTimeout(function(){window.close()},200),1;
l.fakePP=0}var z,da,ea,fa=location.href==`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html?popup=1`,ha=console.log,ia=console.error,B=document,G=window;G.isPopup=fa;function na(a,b){return(b||B).getElementById(a)}
function oa(a,b){return(b||B).getElementByTagName(a)[0]}
function qa(a,b){return(b||B).getElementsByTagName(a)}
function sa(a,b){return(b||B).getElementsByClassName(a)[0]}
function ua(a,b){return(b||B).getElementsByClassName(a)}
function L(a){return chrome.i18n.getMessage(a)||a}
function wa(a,b){a.innerText=b}
function xa(a,b){a.innerHTML=b}
function za(a){var b=a.path||"";a=a.type;a==Ba?b.startsWith("recent")||(/^\d+$/g.test(b)?b="chrome://bookmarks/?id="+b:(b.startsWith("q=")&&(b=b.slice(2)),b="chrome://bookmarks/?q="+b)):a==Ea&&(b.startsWith("recent")||(b="important://"+b.slice(4)));return b}
function M(a,b,c,d){a=B.createElement(a||"DIV");c&&(a.className=c);d&&(a.style=d);b&&b.appendChild(a);return a}
function Fa(a,b){try{b?a.stopImmediatePropagation():a.stopPropagation(),a.preventDefault()}catch(c){ia(c)}}
function Ga(a,b,c,d){(d||G).addEventListener(a,b,c)}
function Ha(a,b,c,d){(d||G).removeEventListener(a,b,c)}
function Ja(a){function b(c){Ha("copy",b,!0,B);Fa(c,1);c.clipboardData.setData("text/plain",a)}
Ga("copy",b,!0,B);B.execCommand("copy");Ha("copy",b,!0,B)}
const Ka=chrome.storage.local;function La(a,b){Ka.get(a,b)}
function Pa(a){Ka.get(a,b=>{console.log(b[a])})}
function Qa(a,b){La(a,c=>{b(c[a])})}
var Ra={};function Sa(a,b){Ra[a]?b(Ra[a]):Qa(a,c=>{b(Ra[a]=c)})}
function Ta(a,b){Ka.set(a,b)}
function Ua(a,b,c){var d={};d[a]=b;Ta(d,c)}
function Va(a,b){Ka.remove(a,b)}
var Xa=l.d(),$a,ab,bb={},cb=M("style",document.head);bb.reload=()=>{setTimeout(()=>{location.reload()},350)};
Xa.bkmks.push(bb);M("style",document.head).innerText=`.folder-icon > .item-icon{-webkit-mask-image:url("chrome-extension://${chrome.runtime.id}/images/folder_open.svg")}`;cb.innerText=".img,IMG,.fico{display:none!important}";var gb=na("tabos"),hb=na("tabNew"),P=hb.parentNode,ib=P.parentNode,jb,R,kb=[],lb,mb,nb,ob,pb,qb,W={},tb={},ub={},vb,wb=Xa.opt;wb||(Xa.opt=wb={autoExp:1,mcTab:1,tkImp:0,topImp:0,uniImp:1});B.title=L("sw");var xb,yb;
function Ab(a,b,c){if(a){a=a.classList;var d=a.contains(b);if(void 0===c||d^!!c)d?a.remove(b):a.add(b)}}
function Bb(a){return a.path.startsWith("recent")}
function Db(a,b){l.initListView&&!Eb||l.loadListView();xb||function(){function d(f,g,q){if(!g.t){var w=g._=g;w.classList.add("item-wrap");g.dot=M("P",w,"dot");g.con=M(0,w,"item-icon");g.icon=M(0,g.con,"img");g.lv=M("DIV",w,"item-tlv");g.t=M("P",g.lv,"item-title");g.st=M("P",g.lv,"item-subtitle");g.lv.draggable=!0;g.lv.ondragstart=ta;g.lv.ondragend=ja;g.onmousedown=K;g.ondblclick=D;g.oncontextmenu=S;g.lst=f}w=f.ada.getItem(q);var u=f.salad;w||={title:""};g.data=w;var m=w.title||" ";if(m.startsWith("(")){var t=
m.indexOf(")");0<t&&(m=m.slice(t+1).trim())}g.t.innerText=m;m=w.url;t=g.icon;g.lv.href=m;Fb(w)^g.folder&&(g.folder=!g.folder,g.folder?(g._.classList.add("folder-icon"),t.style.backgroundImage=""):g._.classList.remove("folder-icon"));var E=u&&u[w.id];Ab(g._,"selecting",E||null);E&&E.e!=g._&&(u[w.id].e=g._);Hc==w.id&&zb!=g&&Wa(zb);m?(g.st.innerText=m,g.folder||("javascript:"==m||m.startsWith("javascript:&tm=")||m.startsWith("https://separator")?t.style.backgroundImage="":(w=t.style,u=m,m=u.indexOf("/",
u.indexOf(":")+3),0<m&&(u=u.slice(0,m)),w.backgroundImage='url("chrome://favicon/'+u+'")'))):t.style.backgroundImage="";f.tada===q&&(Gb(g,15),f.tada=void 0)}
function k(f){f=f.target||f;for(var g=0;f;){if(f.data&&f.classList.contains("item")){g=f;break}if(f==B.body||f.classList.contains("ListView"))break;f=f.parentNode}return g}
function h(f){Object.keys(f).forEach(q=>{(q=f[q])&&Ab(q.e,"selecting",0)});
for(var g in f)delete f[g]}
function p(f){if(f){var g=f.tD,q=g.path;bb[q]&&(bb[q].data=0);l.pullBkmk(q,function(w){f.v.onRemove();xb.bind(f,w,Hb(w,g,q))},fa,!0)}}
function n(f){f=f.ada.dPos(X.pos+1);1==f&&Ib&&Ib.clientY-R.lv.getBoundingClientRect().y<X.offsetHeight/2-5&&(f=0);return f}
function r(f,g,q,w){var u=X.data,m=X.lst,t=m.salad,E=function(A){A&&p(m);Jb()};
switch(f){case "fold":var H=prompt(L("ca"),L("xy"));m=X.lst;if(H){var O=n(m);chrome.bookmarks.create({parentId:u.parentId,title:H,index:O},E)}break;case "addThis":O=n(m);1==O&&Ib&&Ib.clientY-R.lv.getBoundingClientRect().y<X.offsetHeight/2-5&&(O=0);Kb(A=>{!A||w.ctrlKey?chrome.bookmarks.create({parentId:u.parentId,url:z.url,title:z.title,index:O},E):chrome.bookmarks.move(A.id,{parentId:u.parentId,index:O},E)});
break;case "newFav":!w||w.ctrlKey?J(u,m,u.parentId,0,u.index+(m.ada.ni?-1:1),!0):Lb(A=>J(u,m,u.parentId,A,u.index+(m.ada.ni?-1:1)));
break;case "addSep":v(w,u,m);break;case "edit":J(u,m);break;case "replace":J(u,m,void 0,z);break;case "delete":F(u,m);break;case "openFolder":Mb(jb,{path:u.id});break;case "pinTop":(()=>{function A(ka,la,ma,Ma){db.length?(la&&(Ma=ya[la.pos],la.id==ka.id&&(la.title=ka.title),Ma==la&&(ka=ya.splice(la.pos,1)[0],la.pos<ma&&ma--,la.pos=ma,ya.splice(ma,0,ka))),I(db.shift())):E(ka||1)}
function I(ka){for(var la=0,ma=(ka.title||"").startsWith(ba),Ma;Ma=ya[la];){if(ma&&!Na&&Ma==ka){Q="";la=0;break}if(!(Ma.title||"").startsWith(ba))break;la++}chrome.bookmarks.move(ka.id,{parentId:ka.parentId,index:la},Ia=>{Q&&Ia&&!ma?chrome.bookmarks.update(ka.id,{title:Q+ka.title},Rb=>{A(Rb,ka,la)}):A(Ia,ka,la)})}
var Q="\ud83d\udccc ",ba=Q.trim(),ya=listView.arr,Na=x(u,t),db=y(u,t,Na,m);Na=1<db.length;A()})();
break;case "pinBot":(()=>{function A(ya){var Na=I.length,db=(ya.title||"").startsWith("\ud83d\udccc ");chrome.bookmarks.move(ya.id,{parentId:ya.parentId,index:Na},ka=>{db&&chrome.bookmarks.update(ya.id,{title:ya.title.slice(3)});ba.length?A(ba.shift()):E(ka||1)})}
var I=listView.arr,Q=x(u,t),ba=y(u,t,Q,m);Q=1<ba.length;ba.length?A(ba.shift()):E(1)})();
break;case "openAll":f="";for(H in t)f+=m.arr[t[H].pos].url+"{BKMKBK}";chrome.runtime.sendMessage({urls:f,type:"openAll"},function(A){});
break;case "copyUrl":Ja(u.url);Nb(u.url);break;case "openInCurrent":Fb(u)?R.etLoca.reload(u.id,u.title):chrome.tabs.update(z.id,{url:u.url},function(A){fa&&window.close()});
Aa();break;case "openInNewTab":Ob(u.url,function(A){A&&0<A.length?chrome.tabs.update(A[0].id,{active:!0}):chrome.tabs.create({url:u.url})});
Aa();break;case "openInBackgroud":Lb(A=>{chrome.tabs.create({url:u.url,index:A.index+1,active:!1})});
Aa();break;case "openInTmp":(()=>{var A=x(u,t),I=y(u,t,A,m);A=1<I.length;for(var Q=0;A=I[Q];Q++)l.addToTmpUrls(A.url,A.title||"",0,()=>{I[Q+1]||Gb(X)})})();
break;case "openInIframe":H=l.newTab(W,u.url,Pb,P);H.title=u.title;Qb(Sb([H],0,jb.nextSibling));P.dirty();break;default:return 1}Tb();return 1}
function v(f,g,q,w){w=w?"https://separator.mayastudios.com/index.php?t=horz":"javascript:";Ub()&&(w+="&tm="+Date.now());chrome.bookmarks.create({parentId:g.parentId,url:w,title:"───────────",index:q.ada.dPos(X.pos+1)},function(u){u&&(p(q),Tb(),(f.ctrlKey||1==f.button)&&J(u,q))})}
function x(f,g){return g[f.id]&&1<Object.keys(g).length}
function y(f,g,q,w){var u=w.arr,m=[],t=!1;if(q){for(var E in g)if(q=w.ada.d4sa(E,g[E]),q=u[q])t||q!=f||(t=!0),m.push(q);m.sort(function(H,O){return H.pos-O.pos})}t||m.push(f);
return m}
function J(f,g,q,w,u,m){Yb("assets/dialog.js",function(){var t=showDialog(B,B.body);wa(t.t,L("z"));xa(t.t1,Zb(L("bf").toUpperCase())+Zb(L("dv").toUpperCase()));var E=void 0!==q;wa(t.btn0,E?L("sg"):L("7"));wa(t.btn1,L("r"));var H=qa("TEXTAREA",t.t1);H[0].value=w?.title||f.title;H[1].value=w?.pendingUrl||w?.url||f.url||"";t.btn0.onclick=()=>{var O=H[1].value;m&&Ub()&&(O+=(O.includes("?")?"&":"?")+"tm="+Date.now());var A=I=>{I&&(p(g),t.s.remove());Jb()};
O={url:O,title:H[0].value};E?(O.parentId=q,O.index=u,chrome.bookmarks.create(O,A)):chrome.bookmarks.update(f.id,O,A)};
t.btn1.onclick=()=>{t.s.remove()}},G.showDialog)}
function F(f,g){var q=g.salad,w=x(f,q),u=y(f,q,w,g);Yb("assets/dialog.js",function(){var m=showDialog(B,B.body);xa(m.t,L("j"));xa(m.t1,L("vl").replace("size",u.length));wa(m.btn0,L("q2"));wa(m.btn1,L("r"));m.btn0.onclick=()=>{var t=()=>{chrome.bookmarks.remove(u.shift().id,function(){0==u.length?p(g):t();Jb()})};
t();m.s.remove()};
m.btn1.onclick=()=>{m.s.remove()}},G.showDialog)}
function S(f){if(window.oncontextmenu==$b)$b(f);else{var g=k(f);if(g){N(g);var q=g.data,w=g.lst,u=x(q,w.salad),m=ac(w.tD),t=bc(q.url,z.url);u=0==lc?["",[0,m?"addThis":0,L("9q"),1,,[0,"addSep",L("1")],[0,"fold",L("ca"),1],[0,"newFav",L("c"),1]],[0,m?0:"openFolder",L("h"),1],[0,u?"openAll":0,L("pj")],[0,"edit",L("s"),1],[0,"delete",L("t")],[0,t?"replace":0,L("ph")],[0,"pinTop",L("qi"),1],[0,"pinBot",L("tf")]]:["",[0,"openInCurrent",L("72")],[0,"openInNewTab",L("i")],[0,"openInBackgroud",L("g7")],[0,
"openInTmp",L("6")],[0,"openInIframe",L("cb")],[0,"copyUrl",L("4y")]];cc(u,r,f,g,S,[L("ee3r"),L("8")],lc,E=>{l.menuPageBkmk=lc=E;S(f)});
Ib=f;dc=function(){N()};
if(ec()){u=fc();if(g=na("addSep",u))g.title=L("9f"),g.oncontextmenu=E=>{Fa(E);v(E,q,w,!0)},g.onmousedown=E=>{1==E.button&&(Fa(E),v(E,q,w,!0))};
if(g=na("openInCurrent",u))g.title=L("右键不关闭弹窗"),g.oncontextmenu=E=>{chrome.tabs.update(z.id,{url:q.url},function(H){Tb()});
Fa(E);Aa()};
if(g=na("newFav",u))g.title=L("8n"),g.oncontextmenu=E=>{r("newFav");Fa(E)}}}}}
function aa(f,g){f.innerText=g.ni?"⇈":"⇊";f.title=g.ni?L("2u"):L("13")}
function T(f,g){g=g.icon;return f.clientX>g.offsetLeft+g.offsetWidth}
function pa(f,g,q,w){var u=f.ver;f=f.salad;g?(Ab(g,"selecting",q),q?f[g.data.id]={pos:g.pos,e:g,ver:u}:delete f[g.data.id]):void 0!=w&&(f[q.id]={pos:w,ver:u})}
function Wa(f){zb=f;f.lst.sel=Jc=f.pos;Hc=f.id}
function Aa(f){f||=X;l.navPath=f.lst.tD.path;l.navCtx={idx:f.pos,ni:f.lst.ada.ni};l.navBkmk=f.data.id}
function D(f){if(!ra){var g=k(f);if(g&&(N(g),Aa(g),T(f,g))){var q=g.data;if(g=q.url)f.shiftKey||f.ctrlKey?Lb(m=>{f.shiftKey?chrome.tabs.update(m.id,{url:q.url},function(){fa&&!f.ctrlKey&&window.close()}):f.ctrlKey&&Ob(q.url,t=>{t&&0<t.length?chrome.tabs.update(t[0].id,{active:!0}):chrome.tabs.create({url:q.url,
active:!1,index:m.index+1})})}):window.open(g);
else if(q.dateGroupModified){if(!f.ctrlKey){g=0;for(var w;w=P.children[g++];)if(w.d?.path==q.id&&w.type==Ba){var u=w;break}}u?Qb(u):(u=l.newTab(W,q.id,0,P),u.title=q.title,Qb(Sb([u],0,jb.nextSibling)));P.dirty()}}}}
function C(f){if(!ra)if(Ca){if(0==f.button){var g=k(f);g||(g=f.target,g=g.classList.contains("ListView")?{pos:g.ada.size,lst:g,data:{parentId:g.tD.path},getBoundingClientRect:function(){}}:0);
if(g){if(Bb(g.lst.tD))return;var q=g.getBoundingClientRect()||{};q=f.clientY>q.y+q.height/2;var w=g.data,u=Oa.data;f=Oa.pos-g.pos;var m=Oa.lst==g.lst?0:g.lst;if(f||m){f=g.pos+1;q||f--;R.onRemove();var t=Oa.lst,E=t.v,H=t.salad;g=Object.keys(H);var O=E.tP.pos,A=g[0].ver,I=0;q=t.ada.ni;try{g=g.sort(function(ma,Ma){if(H[ma].ver!=A)throw I=1,1;return H[ma].pos-H[Ma].pos})}catch(ma){}I&&(g=t.ada.sort(H,g.length));
q&&g.reverse();f<=O&&(O=0);function la(ma,Ma){chrome.bookmarks.move(ma[ma.nxt],{index:Ma,parentId:w.parentId},function(Ia){ma.nxt++;if(Ia){var Rb=H[Ia.id],rd=Rb.pos;O&&rd<O&&E.tP.pos--;m&&(u.parentId==Ia.parentId||Bb(t.tD)||delete H[Ia.id],m.salad[Ia.id]={id:Rb.id});ma.nxt<ma.length?la(ma,Ia.index+1):Ia=0}if(!Ia){var Kc=jb.d.path;l.pullBkmk(Kc,function(Lc){Ya(R.lv,Lc,Hb(Lc,jb.d,Kc))})}})}
g.nxt=0;t=m||t;f=t.ada.dPos(f);la(g,f)}}nc()}}else if(g=k(f)){t=g.lst;var Q=g.data.id;H=t.salad;f.ctrlKey||h(H);q=T(f,g);if(f.shiftKey){if(pa(t,g,1),zb&&zb.lst==t){Q=g;var ba=g.pos-Jc,ya=0<ba,Na;0>ba&&(ba=-ba);ba++;for(Na=ba;0<Na;){var db=g.pos+(ya?-1:1)*(ba-Na),ka=t.ada.getItem(db);pa(t,Q,ka,db);Q&&=t.rowSibling(Q,ya);Na--}}}else q&&!H[Q]?pa(t,g,1):(pa(t,g,0),q||(t.sel=null));!q||zb&&f.shiftKey||Wa(g)}}
function K(f){if(1==f.button)if(f.clientX<2*B.body.clientWidth/3){var g=k(f);g&&(f.r=g,Ca||N(g),f.lv=g.lst,f.sy=f.lv.scrollTop,Vb=f)}else Vb=0;else if(0==f.button)Ca||N();else if(2==f.button&&!Ca&&!ra&&(g=k(f))){var q=g.lst;B.body.addEventListener("mousemove",U);Cb=g.pos;Za=-1;ra=g;ra.x=f.clientX;oc=q.getBoundingClientRect().y;ra.y0=f.clientY;ra.y=q.scrollTop+ra.y0-oc;N(g)}}
function U(f){if(void 0!=f.clientX){Mc=f;var g=k(f)}else f=Mc,g=k(document.elementFromPoint(f.clientX,f.clientY));if(g&&(-1==Za&&(g.pos!=Cb||3<Math.abs(ra.y0-f.clientY))&&(Za=g.pos,Da=g.lst,Nc=Da.topPos(),rb||=M(0,0,"BoxSel"),Da.append(rb),Da.style.position="relative",Da.addEventListener("scroll",U)),-1!=Za)){Za=g.pos;var q=g.lst,w=ra.x,u=f.clientX,m=ra.y;f=q.scrollTop+f.clientY-oc;var t=u-w,E=f-m;0>E&&(E=-E,m=f);0>t&&(t=-t,w=u);Da.topPos()!=Nc&&(Cb<g.pos?(m=0,E=f):(m=f,E=q.scrollHeight+5));rb.style.top=
m+"px";rb.style.left=w+"px";rb.style.height=E+"px";rb.style.width=t+"px";N(g)}}
function V(f){if(-1!=Za){var g=Cb,q=Za;Cb>Za&&(g=q,q=Cb);var w=0,u=1,m=Da.topPos(),t=Da.salad;for(f=f?0:1;g<=q;g++){var E=Da.ada.getItem(g);u&&g>=m&&(w=Da.findRow(g),u=0);w&&(w.pos==g?Ab(w,"selecting",f):w=0);f?t[E.id]={pos:g,id:E.id,e:w}:delete t[E.id];w&&=Da.rowSibling(w)}Za=-1;window.oncontextmenu=$b;setTimeout(function(){window.oncontextmenu=0},20);
Da.removeEventListener("scroll",U);N();rb.remove()}ra&&(B.body.removeEventListener("mousemove",U),ra=0)}
function N(f){Wb!=f&&(Ab(Wb,"hot"),Wb=f,Ab(Wb,"hot",null!=f))}
function va(f){f.srcElement.scrollTop=Oc}
function ta(f){if(f.ctrlKey||f.shiftKey||Ca||ra)$b(f);else{var g=f.target.href;"add"==g&&(g="平典搜索");f.dataTransfer.setData("url",g);Oa&&(Oa.classList.remove("sorting"),Oa=0);Ca&&(Ca=0,sb.hidden=1);if(f=k(f)){g=f.lst;var q=g.salad;q[f.data.id]||h(q);pa(g,f,1);Oa=f;Wa(f);N(f)}}}
function ja(f){if(f=k(f))sb||(eb=M(0,0,0,"position:absolute;height:25px;width:50px;background:#2196f3e3;color:#FFF;z-index:9;border-radius:30px;left:10px;text-align:center;z-index:10;pointer-events:none;"),sb=M(0,0,0,"position:absolute;bottom:0;width:100%;height:39px;background-image:linear-gradient(rgba(0, 0, 0, 0), rgb(90 90 90 / 68%));color:#fff;z-index:9;pointer-events:none;"),M("P",sb,0,"position:absolute;width:100%;font-size:1em;bottom:0;text-align:center;line-height:0;").innerHTML=L("3")),
eb.innerText=1,sb.hidden=0,Ca=f,f=na("tabs"),f.insertBefore(sb,f.firstChild),f.insertBefore(eb,f.firstChild),B.body.addEventListener("mousemove",Pc)}
function nc(){Ca&&(Ca=0,sb.remove(),eb.remove(),B.body.removeEventListener("mousemove",Pc),fb&&(fb.classList.remove(Xb),fb=0),Oa.classList.remove("sorting"),Oa=0,N())}
function Pc(f){if(!Bb(jb.d)){var g=B.elementFromPoint(f.clientX,f.clientY);if(g=k(g)){var q=g.getBoundingClientRect();q=f.clientY>q.y+q.height/2?"drag-below":"drag-above";if(fb!=g||Xb!=q)fb&&fb.classList.remove(Xb),fb=g;fb.classList.add(Xb=q)}}eb.style.left=f.clientX-eb.offsetWidth/2+"px";eb.style.top=f.clientY-eb.offsetHeight+"px"}
function Ya(f,g,q){var w=f.tP,u={size:g.length,ni:w.ni,bifun:d,getItem:function(m){return g[this.ni?g.length-1-m:m]},
sort:function(m,t){for(var E=[],H=0;H<g.length;H++){var O=g[this.ni?g.length-1-H:H],A=m[O.id];if(A&&(A.pos=H,A.ver=f.ver,E.push(O.id),0>=--t))break}return E},
dPos:function(m){return this.ni?g.length-m:m},
rPos:function(m){return this.ni?g.length-1-m:m},
d4sa:function(m,t,E){var H=this.rPos(t.pos),O=g[H];if(O&&O.id==m)return O.pos=H;H=-1;if(!E)for(E=0;O=g[E++];)if(O.id==m)return t.pos=this.dPos(E),this.d4sa(m,t,1);return H}};
f.dVer=q;f.ver=u;f.arr=g;f.ada=u;G.resetLv=()=>{f.reset(u,w.pos||0,w.offset)};
f.reset||l.initListView(f,u,30,"px",G);f.reset(u,w.pos||0,w.offset);gc()}
var Wb,Oc,Vb,Hc=-1,zb,Jc,Oa,fb,Xb,Ca,sb,eb,Mc,Da,rb,Cb,ra,Za,Nc,oc,lc=l.menuPageBkmk||0;B.addEventListener("mouseup",function(f){if(1==f.button){var g=0,q=Vb;if(!q)return;var w=q.lv,u=q.r;if(u&&w){if(f.srcElement==q.srcElement&&w.scrollTop==q.sy&&q.clientX==q.clientX&&q.clientY==q.clientY&&T(q,u)){g=1;chrome.tabs.create({url:u.lv.href||"about:blank",active:!1});Oc=w.scrollTop;w.onscroll=va;setTimeout(w.onclick=function(){w.onscroll=0;w.onclick=C},300);
var m=Date.now();l.fakePP=m;chrome.browserAction.openPopup(function(t){t&&t.close();q=chrome.runtime.lastError});
Aa(u)}Vb=0}g||Ca||N()}Ca?2==f.button&&(window.oncontextmenu=$b,setTimeout(function(){window.oncontextmenu=0},20),nc()):2==f.button&&ra&&V(f.altKey)},1);
xb={init:function(f,g){var q=M(0,0,"UiTab"),w=M(0,M(0,q,"UiHead"),0,"display:flex;justify-content:space-between;"),u=M(0,q,"UITabo"),m=M(0,u,"ListView"),t=0;t||(u=hc(f),Qa(u,A=>{t=tb[f.id]=A||{};m.tP=t;aa(H,t);g()}));
G.lv=m;u=M(0,w,"folder-icon","padding-left:5px;");M(0,u,"item-icon");u.style.opacity="0.5";var E=q.etLoca=M("INPUT",w,0,"width:100%");q.etSch=M("INPUT",w,0,"width:65%;margin-left:3px;");q.etSch.placeholder="consider donation to help development";w=M("DIV",w,"tools");var H=M("BUTTON",w,"btn");H.id="top";H.innerText="⇧";H.title=L("w");H=M("BUTTON",w,"btn");H.id="bottom";H.innerText="⇩";H.title=L("y");H=M("BUTTON",w,"btn");H.innerText="☆";H.id="add";q.star=H;q.reStar=()=>{(A=>{setTimeout(()=>{A.title=
ea?.parentId==f.path?L("k"):ea?L("d1"):L("e3");wa(A,ea?"★":"☆")},200)})(q.star)};
q.reStar();m.act=A=>{t.pos=t.offset=0;for(var I=m.arr,Q=0;Q<I.length;Q++)if(I[Q].id==A){t.pos=Q-2;m.tada=Q;break}Ya(m,I)};
H.oncontextmenu=A=>{Fa(A);Kb(I=>{ic(q,I)})};
H=M("BUTTON",w,"btn");H.id="sort";t&&aa(H,t);w.onclick=function(A){A=A.target;"sort"==A.id?(t.ni=!t.ni,null!=m.sel&&(m.sel=m.arr.length-1-m.sel,t.pos=m.sel),t.offset=0,Ya(m,m.arr),aa(A,t),m.scrollTop+5<m.scrollHeight-m.offsetHeight&&(m.scrollTop-=m.offsetHeight/2)):"top"==A.id?(t.pos=t.offset=0,Ya(m,m.arr)):"bottom"==A.id?(t.pos=t.offset=0,t.pos=m.arr.length-1,Ya(m,m.arr)):"add"==A.id&&Kb(I=>{J(I||{url:z.url,title:z.title},m,I?void 0:f.path)})};
E.reload=function(A,I){Hb(null,f);I&&(f.title=I);q.taEl.getElementsByClassName("title")[0].innerText=f.title||L("8r");f.path=A;l.pullBkmk(A,function(Q){Ya(q.lv,Q,Hb(Q,f,A))})};
E.onkeydown=function(A){if("Enter"==A.key){var I=E.value+"";if(I.startsWith("recent"))f.path=I,Hb(null,f),l.pullBkmk(I,function(ba){Ya(q.lv,ba,Hb(ba,f,I))});
else if(A=null,A=I.startsWith("chrome://bookmarks/?id=")?parseInt(I.slice(I.indexOf("=")+1)):isNaN(I)?I.startsWith("chrome://bookmarks/?q=")||I.startsWith("q=")?decodeURIComponent(I.slice(I.indexOf("q="))):"q="+I:parseInt(I),null!==A){var Q=A+"";Q.startsWith("q=")?E.reload(Q,L("6k")+Q.slice(2)):chrome.bookmarks.get(Q,function(ba){ba&&ba.length&&E.reload(Q,ba[0].title)})}P.dirty()}};
q.lv=m;q.tD=f;q.tP=t;m.tabIndex=0;m.v=q;m.ver=0;m.tD=f;m.onclick=C;m.salad=[];G.listView=m;var O;q.onRemove=function(){try{var A=m.fvp();A&&(t.pos=A.pos,t.offset=m.scrollTop-m.rowOffset(A),Ua(hc(f),t));O=0}catch(I){ia(I)}};
m.blue=function(){O&&clearTimeout(O);O=setTimeout(q.onRemove,350)};
q.onAttach=function(){q.lv.focus();q.onResume()};
q.onResume=function(){var A=f.path,I=bb[A];I&&(!I.data&&I.stl||I.ver!=q.lv.dVer)&&l.pullBkmk(A,function(Q){Ya(q.lv,Q,Hb(Q,f,A))})};
t&&g();return q},
bind:Ya}}();
var c=xb.init(a,()=>{l.pullBkmk(b,function(d){if(d){var k=Hb(d,a,b);l.initListView?xb.bind(c.lv,d,k):l.loadListView(function(){xb.bind(c.lv,d,a,k)})}else chrome.bookmarks.search(a.title,h=>{h&&(h=h[0],a.path=h.id+"");
l.pullBkmk(a.path,function(p){var n=Hb(p,a,b);l.initListView?xb.bind(c.lv,p,n):l.loadListView(function(){xb.bind(c.lv,p,a,n)})})})})});
c.etLoca.value=za(a);return c}
function Hb(a,b,c){c||(c=b.path);var d=bb[c];if(!d){if(!a)return;d=bb[c]={s:[],ver:0}}var k=d.s.indexOf(b),h=0<=k;h&&d.s.splice(k,1);if(a){if(d.s.push(b),d.data=a,d.stl=0,!h&&ob){a=[];var p=bb,n;for(n in p)if(c=p[n],c=c.s){k=!0;h=0;for(var r;k&&(r=c[h++]);)if(r.id!=b.id){var v=ob[r.id];void 0!=v&&8>=v&&(k=!1)}else k=!1;k&&a.push(n)}a.forEach(function(x){delete p[x]})}}else 0==d.s.length&&delete bb[c];
return d.ver}
function jc(a,b){return((c,d)=>{function k(D){for(var C,K=0,U;U=x.grid(1).el.children[K++];)if(U.data.url===D){C=!0;break}return C}
function h(D,C,K){var U=x.grid().el,V=K.ctrlKey;-1==C?!(C=z)||!V&&k(C.url)||(x.layout([{url:C.url,title:C.title,favIconUrl:C.favIconUrl,tabId:C.id}],0,U,D),J=F.v):-2!=C&&-3!=C||chrome.tabs.query(-2==C?{currentWindow:!0}:{},function(N){for(var va=[],ta=0,ja;ja=N[ta++];)!V&&k(ja.url)||va.push({url:ja.url,title:ja.title,favIconUrl:ja.favIconUrl,tabId:ja.id});va.length&&(x.layout(va,0,U,D),J=F.v)});
x.dirty()}
function p(D){chrome.windows.update(D,{focused:!0},function(C){})}
function n(D,C){chrome.tabs.update(C.id,{active:!0},function(){});
D.tabId=C.id;Xa.favTabs[C.id]=D;p(C.windowId)}
function r(D){l.navPath=d;l.navCtx={idx:F.data.indexOf(D),tmp:T.tmp,same:T.same};l.navBkmk=0;if(d.startsWith("imp_tmp")){!T.tmp||Aa&&fa||(x.pref("del"),Aa=1);var C=D.url;T.same?chrome.tabs.update(z.id,{url:C}):window.open(C);fa&&window.close()}else chrome.tabs.update(D.tabId||0,{active:!0},function(K){K?(p(K.windowId),Xa.favTabs[K.id]||(Xa.favTabs[K.id]=D)):chrome.tabs.query({url:D.url},function(U){(U=U&&U[0])?n(D,U):(U=D.url.lastIndexOf("#"),0<U&&chrome.tabs.query({url:D.url.slice(0,U)},function(V){V&&
(V=V&&V[0])&&n(D,V)}))})})}
function v(){setTimeout(()=>x.onAttach(),100)}
d=d||"imp_";var x=M(0,0,"UiTab");x.id=c.id;var y=0,J=0;x.dirty=function(){y=(F.v||0)+1};
x.f1=function(){};
x.onload=function(D){var C=Xa.favPlus;C||(C=Xa.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`,fixed:1,dyn:1});D.f0=x.layout([C],0,D,0);D.bin=x.bin;D.dirty=x.dirty};
x.onResume=function(){J<F.v&&(J=F.v,x.load())};
var F,S=d,aa,T,pa;x.load=function(){Sa(pa=c.path.includes("tmp")?"opt_imp":"opt_tmp",D=>{T=D||{};void 0==T.tmp&&(T.tmp=c.path.includes("tmp"));void 0==T.same&&(T.same=c.path.includes("tmp"));kc(hc(c),C=>{aa=C||{};l.pullImpt(S,K=>{bb[S]=F=K;x.impd=K;y=K.v||0;x.layout(K.data);J=F.v;setTimeout(()=>{x.grid(1).el.parentElement.scrollTop=aa.top},10);
setTimeout(()=>{x.grid(1).el.parentElement.scrollTop=aa.top},100);
gc()})})})};
x.save=function(){var D=parseInt(x.grid(1).el.parentElement.scrollTop),C=aa.top!=D&&x.grid(1).el.children.length;aa.top=D;if(y>(F.v||0)){F.v=y;D=[];for(C=x.grid(1).el.firstElementChild;C;){var K=C.data;K&&!K.dyn&&D.push(K);C=C.nextElementSibling}F.data=D;l.log("saving::",S,D);l.saveImportabs(S,F);mc(hc(c),aa);J=F.v}else C&&mc(hc(c),aa);T.changed&&(delete T.changed,Ua(pa,T))};
x.bin=[];x.pref=function(D,C,K,U){var V=x.grid();K=V.el;var N=X,va=0,ta=N.data;switch(D){case "del":X.classList.contains("selected")&&(va=pc(V,N));va||=qc(V,N,x.bin,V.el);break;case "delSel":va=pc(V,N);break;case "restore":va=rc(V,N);break;case "moveSel":va=sc(V,N);break;case "selAll":tc(V);break;case "open":Lb(ja=>{chrome.tabs.create({active:!U.ctrlKey,url:ta.url,index:ja.index+1},function(nc){})});
break;case "addThis":h(!N||N.fixed?0:N.nextSibling,-1,U);break;case "openFolder":Mb(jb,N.data);break;case "addWnd":h(!N||N.fixed?N:N.nextSibling,-2,U);break;case "addAll":h(!N||N.fixed?N:N.nextSibling,-3,U);break;case "uniImp":return wb.uniImp=!C,1;case "tweak":return wb.tkImp=C,1;case "topImp":return wb.topImp=C,K.f0&&(K.f0.remove(),K.f0=x.layout([K.f0.data],0,K,C?K.firstChild:0)),1;case "isTmp":return T.tmp=!!C,T.changed=1;case "isSame":return T.same=!!C,T.changed=1;case "multi":return N&&V.els(N)||
(wb.mtImp=C),1;case "copyUrl":Ja(ta.url);Nb(ta.url);break;case "openInCurrent":Lb(ja=>{chrome.tabs.update(ja.id,{url:ta.url},function(){fa&&void 0!=U&&window.close()})});
break;case "openInNewTab":Ob(ta.url,function(ja){ja&&0<ja.length?chrome.tabs.update(ja[0].id,{active:!0}):chrome.tabs.create({url:ta.url})});
break;case "openInBackgroud":Lb(ja=>{chrome.tabs.create({url:ta.url,index:ja.index+1,active:!1})});
break;case "openInIframe":K=l.newTab(W,ta.url,Pb,P);K.title=ta.title;Qb(Sb([K],0,jb.nextSibling));P.dirty();break;case "topImp1":D=ta.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`};x.layout([D],0,K,N.nextElementSibling);break;case "pinTop":va=uc(V,N,1);break;case "pinBot":va=uc(V,N);break;case "goTop":R.grid(1).el.parentElement.scrollTop=0;break;case "goBot":R.grid(1).el.parentElement.scrollTop=R.grid(1).el.parentElement.scrollHeight}Tb();
va&&x.dirty();return 1};
var Wa=l.menuPageImp||0;x.oncontextmenu=function(D){for(var C=D.target,K=C.S;!K&&C&&!C.classList.contains("item-sqr");)C=C.parentNode;X=C;var U=C.data;C||(K=1);K=x.grid();U=0==Wa?["",[0,"open",[L("i"),U.url]],,[0,"addThis",L("9q"),1,,[0,"addWnd",L("v8")],[0,"addAll",L("o")]],[0,"topImp1",L("4")],[0,"pinTop",L("qi")],[0,"pinBot",L("tf")],[0,"del",L("c5"),x.bin.length,[0,"restore",L("g")]],[0,"multi",L("vn"),wb.mtImp||K.els(C),[0,"moveSel",L("6s")],[0,"delSel",L("lt")],[0,"selAll",L("s3")]],[1,c.path.includes("tmp")?
"isTmp":0,L("2"),T.tmp],[1,c.path.includes("tmp")?"isSame":0,L("72"),T.same]]:["",[0,"openInCurrent",L("72")],[0,"openInNewTab",L("i")],[0,"openInBackgroud",L("g7")],[0,"openInIframe",L("cb")],[0,"goTop",L("w")],[0,"goBot",L("y")],[0,"copyUrl",L("4y")]];cc(U,x.pref,D,C,x.oncontextmenu,[L("ee3r"),L("8")],Wa,V=>{l.menuPageImp=Wa=V;x.oncontextmenu(D)});
Ib=D;if(ec()){C=fc();if(vc=na("open",C))vc.oncontextmenu=V=>{Fa(V);x.pref("openInCurrent")};
vc=na("addSep",C);if(vc=na("openInCurrent",C))vc.title="右键不关闭弹窗",vc.oncontextmenu=V=>{Fa(V);x.pref(vc.id)}}};
x.dblclick=function(D,C){D=C.data;"add"!=D.url&&chrome.tabs.create({active:!0,url:D.url,index:z.index+1},function(K){})};
x.click=function(D,C){var K=C.data;if("add"==K.url)h(C,-1,C);else{for(D=D.target;D&&!D.classList.contains("item-sqr");)D=D.parentNode;X=D;r(K)}};
var Aa;G.initGridTab?(initGridTab(G,B,x),v()):Yb("gridtab.js",function(){l.initSortable&&!Eb?(l.initSortable(B,G),initGridTab(G,B,x),v()):l.loadSortable(function(){l.initSortable(B,G);initGridTab(G,B,x);v()})});
return x})(a,b)}
function wc(a,b){var c=a.firstChild;if(c)return c;for(;a&&a!=b;){if(c=a.nextSibling)return c;a=a.parentNode}}
function xc(a){a=a.path;a.startsWith("sch:")&&(a=a.slice(4));return a}
function yc(a,b,c,d){l.putSchKey(b);if(!d||b)a?(b=a.replace("%s",b),c?chrome.tabs.update(z.id,{url:b}):window.open(b)):chrome.search.query({text:b,disposition:"NEW_TAB"}),fa?window.close():zc()}
var Ac;function Bc(a,b){function c(){r=xc(a);h.schEng.innerText=r||L("x")}
function d(v,x){v=v.value.trim()||h["1"].value.trim()||h["2"].value.trim();v!=n.key&&(n.key=v,Ua(k,n));yc(r,v,x)}
b=M(0,0,"UiTab");b.innerHTML='\n        <div class="UiHead">\n        \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div id="pasteIt" style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;" title="获取手机上的剪贴板数据，\n 当安卓无限词典处于前台无需复制只需选择，\n 当处于后台需要打开悬浮按钮。\n点击此处粘贴至浏览器内部的输入框">\n\t\t\t\t\t新的搜索&ensp;\n\t\t\t\t</div>\n                <textarea id=\'1\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="11" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="12" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n            \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;">当前页搜索&ensp;</div>\n                <textarea id=\'2\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="21" title="搜索">\ud83d\udd0d</button>\n                    <button class="btn" id="22" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="23" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n\t\t\t\n            <div class="divider">\n\t\t\t    <HR style=\'margin:15px;opacity:.8;\'>\n                <span class="dividerTitle" id="dt"></span>\n            </div>\n\t\t\t\n            <div style="height:18px;display:flex;flex-direction: row;position:fixed; bottom:0; width:100%; user-select:none; cursor: pointer;">\n                <div id="schEng" class="tools" style="height:30px;width: 100%;font-size:10px;padding-left:5px;color:#888">\n                    默认搜索引擎\n                </div>\n            </div>\n            \n        </div>\n        <div class="UITabo">\n            <div class="ListView" id="key"></div>\n        </div>';
for(var k="v_"+lb.id+"_"+a.id,h={},p=b,n={};p=wc(p,b);)p.id&&(h[p.id]=p);var r;c();b.et=h["1"];wa(h.dt,a.title);M("SPAN",0,"tabx").innerText="";p=M(0,0,"item-icon");M(0,p,"img web").style.backgroundImage=Cc(a.path.slice(4));p.style="display: inline-block;transform: translateY(4px);";h.dt.insertBefore(p,h.dt.firstChild);h["11"].onclick=function(){d(h["1"])};
h["21"].onclick=function(){d(h["2"],!0)};
h["22"].onclick=function(){d(h["2"])};
h.schEng.onclick=function(){var v=prompt("输入搜索引擎地址，用%s代替关键词：",r);void 0!=v&&v!=r&&(a.path="sch:"+v,c(),P.dirty())};
Ga("keydown",function(v){"Enter"!==v.key||v.shiftKey||(Fa(v),d(v.target))},0,h["1"]);
Ga("keydown",function(v){"Enter"!==v.key||v.shiftKey||(Fa(v),d(v.target,!0))},0,h["2"]);
b.onAttach=function(){vb==Dc&&setTimeout(()=>{h.schEng.click()},250);
Ac||(Ac=M(0,0,"sch-pane"),zc());h.key.append(Ac)};
b.onRemove=function(){};
La(k,v=>{if(v=v[k])n=v,h["1"].value=v.key||"";Ec(x=>{h["2"].value=x})});
return b}
function Fc(a,b){a=M(0,0,"UiTab");var c=M("IFRAME",a);b.includes(":")||(b="https://"+b);c.src=b;c.style.width="100%";c.style.height="100%";return a}
function Gc(a,b){return((c,d)=>{function k(){return r}
function h(y){y=y.src;n.shadow.innerHTML=y;p.s=n.shadow;var J=y.lastIndexOf("<script>");J&&(J=y.slice(J+8,y.indexOf("</script>",J+8)),eval(J.replace("_bg()",k.name+"()")))}
var p=M(0,0,"UiTab disp0"),n=M(0,p);n.src=d;n.style.width="100%";n.style.height="100%";n.shadow||(n.shadow=n.attachShadow?n.attachShadow({mode:"open"}):M(0,n));p.d=c;var r,v=hc(c),x=v+"_";p.k=v;p.tmps=l.d();p.onRemove=()=>{if(r.view.onSave)r.view.onSave();if(r.changed){var y={};Object.assign(y,r);delete r.changed;delete y.changed;delete y.view;delete y.src;Ua(r.view.k,y)}};
p.reload=y=>{h(y)};
La([v,x],y=>{p._bg=r=y[v]||{};r.view=p;r.src=y[x];delete r.changed;if(r.src)h(r);else if("百度高级搜索"==c.title){var J=new XMLHttpRequest;J.open("GET","assets/百度高级搜索.html",!!r);J.onreadystatechange=function(F){4===J.readyState&&200===J.status&&(r.src=J.responseText,h(r))};
J.send()}});
return p})(a,b)}
function Ja(a){function b(c){document.removeEventListener("copy",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("copy",b,!0);document.execCommand("copy")}
function Ic(a){function b(c){document.removeEventListener("paste",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("paste",b,!0);document.execCommand("paste")}
function Yb(a,b,c){c?b():(c=document.createElement("script"),c.type="text/javascript",c.onload=b,c.src=a,document.body.appendChild(c))}
var Y;function Qc(a){l.initSortable(B,G);Y=new Sortable(P,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabH",root:!0,forceFallback:!1,sort:!0,onMove(b){this.options.animation=pb?300:0;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){Y.did(b)&&P.dirty()},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;G.disani=0},click(b){},trace:function(){console.log("trace"+Error().stack)}});
a&&(Y._onTapStart(a),a.constructor==DragEvent?Y._onDragStart(a):Y._onDrop(a),Rc(a,1))}
var Eb=1;function Rc(a,b){Y?a&&(b?P.onclick=a.target.ondragstart=void 0:Rc(a,1)):l.initSortable&&!Eb?Qc(a):l.loadSortable(function(){Qc(a)})}
P.onclick=function(a){(a.ctrlKey||a.shiftKey)&&a.target!=P&&Rc(a)};
document.ondblclick=function(a){var b=a.target;b==P?Y&&Y.multiDrag._deselectMultiDrag():R&&R.contains(b)&&R.dblclick&&R.dblclick(a,b)};
var Sc={};document.onkeydown=function(a){if(!Sc[a.key]){Sc[a.key]=1;var b=a.target;b.grido&&(b=b.grido());if(b.S){var c=0;a.ctrlKey?"a"==a.key?(tc(b.S),c=1):"z"==a.key&&(rc(b.S),c=1):"Delete"==a.key&&(pc(b.S,0),c=1);c&&(b.dirty(),$b(a))}}};
document.onkeyup=function(a){Sc[a.key]=0};
var Tc,Uc;function Vc(){l.initTabs(function(a,b,c){function d(){if(null!==nb&&fa&&2!=lb.t0&&qb)try{y.scrollTop=nb;return}catch(F){}try{y.scrollTop=jb.offsetTop-ca/3*Uc}catch(F){}}
var k=!Tc;W={};if(0==a.length){function F(S,aa,T){void 0===T&&(T=Dc);"v"==S&&(S="");S=l.newTab(W,S,T,0,aa,a.length+1);a.push(S)}
if(b.name==L("4s")||2==b.t0){var h=new XMLHttpRequest;h.open("GET","assets/default_sch_engines.js",!1);h.onreadystatechange=function(S){4===h.readyState&&200===h.status&&eval(h.responseText.replaceAll("doit",F.name))};
h.send();b.t0=2}else if(b.name==L("qc")||3==b.t0)F("recent",0,Ba),F("",0,Wc),F("",L("x"),Dc),F("imp_tmp",L("xp"),Ea);else if("tabs1"==b.id||1==b.t0)F("0",0,Ba),F("1",0,Ba),F("2",0,Ba),F("recent",0,Ba)}Y&&(Y=0,P.onclick=function(F){(F.ctrlKey||F.shiftKey)&&F.target!=P&&Rc(F)});
if(b.type==Xc&&c.bar){for(var p=[],n={},r=a.length-1;0<=r;r--){var v=a[r];v.pos=r;v.auto&&v.type==Ba&&(a.splice(r,1),n[v.path]=v);W[v.id]=v}function F(S){if(void 0!=S.dateGroupModified){S=S.id;var aa=n[S];aa?(delete n[S],delete W[S]):(aa=l.newTab(W,S,Ba),aa.auto=1);p.push(aa)}}
F({dateGroupModified:1,id:"1",title:L("2n")});for(r=0;r<c.bar.length;r++)F(c.bar[r]);for(r=0;r<a.length;r++)p.splice(a[r].pos||0,0,a[r]);a=p;for(var x in n)r=n[x],delete W[x],Va(hc(r,b)),r.type==Wc&&Va(hc(r,b)+"_")}mb=0;nb=void 0===c.scroll?null:parseInt(c.scroll)||0;lb=b;ob=c.hots||{};pb=wb.expTab=c.exp;qb=c.rec;void 0===qb&&(qb=2!=b.t0);gb.innerText="";jb=R=ab=0;kb=[];tb=b.tPs||{};var y=k?P:P.cloneNode();b=P;ca=pb?6:3;fa&&(ca=pb?6:4);Tc=Math.ceil(Uc*ca);y.style.maxHeight=Tc+"px";y.bin=Yc;var J=
0;y.dirty=function(){J=Xa.tabsVer+1};
y.save=function(){if(J>Xa.tabsVer){Xa.tabsVer=J;$a.length=0;for(var F=y.firstElementChild;F;){var S=F.d;S&&$a.push(S);F=F.nextElementSibling}$a.now=ab.id;l.saveTabs(lb,$a,()=>{})}};
window.tmpTabH=y;$a=a;ab=0;c=Sb($a,c.tix,0,y);ab||(ab=a[0],c=y.firstElementChild,c==hb&&(c=c.nextElementSibling));y.append(hb);y.style.minHeight="";k||(Zc.observe(y),y.style.position="absolute",y.style.visibility="hidden",ib.insertBefore(y,P),P=y,$c(),Zc.unobserve(b));Qb(c,1);hb.fixed=1;y.oncontextmenu=ad;bd.dirty||cd();k?setTimeout(()=>{Uc=Math.max(hb.offsetHeight,P.firstElementChild.offsetHeight);Tc=Math.ceil(Uc*ca);y.style.maxHeight=Tc+"px";y.MH=Tc;$c();d()},1):d();
k||(y.style.position="",y.style.visibility="",b.remove())},fa?0:window)}
Vc();function dd(a){var b=Object.create(Object.getPrototypeOf(a));Object.getOwnPropertyNames(a).forEach(function(c){var d=Object.getOwnPropertyDescriptor(a,c);Object.defineProperty(b,c,d)});
return b}
function Sb(a,b,c,d){var k=d||P;d||(c||=hb);for(var h=0,p=0;p<a.length;p++){var n=a[p];d&&(a[p]=n=dd(n));var r=n.type,v=n.title,x=n.ico;v||(r==Ba&&(v=n.path?.startsWith("recent")?L("7z"):L("8r")),r==Ea&&(v=n.path?.includes("tmp")?L("xp"):L("wd")),r==ed&&(v="无限词典"),r==Wc&&(v=L("9b")));x||(r==Ba&&(x="★"),n.type==Pb&&(x="\ud83c\udf10"),n.type==Dc&&(x="\ud83c\udf10"));r=M("LI",0,"tab");n.type==fd&&(r.classList.add("tab-sep"),n.path&&(r.style=n.path));if(x){var y=M("SPAN",r,"tabx");y.innerText=x}n.type==
Dc&&n.path&&(y.innerText="",r.con=M(0,r,"item-icon"),r.icon=M(0,r.con,"img web"),r.icon.style.backgroundImage=Cc(n.path.slice(4)));let J=M("SPAN",r,"tabx title");(n.type==fd?xa:wa)(J,v);0!=n.type||Bb(n)||chrome.bookmarks.get(n.path,function(F){F&&F.length&&(J.innerText=F[0].title)});
r.onclick=gd;r.ondblclick=hd;r.oncontextmenu=ad;r.id="tab_"+n.id;W[n.id]=n;Y||(r.draggable=!0,r.ondragstart=Rc);r.d=n;d&&ob&&(v=ob[n.id],void 0!=v&&(r.classList.add("tab-hot"),r.style.setProperty("--bg",id(132,175,255,255,255,255,999==v?.85:.0625*v)),999!=v&&kb.push(r)));c&&c.parentNode==k?k.insertBefore(r,c):k.append(r);n.type==fd&&n.br&&(v=M("div",0,"flex-break"),k.insertBefore(v,r));h||(void 0!=b?p==b&&(ab=n,h=r):h=r)}d&&kb.sort(function(J,F){return-J.lev1+F.lev1});
return h}
const $c=a=>{a=P.scrollHeight>Tc;var b=P.style;!a^"visible"==b.overflowY&&(b.overflowY=a?"scroll":"visible",b.minHeight&&(b.minHeight=""))},Zc=new ResizeObserver($c);
Zc.observe(P);var Yc=[];function gd(a){if(!a.shiftKey&&!a.altKey&&!a.ctrlKey){for(a=a.target;a&&!a.classList.contains("tab");)a=a.parentNode;Qb(a);mb=1;clearTimeout(P.saving);P.saving=setTimeout(jd,800)}}
hb.onclick=function(a){X=0;kd(a)};
P.ondblclick=function(a){Y&&a.srcElement==P&&Y.multiDrag._deselectMultiDrag()};
function hd(a){if(!a.ctrlKey&&!a.shiftKey){for(a=a.srcElement;a&&!a.classList.contains("tab");)a=a.parentNode;pb=!pb;ld(a)}}
function md(a){return a&&a.parentNode==P&&a!=hb}
function ld(a){ca=pb?6:3;fa&&(ca=pb?6:4);P.MH=Tc=Math.ceil(Uc*ca);P.style.maxHeight=Tc+"px";$c()}
function nd(a){if(md(a)){var b={};Object.assign(b,a.d);var c=a.cloneNode(1);c.onclick=gd;c.ondblclick=hd;c.oncontextmenu=ad;b.id=l.newTabid(W,P.children.length);Y||(c.draggable=!0,c.ondragstart=Rc);c.d=b;P.insertBefore(c,a.nextSibling);Qb(c)}}
function qc(a,b,c,d){if(!b.fixed){d=c?{e:b,idx:[].indexOf.call(d.children,b)}:{};var k=a?a.els().indexOf(b):-1;~k&&(a.els().splice(k,1),d.sel=1);b.remove();c&&c.push(d);return!0}}
function pc(a,b,c){if(a&&(b=a.els(),b.length)){a.el.bin.push({es:b.concat(),idx:[].indexOf.call(a.el.children,b[0])});a=0;for(var d;d=b[a++];)if(d.remove(),c)try{c(d)}catch(k){ia(k)}b.length=0;return!0}}
function uc(a,b,c){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var d=a.els();d.length||(d=[b]);if(d.length){b=0;for(var k;k=d[b++];)k.remove();for(b=0;k=d[b++];)c?a.el.insertBefore(k,a.el.firstElementChild):a.el.append(k);return!0}}}
function sc(a,b){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var c=a.els();if(c.length&&-1==c.indexOf(b)){for(var d=0,k;k=c[d++];)k.remove();b=b.nextElementSibling;for(d=0;k=c[d++];)a.el.insertBefore(k,b),b=k.nextElementSibling;return!0}}}
function rc(a,b){if(a){var c=a.el.bin.pop();if(c){var d=a.el,k=d.children[c.idx||0];if(b=c.e)d.insertBefore(b,k),c.sel&&a&&a.els().push(b);else{b=c.es;c=0;for(var h;h=b[c++];)d.insertBefore(h,k),a&&a.els().push(h);b=b[0]}return b}}}
function tc(a){if(a){var b=a.els(),c=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||(b.push(d),d.classList.add("selected"))}}
function od(a){if(a){var b=a.els(),c=b.length=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||d.classList.remove("selected")}}
function cc(a,b,c,d,k,h,p,n){X=d;ec()?(Z=pd(0,a,b),qd(c),h?setTimeout(()=>sd(h,p,n),5):td&&td.remove()):Yb("settings.js",function(){initSettings(G,B,"settings.css");
ec()&&k(c)});
$b(c)}
function Jb(){ab?.type==Ba&&Kb(()=>R.reStar())}
function ud(a,b){var c=a.d.path,d=function(k){Gb(a);if(a.d==ab&&R&&R.onResume)R.onResume();Jb()};
Kb(k=>{!k||b.ctrlKey?chrome.bookmarks.create({parentId:c,url:z.url,title:z.title,index:b.shiftKey?0:void 0},d):k.parentId!=c?chrome.bookmarks.move(k.id,{parentId:c,index:b.shiftKey?0:void 0},d):Nb("已经添加到该文件夹！<br>"+L("x2"))})}
function Mb(a,b){chrome.bookmarks.get(b.path,function(c){if(c=c?c[0]:0)Tb(),ic(a.tabView,c)})}
function ic(a,b){if(b)if(b.parentId==a?.lv.tD.path)a.lv.act(b.id);else{for(var c,d=0,k;k=P.children[d++];)if(k.d?.path==b.parentId&&k.type==Ba){c=k;break}c?Qb(c):(c=l.newTab(W,b.parentId,Ba,P),Qb(Sb([c],0,a.taEl.nextSibling)));c&&(P.dirty(),setTimeout(()=>{R.lv&&R.lv.act(b.id)},500))}}
function kd(a){var b=X,c=["",[0,["tabFav",0],[L("u")],1,,[0,"tabRec",L("7z"),1]],[0,["tabImp",0],[L("wd")],1,,[0,"tabTmp",L("xp"),1]],[0,"tabSch",L("ff2s"),1],[0,"tabWeb",L("cb"),1],[0,["tabCustomX",0],[L("p")],1,,[0,"tabBaidu",L("百度高级搜索"),1],[0,"tabCustom",L("9b"),1]]];cc(c,vd,a,b,kd)}
function ad(a){Y||Rc(a);if(window.oncontextmenu==$b)$b(a);else{for(var b=a.target,c=b==P;!c&&b&&!b.classList.contains("tab");)b=b.parentNode;c=b.d.type==Ba;var d=ac(b.d),k=b.d.type==Dc,h=b.d.type==Ea,p=b.d.type==Pb;c=["",[0,d?["addFav",0]:0,[L("e3")],1,,[0,d?["newFavFolder",0]:0,[L("2i")],1],[0,d?["openLocatedFoler",0]:0,[L("h")],1]],[0,k?["schNew",0]:0,L("av"),1,[0,k?["schThis",0]:0,L("8k"),1]],[0,p||k||c?["openWeb",0]:0,L("i"),1],[0,b.d.type==Wc?["editSrc",0]:0,L("sb"),1],[0,h?["setTemp",0]:0,[L("2s")],
1],[0,["copyUrl",0],[L("od")],1],[0,["newTab",0],[L("tl")],1,,[0,["dupTab",0],[L("l")]],[0,["newSep",0],[L("1")]]],[0,["closeTab",0],[L("xm")],Yc.length,[0,["resumeTab",0],[L("v")]]],[0,["multiTab",0],[L("xx")],wb.mt||Y&&Y.els(b),[0,["moveTabs",0],[L("5")]],[0,["closeTabs",0],[L("jx")]],[0,["selTabs",0],[L("s3")]]],[1,fa?"recPos":0,[L("ld")],qb],[1,"expTab",[L("ov")],pb]];cc(c,vd,a,b,ad);if(ec()){Z.e=a;a=fc();if(b=na("selTabs",a))b.title=L("f"),b.oncontextmenu=n=>{od(Y);Fa(n);Tb()};
if(b=na("copyUrl",a))b.title=L("of"),b.oncontextmenu=n=>{Fa(n);wd()},b.onmousedown=n=>{1==n.button&&(Fa(n),xd())};
if(b=na("addFav",a))b.title=L("x2");if(b=na("addImp",a))b.title=L("x2")}}}
function xd(){var a=X,b=a.d;if(ac(b))chrome.bookmarks.get(b.path,function(k){if(k=k?k[0]:0)Tb(),Yb("assets/dialog.js",function(){var h=showDialog(B,B.body);wa(h.t,"Edit");xa(h.t1,Zb("NAME"));wa(h.btn0,"Save");var p=qa("TEXTAREA",h.t1);p[0].value=k.title;h.btn0.onclick=()=>{var n=p[0].value;chrome.bookmarks.update(b.path,{title:n},r=>{r&&(wa(sa("tabx title",a),n),h.s.remove())})};
h.btn1.onclick=()=>{h.s.remove()}},G.showDialog)});
else{var c=X.d.title,d=prompt("标题：",c);d!=c&&void 0!=d&&(Tb(),P.dirty(),(b.type==fd?xa:wa)(sa("tabx title",a),b.title=d),Gb(a))}}
function wd(){var a=X,b=a.d,c=za(X.d),d=prompt("请输入新地址（可以是书签url或者http网址）",c),k="v_"+lb.id+"_"+b.id,h=d!=c;if(d){Tb();function n(r,v){Ka.remove(k);var x=b.id;Object.keys(b).forEach(function(y){delete b[y]});
b.id=x;b.type=p;b.title=r;p==Ea&&(d.startsWith("important://")&&(d=d.slice(12)),d.startsWith("imp_")||(d="imp_"+d));b.path=d;h&&P.dirty();r=a.nextElementSibling;qc(Y,a,0,P);Sb([b],0,r);a==jb&&Qb(a);Gb(a,v)}
if(d.startsWith("chrome://bookmarks")||!isNaN(d)){var p=Ba;n(e[0].title,350)}else d.startsWith("imp")?(p=Ea,c=b.type==p?b.title:0,b.path.includes("tmp")!=d.includes("tmp")&&(c=0),n(c)):d.startsWith("custom")?(p=Wc,c=b.type==p?b.title:0,n(c||L("9b"))):d.startsWith("sch:")?(p=Dc,n(yd(d,!0)||L("ff2s"))):(p=Pb,n(yd(d,!0)))}}
function yd(a,b){var c=a,d=c.indexOf(":");for(0<=d&&(c=c.slice(d+1));c.startsWith("/");)c=c.slice(1);d=c.indexOf(".");if(0<d){if(a=c.slice(0,d),"www"==a){var k=c.indexOf(".",d+1);0<k&&(a=c.slice(d+1,k))}}else a=c;b&&(a=a.toUpperCase());return a}
function zd(a){a.delay?setTimeout(Tb,10):Tb()}
function id(a,b,c,d,k,h,p){a=Math.round(a*(1-p)+d*p);b=Math.round(b*(1-p)+k*p);c=Math.round(c*(1-p)+h*p);return"rgb("+a+" "+b+" "+c+")"}
const Ba=0,Ea=1,ed=2,Pb=4,Wc=5,Dc=6,fd=7;
function Qb(a,b){if(md(a))if(a.d.type==fd)Qb(a.nextElementSibling);else{if(jb){jb.classList.remove("tab-now");var c=R;if(c&&!c.hidden){if(c.onRemove)try{c.onRemove()}catch(n){}c.hidden=1;c.style.display="none"}}jb=a;if(ob){c=kb.indexOf(a);0<c&&kb.splice(c,1);kb.push(a);15<kb.length&&(c=kb.shift(),delete ob[c.d.id],c.lev1=999,c.style.setProperty("--bg",id(132,175,255,255,255,255,.85)));a.classList.add("tab-hot");c=kb.length-1;for(var d=c-1;0<=d;d--){var k=kb[d];ob[k.d.id]=k.lev1=c-d;k.style.setProperty("--bg",
id(132,175,255,255,255,255,.0625*(c-d)))}}a.classList.add("tab-now");d=ab=a.d;c=a.tabView;if(!c){c=d.type;try{c==Ba?(c=Db(d,d.path,a),c.taEl=a):c=c==Ea?jc(d,d.path):c==ed?newTabPlainDict(d,d.path):c==Pb?Fc(d,d.path):c==Wc?Gc(d,d.path):c==Dc?Bc(d,d.path):""}catch(n){console.error(n),c=""}c||=M(0,gb,0,"错误");a.tabView=c}(d=R!==c)&&(R=c);k=c.parentNode!=gb;if(c.hidden||k){if(c.hidden=0,c.style.display="",k&&gb.append(c),c.onAttach)try{c.onAttach()}catch(n){ia(n)}}else if(d&&c.onResume)try{c.onResume()}catch(n){ia(n)}c=
a.offsetHeight;d=a.offsetTop+c;k=P.scrollTop;var h=P.clientHeight,p=null;d<k+c/2+9?p=a.offsetTop:d>k+h&&(p=d-h);null!==p&&P.scrollTo({top:p,behavior:b?"auto":"smooth"})}}
G.onfocus=function(a){if(G._blr&&(G._blr=0,R&&R.onResume))R.onResume()};
G.onblur=function(a){G._blr=1;if(R&&R.onRemove)R.onRemove(1);jd();Ad()};
G.onbeforeunload=function(){Bd();if(R&&R.onRemove)R.onRemove(1);P.save();Ad();fa||delete l.bkWnds[z.id]};
function vd(a,b,c,d){function k(){Tb();p&&(Qb(Sb([p],0,X?.nextElementSibling)),h=1);h&&P.dirty()}
var h=0,p=0,n=X?.d;switch(a){case "addFav":ud(X,d);break;case "newFavFolder":chrome.bookmarks.get(n.path,function(v){if(v=v?v[0]:0){var x=v.title||"",y=x.replace(/\d+$/g,function(J){return(parseInt(J)+1).toString()});
(x=prompt("新建文件夹",y!==x?y:x+" 1"))&&chrome.bookmarks.create({parentId:v.parentId,title:x,index:v.index+1},function(J){J&&(p=l.newTab(W,J.id,Ba,P),k(),P.save())})}});
return;case "openLocatedFoler":return Mb(X,n),1;case "newTab":return kd(Z.e),1;case "tabFav":p=l.newTab(W,ea?ea.parentId:"0",Ba,P);break;case "tabRec":p=l.newTab(W,"recent=1000",Ba,P);break;case "tabImp":p=l.newTab(W,"imp_",Ea,P);break;case "tabTmp":p=l.newTab(W,"imp_tmp",Ea,P);break;case "tabAll":p=l.newTab(W,"all",Ea,P);p.title="全部页面";break;case "tabSch":p=l.newTab(W,"sch:",vb=Dc,P);p.title=L("ff2s");setTimeout(()=>{vb=0},250);
break;case "tabPDict":p=l.newTab(W,"",ed,P);break;case "tabWeb":b=prompt("输入网址：","");if(void 0!=b)b=b||"about:blank",p=l.newTab(W,b,Pb,P,yd(b,!0));else return;break;case "tabBaidu":p=l.newTab(W,"custom://",Wc,P,"百度高级搜索");break;case "tabCustom":p=l.newTab(W,"custom://",Wc,P,L("9b"));break;case "schNew":case "schThis":Ec(v=>yc(xc(X.d),v,"T"==a[3],!0));
break;case "setTemp":l.setTmpUrlPath(n.path);break;case "openWeb":var r=n.path;n.type==Dc&&(r=(new URL(r.slice(4))).origin+"");n.type==Ba&&(r=za(n));Ob(r,function(v){v&&0<v.length&&!d.ctrlKey?chrome.tabs.update(v[0].id,{active:!0}):Lb(x=>{chrome.tabs.create({active:!d.ctrlKey,url:r,index:x.index+1})})});
break;case "copyUrl":b=za(X.d);Ja(b);Nb(b);Gb(X);break;case "dupTab":nd(X);h=1;break;case "editSrc":Cd(X);break;case "newSep":p=l.newTab(W,"",fd,P,"&emsp;&emsp;");break;case "expTab":wb[a]=pb=b;mb=1;ld(X);break;case "recPos":qb=b;mb=1;break;case "closeTab":b=Y&&jb==X?jb.previousElementSibling||P.firstElementChild:0;if(h=qc(Y,X,Yc,P))Qb(b),Ka.remove(hc(n)),n.type==Wc&&Ka.remove(hc(n)+"_");break;case "closeTabs":h=pc(Y,X,v=>{n=v.d;Ka.remove(hc(n));n.type==Wc&&Ka.remove(hc(n)+"_")});
break;case "resumeTab":(h=rc(Y,X))&&Qb(h);break;case "moveTabs":h=sc(Y,X);break;case "selTabs":tc(Y);break;case "multiTab":return Rc(),X&&Y&&Y.els(X)||(wb.mt=b),1;default:return wb[a]=b,1}k();return 1}
var Dd,Z,X,dc,Ib,td;
function qd(a,b){if(b){if(window.e=a,ec()){b=Z.style;Z.p.style.display="block";var c=a.clientX,d=a.clientY;b.maxHeight="";if(Z.revert)b.right=G.innerWidth-c+5+"px",b.bottom=G.innerHeight-d+5+"px";else{var k=Z.parentNode.offsetWidth,h=Z.parentNode.offsetHeight;c+Z.offsetWidth/2>k&&(c=k-Z.offsetWidth/2,d+=2);b.left=c+"px";d+Z.offsetHeight>=h+45&&Z.offsetHeight/2>h-d&&150>h-d?(b.bottom=h-d+5+"px",b.top=b.maxHeight="",c=Z.cards[0].style,c.display="flex",c.flexDirection="column-reverse",b.maxHeight=Z.parentNode.offsetHeight-
(h-d+5)+"px",setTimeout(()=>{Z.cards[0].firstElementChild.scrollIntoView()},5)):(b.maxHeight=Z.parentNode.offsetHeight-d-5+"px",b.top=d+"px")}}}else setTimeout(()=>{qd(a,1)},5)}
function $b(a){Fa(a)}
function pd(a,b,c){if(Dd){if(a&&Dd.n===a)return Dd.p.parentNode||document.body.append(Dd.p),Dd;Dd.parentNode&&Dd.remove()}var d=na("menup");d||(d=M(0,document.body),d.id="menup",d.onmousewheel=function(p){p.srcElement==d&&Tb()},d.onmouseup=function(p){var n=p.target;
n===d?Tb():1==k.type&&(Fa(p),2==p.button&&(window.oncontextmenu=$b),n.classList.contains("sep")||n==k||(p.delay=!0,zd(p)),2==p.button&&setTimeout(function(){window.oncontextmenu=0},20))});
var k=M(0,d,"menu","max-width:35%;overflow:overlay;overflow-x:hidden;"),h=k;h.cards&&(h.cards.forEach(function(p){p.remove()}),h.cards=0);
SettingsBuildCard(c,b,h);k.n=a;k.l=b;k.p=d;return Dd=k}
function Tb(){Z&&(Z.p.style.display="none",dc&&dc(Z),Z=null)}
if(fa)chrome.tabs.query({active:!0,lastFocusedWindow:!0},function(a){if(z=a[0])Kb(b=>{}),da&&da()});
else{var vc=document.title;document.title+=Math.random();chrome.tabs.query({title:document.title},function(a){if(z=a[0])Kb(b=>{}),l.bkWnds[z.id]=1;
document.title=vc;z.title=vc})}function gc(){}
setTimeout(function(){cb.remove();cb=0},95);
fa||chrome.runtime.onMessage.addListener(function(a,b,c){if("focus"==a.name)G.onfocus();if("blur"==a.name)G.onblur()});
pb&&ld();var bd=na("tabgroup"),Ed,Fd;function cd(){bd.dirty||(bd.dirty=()=>{bd._dirty=l.verTG+1;bd._dirty<=l.verTG&&(l.verTG=0,bd._dirty=1)},Ga("mousewheel",function(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;
(b=Math[1<=b?"floor":"ceil"](b))&&bd.scrollTo({left:bd.scrollLeft+80*b,behavior:"auto"});Fa(a)},1,bd));
Qa("tab_groups",a=>{a&&a.constructor===Array||(a=[]);0==a.length&&(a.push({id:"tabs",name:L("2n"),type:Xc}),a.push({id:"tabs1",name:L("kq")}),a.push({id:"tabs2",name:L("4s"),t0:2}),a.push({id:"tabs3",name:L("qc"),t0:3}));Ed=a;Gd(Ed)})}
function Hd(a){Ad();a=a.target;if(a.d){if(a.d.id==lb.id)try{P.scrollTop=jb.offsetTop-ca/3*Uc;return}catch(b){}Fd&&Fd.classList.remove("sel");jd();Id(a.d);a.classList.add("sel");Fd=a}}
function Id(a){if(R&&R.onRemove)try{R.onRemove(1)}catch(b){ia(b)}jd();Ad();lb=a;ob=0;mc("sel_tab_gp",lb,()=>Vc())}
function jd(){P.save();var a=parseInt(P.scrollTop);if(lb&&ob&&(mb||a!=nb&&fa&&2!=lb.t0&&(qb||void 0!=nb))){var b="v_"+lb.id+"__";mb=0;nb=qb?a:a=void 0;var c=$a.indexOf(jb.d)||0;0>c&&(c=0);mc(b,{tix:c,hots:ob,scroll:a,exp:pb,rec:qb})}}
function mc(a,b,c){fa?Ua(a,b,c):(sessionStorage.setItem(a,JSON.stringify(b)),c&&c())}
function kc(a,b,c){if(fa||c)Qa(a,b);else{c=sessionStorage.getItem(a,null);try{c=JSON.parse(c)}catch(d){c=0}c?b&&b(c):kc(a,b,1)}}
function Gd(a){bd.innerHTML="";M(0,bd,"tgpd");for(var b=Fd=0,c;c=a[b++];){var d=M(0,bd,"tg");d.innerText=c.name;d.id="tg_"+c.id;d.d=c;d.onclick=Hd;d.oncontextmenu=Jd;Kd||(d.draggable=!0,d.ondragstart=Ld);c.id==lb.id&&(Fd=d,lb=c,d.classList.add("sel"))}M(0,bd,"tgpd");Fd&&requestAnimationFrame(()=>{bd.scrollLeft=Fd.offsetLeft-(bd.offsetWidth-Fd.offsetWidth-45)/2})}
const Md=0,Xc=1;function Nd(a,b,c){function d(x,y,J){v=Ed.indexOf(n);0>v?v=Ed.length:v++;for(var F=0,S=0,aa;aa=Ed[S++];)aa=1+(parseInt(aa.id.slice(4))||0),aa>F&&(F=aa);var T=F;Qa("rcy_bin_tg",pa=>{function Wa(D){if(void 0===Aa[D]&&!na("tg_tabs"+(D||"")))return r={id:"tabs"+(F||""),name:x,type:J||Md,t0:y},Ed.splice(v,0,r),Id(r),h(),1}
var Aa=pa||[];for(pa=0;void 0!=Aa[pa++];);for(pa=0;!Wa(F)&&pa<T+1024;)pa++,F=pa})}
function k(x){v=Ed.indexOf(n);p=1;if(x){Ed.splice(v,1);if(n==lb){(r=Ed[v])||(r=Ed[v-1]);if(!r){d(L("q"));return}Id(r)}Qa("rcy_bin_tg",y=>{y=y||[];y.push(n);75<y.length&&y.splice(0,25);Ua("rcy_bin_tg",y)});
Qa(n.id,y=>{"string"===typeof y&&(y=JSON.parse(y));if(y)for(var J=0,F;F=y[J++];)Ka.remove(hc(F,n))});
Ka.remove("v_"+n.id+"__");h()}else v++,Qa("rcy_bin_tg",y=>{y=y||[];r=y.pop();Ed.splice(v,0,r);Id(r);h();Ua("rcy_bin_tg",y)})}
function h(){Tb();if(p||r)bd.dirty(),Gd(Ed)}
var p=0,n=X.d,r,v;switch(a){case "rename":if(a=prompt(L("nb"),n.name))n.name=a,p=1;break;case "newGroup":(a=prompt(L("m"),L("di")))&&d(a,3);return;case "ngpEmpty":d(L("q"));return;case "ngpBar":d(L("2n"),0,Xc);return;case "ngpBkmk":d("bookmarks",1);return;case "ngpSch":d(L("4s"),2);return;case "close":k(!0);return;case "restore":k(!1);return;default:return wb[a]=b,1}h();return 1}
function Jd(a){if(window.oncontextmenu==$b)$b(a);else{Ad();for(var b=a.target,c=b==bd;!c&&b&&!b.classList.contains("tg");)b=b.parentNode;c=["",[0,["rename",0],[L("5y")],1],[0,["newGroup",0],[L("9")],1,,[0,["ngpEmpty",0],[L("q")]],[0,["ngpBar",0],[L("2n")]],[0,["ngpBkmk",0],[L("8r")]],[0,["ngpSch",0],[L("4s")]]],[0,["close",0],[L("b")],1,[0,["restore",0],[L("dy")]]]];cc(c,Nd,a,b,Jd);if(ec()){Z.e=a;if(a=na("selTabs",fc()))a.title=L("f"),a.oncontextmenu=d=>{od(Y);Fa(d);Tb()};
if(a=na("rename",fc()))a.onmousedown=d=>{1==d.button&&(Fa(d),d.target.click())}}}}
function Ad(){if(bd._dirty>l.verTG){for(var a=[],b=0,c;c=bd.children[b++];)c.d&&void 0!=c.d.id&&a.push(c.d);Ua("tab_groups",a,()=>{l.verTG=bd._dirty})}}
var Od=-1,Pd;function Qd(){clearTimeout(Od);var a=na("toastview");a.style.opacity=0;Od=setTimeout(function(){Od=-1;a.style.display="none"},300)}
function Nb(a,b,c,d,k){-1!=Od&&clearTimeout(Od);d||(d=B.body);var h=na("toastview");h||(h=M(0,d),h.id="toastview",M(0,h).id="toasttext");var p=h.parentNode;p!=d&&(p&&h.remove(),d.appendChild(h));d=h.firstChild;d.innerHTML=a;d.className=1<=b?"warn":"info";Od=setTimeout(Qd,c||1E3);setTimeout(function(){h.style.opacity=1},16);
h.style.display="block";d.style.opacity=k||1}
function Gb(a,b){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},b||599)}
var Rd;
function Ec(a){if(Rd)a(Rd);else{var b=z.pendingUrl||z.url,c=(new URL(b)).searchParams,d=c.get("q")||c.get("wd")||c.get("search")||c.get("searchkey")||c.get("keyword")||c.get("query")||c.get("sokeytm")||c.get("char")||c.get("text")||c.get("queryField_a")||c.get("w")||c.get("q1")||c.get("terms")||c.get("term");null===d&&(c=b.indexOf("zdic.net/hans/"),0<c&&(d=b.slice(14)),0>c&&(c=b.indexOf("dictionary/"),0<c&&(d=b.slice(11))),0>c&&(c=b.indexOf("/zh/"),0<c&&(d=b.slice(4))),0>c&&(c=b.indexOf("/search/"),0<
c&&(d=b.slice(c+8))),d&&(c=d.indexOf("?"),0<c&&(d=d.slice(0,c))));null===d&&(d="");d=decodeURIComponent(d).replace(/\+/g," ");fa?chrome.tabs.executeScript(z.id,{code:"window.getSelection().toString()"},function(k){k&&k[0]?a(k[0]):a(d)}):a(d)}}
function hc(a,b){return"v_"+(b||lb).id+"_"+a.id}
function Cc(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return'url("chrome://favicon/'+a+'")'}
function Sd(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return"chrome://favicon/"+a}
function Td(a){for(var b=0,c=0,d=0,k=a.length/4,h=0;h<a.length;h+=4)b+=a[h],c+=a[h+1],d+=a[h+2];return"rgb("+Math.round(b/k)+","+Math.round(c/k)+","+Math.round(d/k)+")"}
function Ud(a){for(var b={},c=0,d=null,k=0;k<a.length;k+=4){var h=a[k],p=a[k+1],n=a[k+2];255==a[k+3]&&(h=h+","+p+","+n,b[h]?b[h]++:b[h]=1,b[h]>c&&(c=b[h],d=h))}return"rgb("+d+")"}
var Kd;function Vd(a){l.initSortable(B,G);Kd=new Sortable(bd,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabG",root:!0,forceFallback:!1,sort:!0,anisk:1,onMove(b){this.options.animation=300;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){Kd.did(b)&&bd.dirty()},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;G.disani=0},click(b){Hd(b)},trace:function(){console.log("trace"+Error().stack)}});
a&&(Kd._onTapStart(a),a.constructor==DragEvent?Kd._onDragStart(a):Kd._onDrop(a),Ld(a,1))}
function Ld(a,b){Kd?a&&(b?bd.onclick=a.target.ondragstart=void 0:Ld(a,1)):l.initSortable&&!Eb?Vd(a):l.loadSortable(function(){Vd(a)})}
function Zb(a){return`<div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">
            <div style="white-space:nowrap;font-size:.89em;padding-right:10px;text-align:center;padding-top:7.9px;">${a}</div>
            <textarea class='eta' style="flex:1;resize:vertical;min-height:30px;font-size: large;padding-left: 17px; padding-top: 10px;"></textarea>
        </div>`}
function ac(a){return a.type==Ba&&!a.path.startsWith("q=")&&!a.path.startsWith("recent")}
function sd(a,b,c){function d(r){sa("hot",td)?.classList.remove("hot");r.target.classList.add("hot");c(r.target.idx)}
var k=Z.style;if(!td){td=M(0,0,"tabG");var h=td.style;h.position="fixed";h.height="auto";h.background="white";h.borderRadius="4px";h.transform="scale(0.9)";h.transformOrigin="left";h.boxShadow=getComputedStyle(Z.cards[0]).boxShadow}h=td.style;td.innerText="";for(var p=0;p<a.length;p++){var n=M(0,td,"tg"+(b==p?" hot":""));n.idx=p;wa(n,a[p]);n.onclick=d}h.left=parseInt(k.left)+1.5+"px";k.top?(h.bottom=Z.parentNode.offsetHeight-parseInt(k.top)-.75+"px",h.top=""):(h.top=Z.parentNode.offsetHeight-parseInt(k.bottom)+
"px",h.bottom="");na("menup").insertBefore(td,Z)}
function ec(){return!!G.SettingsBuildCard}
function fc(){return Z.shadowRoot||B}
function Gb(a){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},599)}
function Kb(a){chrome.bookmarks.search({url:z.url},function(b){a(ea=b?b[0]:0)})}
function Lb(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(z=b?b[0]:0)})}
function Ob(a,b){chrome.tabs.query({url:a},b)}
function Bd(){var a=Xa.bkmks.indexOf(bb);0<=a&&Xa.bkmks.splice(a,1)}
function Fb(a){return void 0!=a.dateGroupModified}
function bc(a,b){try{return(new URL(a)).hostname===(new URL(b)).hostname}catch(c){}}
function Wd(a){R.et.value=a.target.innerText}
function zc(){l.getSchKeys(a=>{Ac.innerHTML="";for(var b=a.length-1;0<=b;b--){var c=a[b],d=M(0,Ac,"sch-item");d.onclick=Wd;wa(d,c)}})}
function Cd(a){Yb("assets/dialog.js",function(){var b=showDialog(B,B.body);wa(b.t,"Edit");xa(b.t1,Zb("CODE"));wa(b.btn0,"Save");var c=a.tabView,d=c?._bg,k=qa("TEXTAREA",b.t1);c?(k[0].value=d.src,b.btn0.onclick=()=>{var h=k[0].value;Ua(c.k+"_",h,p=>{d.src=h;c.reload(d);b.s.remove()})}):Qa(hc(a.d)+"_",h=>{k[0].value=h;
b.btn0.onclick=()=>{var p=k[0].value;Ua(hc(a.d)+"_",p,n=>{b.s.remove()})}});
b.btn1.onclick=()=>{b.s.remove()}},G.showDialog)}
function Ub(){return navigator.userAgent.includes("Edg/")}
;