'use strict';var data={},fakePP=0,debug=console.log,log=console.log,verTG=0,_DEBUG=1,num_tabs=0;function geVal(a,b){chrome.storage.local.get(a,b)}
function getVal(a,b){geVal(a,c=>{b(c[a])})}
function tVal(a){}
function seVal(a,b){chrome.storage.local.set(a,b)}
function setVal(a,b,c){var k={};k[a]=b;seVal(k,c)}
function gm(a){return chrome.i18n.getMessage(a)||a}
var menu=chrome.contextMenus;_DEBUG&&menu.removeAll();(function(){function a(g){if(1>g)throw Error("长度不能小于1");var e={};e.data=new Map;e.sz=g;e.set=function(f,l){var m=e.data,q=e.sz;m.delete(f);m.set(f,l);m.size>q&&(f=m.keys().next().value,m.delete(f))};
e.get=function(f){var l=e.data;if(l.has(f)){var m=l.get(f);l.delete(f);l.set(f,m);f=m}else f=null;return f};
return e}
function b(g,e){var f=popupCache.bkmk?.id;if(f==g||f==e)popupCache.bkmk=0;(f=c!=g&&(!e||e!=k))||(h=Date.now(),f=100<=h-n);if(f){n=h;c=g;k=e;f=0;for(var l,m;l=data.bkmks[f++];){if(m=l[g])m.data=null,m.stl=!0,m.ver++;e&&(m=l[e])&&(m.data=null,m.stl=!0,m.ver++)}}}
(function(){chrome.bookmarks.onMoved.addListener(function(g,e){b(e.oldParentId,e.parentId);g==navBkmk&&fixNav()});
chrome.bookmarks.onRemoved.addListener(function(g,e){b(e.parentId);g==navBkmk&&fixNav()});
chrome.bookmarks.onCreated.addListener(function(g,e){b(e.parentId)});
chrome.bookmarks.onChanged.addListener(function(g,e){chrome.bookmarks.get(g,function(f){f&&f.length&&b(f[0].parentId)})});
chrome.bookmarks.onChildrenReordered.addListener(function(g,e){b(g)})})();
var c,k,n=0,h=0,p=a(5);window.newLru=a;window.pullBkmk=function(g,e,f,l){if(l){f&&(popupCache={});for(var m=0,q;q=data.bkmks[m++];)if(q=q[g])q.data=null,q.stl=!0,q.ver++}if(popupCache.bkmk?.id===g&&popupCache.bkmk?.data)e(popupCache.bkmk?.data);else if(g.startsWith("recent"))l=parseInt(g.slice(6).replaceAll("=","").trim())||1E3,chrome.bookmarks.getRecent(l,function(r){e(r);f&&(popupCache.bkmk={id:g,data:r})});
else if(g.startsWith("q="))chrome.bookmarks.search(g.slice(2),function(r){e(r);f&&(popupCache.bkmk={id:g,data:r})});
else{var t=0;if(!l){m=0;for(var u;q=data.bkmks[m++];)if((u=q[g])&&u.data){t=u.data;break}}t?(setTimeout(function(){e(t)},0),f&&(popupCache.bkmk={id:g,
data:t})):chrome.bookmarks.getChildren(g,function(r){p.set(g,r);e(r);f&&(popupCache.bkmk={id:g,data:r})})}}})();
data.bkmks=[];function d(){return data}
loadJs("tabModel.js",function(){});
menu.create({id:"open_page",title:gm("n"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp",title:gm("6"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp1",title:gm("6")+" ("+gm("ku")+")",contexts:["browser_action","page_action"]},()=>{});
var _MD;menu.onClicked.addListener(func);function func(a){a=a.menuItemId;"open_page"==a&&chrome.tabs.create({url:`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html`});"add_tmp"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b)});
"add_tmp1"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b,0,!0)});
_DEBUG&&_MD&&_MD(a)}
var tmpUrlData,tmpUrlPath,tmpUrlDataDirty,impUrlTd={};function getImpd(a){if(a==tmpUrlPath&&tmpUrlData)return tmpUrlData}
function cacheImpd(a,b){getTmpUrlPath(c=>{a==c&&(tmpUrlData=b)})}
function getTmpUrlPath(a){tmpUrlPath?a(tmpUrlPath):getVal("sel_tmp_url",b=>{b||="";b.startsWith("imp_")||(b="imp_tmp");tmpUrlPath=b;a(tmpUrlPath)})}
function setTmpUrlPath(a,b){tmpUrlPath!=a&&(tmpUrlDataDirty&&saveTmpUrls(),tmpUrlData=tmpUrlPath=0,setVal("sel_tmp_url",a,b))}
getTmpUrlPath(()=>{});
function getTmpUrlData(a){tmpUrlData?a(tmpUrlData):getTmpUrlPath(b=>{getVal(b,c=>{c||={};c.data||(c.data=[]);tmpUrlData=c;a(c)})})}
function pullImpt(a,b){var c=tmpUrlPath===a;if(c&&tmpUrlData)b(tmpUrlData);else{var k=0;if(!k){for(var n=0,h;(h=data.bkmks[n++])&&!(k=h[a]););k?(setTimeout(function(){b(k)},0),c&&(tmpUrlData=k)):getVal(a,p=>{p||={};
p.data||(p.data=[]);parseInt(p.v)&&(p.v=0);"string"==typeof p.data&&(p.data=JSON.parse(p.data));b(p);c&&(tmpUrlData=p)})}}}
function addToTmpUrls(a,b,c,k,n){getTmpUrlData(h=>{function p(l){n?h.data.splice(0,0,l):"add"==h.data[h.data.length-1]?.url?h.data.splice(h.data.length-1,0,l):h.data.push(l);tmpUrlDataDirty=!0;h.v=(h.v||0)+1}
for(var g=!1,e=0;e<h.data.length;e++)if(h.data[e].url===a){n?h.data.splice(e,1):g=!0;break}if(!g){var f=c?.url;function l(){b=f.slice(f.indexOf(":")+3);0<b.indexOf("/",5)&&(b=b.slice(0,b.indexOf("/",5)))}
void 0!==b||f.startsWith("chrome")||f.startsWith("edge")?(b||l(),p({url:a,title:b,favIconUrl:c.favIconUrl}),k&&k(h.data)):chrome.tabs.executeScript(c.id,{code:`window._tmpUrl=\"${a.replace('"',"")}\";window._tmpTop=${n}`},function(m){chrome.tabs.executeScript(c.id,{file:"js/tada_active.js"},function(q){(b=q[0])&&"undefined"!=b||l();p({url:a,title:b,favIconUrl:c.favIconUrl});k&&k(h.data)})})}})}
menu.create({title:gm("t7"),contexts:["link"],onclick:function(a,b){setTimeout(()=>{var c=Date.now()-topTempTime;addToTmpUrls(a.linkUrl,void 0,b,0,100>c&&0<=c)},50)}});
function loadSortable(a){loadJs("popup/Sortable.js",function(){a()})}
function loadListView(a){loadJs("popup/ListView.js",function(){a&&a()})}
function loadJs(a,b){var c=document.createElement("script");c.type="text/javascript";c.onload=b;c.src=a;document.body.appendChild(c)}
var lastAct,bkWnds={};chrome.tabs.onActivated.addListener(function(a){bkWnds[lastAct]&&chrome.tabs.sendMessage(lastAct,{name:"blur"},function(b){});
bkWnds[lastAct=a.tabId]&&chrome.tabs.sendMessage(a.tabId,{name:"focus"},function(b){});
tmpUrlDataDirty&&saveTmpUrls()});
data.favTabsVer=data.favTabsSave=data.tabsVer=0;function saveImportabs(a,b){cacheImpd(a,b);setVal(a,b,function(){})}
chrome.tabs.onUpdated.addListener(function(a,b,c){if(a=data.favTabs[a])data.favTabsVer++,a.lastUrl=a.url!=c.url?c.url:void 0});
chrome.tabs.getAllInWindow(null,function(a){num_tabs=a.length});
chrome.tabs.onCreated.addListener(function(a){num_tabs++});
chrome.tabs.onRemoved.addListener(function(a){num_tabs--;0==num_tabs&&onClose()});
function onUnLoad(){chrome.storage.local.set({date:Date.now()},function(){})}
function saveTmpUrls(){tmpUrlDataDirty=0;tmpUrlData&&setVal(tmpUrlPath,tmpUrlData)}
function onClose(){data.favTabsSave!=data.favTabsVer&&saveImportabs();onUnLoad();tmpUrlDataDirty&&saveTmpUrls()}
chrome.runtime.onMessage.addListener(function(a,b,c){if(a&&a.type&&("load_url"==a.type&&searchActiveTab(n=>{chrome.tabs.update(n.id,{url:a.url})}),"paste"==a.type&&sendPasteToContentScript(a.data),"openAll"==a.type)){b=a.urls.split("{BKMKBK}");
c=0;for(var k in b){let n=b[k];setTimeout(function(){n&&chrome.tabs.create({url:n,active:!1})},500*c);
c++}}});
function getContentFromClipboard(){var a="",b=document.getElementById("sandbox");b.value="";b.select();document.execCommand("paste")&&(a=b.value,console.log("got value from sandbox: "+a));b.value="";return a}
function sendPasteToContentScript(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){chrome.tabs.sendMessage(b[0].id,{data:a})})}
var topTempTime,navPath,navCtx,navBkmk;function fixNav(){navBkmk&&navCtx.idx--}
function navNxt(a){if(void 0===a){a=!0;var b=Date.now()-topTempTime;100>b&&0<=b&&(a=!1)}var c=navPath;!c.startsWith("q=")&&isNaN(c)||pullBkmk(c,k=>{var n=navCtx.idx;n+=a?1:-1;navCtx.idx=n;navCtx.ni&&(n=k.length-n-1);var h=k[n];h&&(navBkmk=h.id,searchActiveTab(p=>{chrome.tabs.update(p.id,{url:h.url})}))});
c.startsWith("imp")&&pullImpt(c,k=>{var n=navCtx.idx;navCtx.tmp&&a||(n+=a?1:-1);var h=k.data[navCtx.idx=n];h&&(navCtx.tmp&&(k.data.splice(navCtx.idx,1),saveImportabs(c,k)),searchActiveTab(p=>{chrome.tabs.update(p.id,{url:h.url})}))})}
chrome.commands.onCommand.addListener(function(a){"top-temp-url"==a&&(topTempTime=Date.now());"next-item"==a&&navPath&&navNxt();"prev-item"==a&&navPath&&navNxt(!1)});
var schKeys=void 0;function getSchKeys(a){void 0==schKeys?getVal("sch_keys",b=>{a(schKeys=b||[])}):a(schKeys)}
function putSchKey(a){getSchKeys(b=>{if(b[b.length-1]!=a){for(var c=0;c<b.length;c++)if(b[c]==a){b.splice(c,1);break}b.push(a);25<b.length&&b.splice(0,b.length-20);setVal("sch_keys",b)}})}
function exportSettings(a){chrome.storage.local.get(null,function(b){console.log(b);a&&a(b)})}
function importSettings(a,b){try{a=JSON.parse(a)}catch(c){console.log(c)}"object"===typeof a&&chrome.storage.local.set(a,function(c){b&&b(c)})}
function searchActiveTab(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(b?b[0]:0)})}
;