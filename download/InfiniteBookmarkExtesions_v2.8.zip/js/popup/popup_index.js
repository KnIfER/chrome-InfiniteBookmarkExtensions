'use strict';var p=chrome.extension.getBackgroundPage(),ba=4;if(p.fakePP){if(400>(new Date).getTime()-p.fakePP)throw setTimeout(function(){window.close()},200),1;
p.fakePP=0}const ca=15,da=0,fa=1,ha=2;var ia,la,ra,ua=location.href==`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html?popup=1`,wa=console.log,za=console.log,Aa=console.error,w=document,A=window,Ba,Ca=0,Da=void 0;A.isPopup=ua;function G(a,b){return(b||w).getElementById(a)}
function Ea(a,b){return(b||w).getElementByTagName(a)[0]}
function Fa(a,b){return(b||w).getElementsByTagName(a)}
function Ga(a,b){return(b||w).getElementsByClassName(a)[0]}
function Ha(a,b){return(b||w).getElementsByClassName(a)}
function J(a){return chrome.i18n.getMessage(a)||a}
function Ia(a,b){a.innerText=b}
function Ja(a,b){a.innerHTML=b}
function La(a,b,c){for(;b;){if(b.classList&&b.classList.contains(a))return b;if(c&&b==c)break;b=b.parentNode}}
function Ma(a,b,c,d){d||=win;d.addEventListener(a,b,c)}
function Na(a,b,c,d){d||=win;d.removeEventListener(a,b,c)}
function Oa(a){var b=a.path||"";a=a.type;a==Ra?b.startsWith("recent")||(/^\d+$/g.test(b)?b="chrome://bookmarks/?id="+b:(b.startsWith("q=")&&(b=b.slice(2)),b="chrome://bookmarks/?q="+b)):a==Sa&&(b.startsWith("recent")||(b="important://"+b.slice(4)));return b}
function N(a,b,c,d){a=w.createElement(a||"DIV");c&&(a.className=c);d&&(a.style=d);b&&b.appendChild(a);return a}
function R(a,b){try{b?a.stopImmediatePropagation():a.stopPropagation(),a.preventDefault()}catch(c){Aa(c)}}
function Ma(a,b,c,d){(d||A).addEventListener(a,b,c)}
function Ta(a,b,c,d){(d||A).removeEventListener(a,b,c)}
function Ua(a){function b(c){Ta("copy",b,!0,w);R(c,1);c.clipboardData.setData("text/plain",a)}
Ma("copy",b,!0,w);w.execCommand("copy");Ta("copy",b,!0,w)}
const Va=chrome.storage.local;function Wa(a,b){Va.get(a,b)}
function Ya(a){Va.get(a,b=>{console.log(b[a])})}
function Za(a,b){Wa(a,c=>{b(c[a])})}
var ab={};function bb(a,b){ab[a]?b(ab[a]):Za(a,c=>{b(ab[a]=c)})}
function cb(a,b){Va.set(a,b)}
function db(a,b,c){var d={};d[a]=b;cb(d,c)}
function eb(a,b){Va.remove(a,b)}
var fb=p.d(),gb,hb,ib={},kb=N("style",document.head);ib.reload=()=>{setTimeout(()=>{location.reload()},350)};
fb.bkmks.push(ib);N("style",document.head).innerText=`.folder-icon > .item-icon{-webkit-mask-image:url("chrome-extension://${chrome.runtime.id}/images/folder_open.svg")}`;kb.innerText=".img,IMG,.fico{display:none!important}";var lb=G("tabos"),mb=G("tabNew"),U=mb.parentNode,nb=U.parentNode,ob,X,pb=[],rb,sb,vb,wb,xb,yb,zb,Ab={},Bb={},Cb={},Db,Fb=fb.opt;Fb||(fb.opt=Fb={autoExp:1,mcTab:1,tkImp:0,topImp:0,uniImp:1});w.title=J("ri");var Gb,Ib;
function Jb(a,b,c){if(a){a=a.classList;var d=a.contains(b);if(void 0===c||d^!!c)d?a.remove(b):a.add(b)}}
function Kb(a){return a.path.startsWith("recent")}
function Lb(a,b){p.initListView&&!Mb||p.loadListView();Gb||function(){function d(f,h,x){if(!h.t){var u=h._=h;u.classList.add("item-wrap");h.dot=N("P",u,"dot");h.con=N(0,u,"item-icon");h.icon=N(0,h.con,"img");h.lv=N("DIV",u,"item-tlv");h.t=N("P",h.lv,"item-title");h.st=N("P",h.lv,"item-subtitle");h.lv.draggable=!0;h.lv.ondragstart=z;h.lv.ondragend=M;h.ondblclick=sa;h.oncontextmenu=H;h.lst=f}u=f.ada.getItem(x);var v=f.salad;u||={title:""};h.data=u;var y=u.title||" ";if(y.startsWith("(")){var t=y.indexOf(")");
0<t&&(y=y.slice(t+1).trim())}h.t.innerText=y;y=u.url;t=h.icon;h.lv.href=y;Nb(u)^h.folder&&(h.folder=!h.folder,h.folder?(h._.classList.add("folder-icon"),t.style.backgroundImage=""):h._.classList.remove("folder-icon"));var E=v&&v[u.id];Jb(h._,"selecting",E||null);E&&E.e!=h._&&(v[u.id].e=h._);pa==u.id&&ma!=h&&Xa(ma);y?(h.st.innerText=y,h.folder||("javascript:"==y||y.startsWith("javascript:&tm=")||y.startsWith("https://separator")?t.style.backgroundImage="":(u=t.style,v=y,y=v.indexOf("/",v.indexOf(":")+
3),0<y&&(v=v.slice(0,y)),u.backgroundImage='url("chrome://favicon/'+v+'")'))):t.style.backgroundImage="";f.tada===x&&(Ob(h,15),f.tada=void 0)}
function g(f){f=f.target||f;for(var h=0;f;){if(f.data&&f.classList.contains("item")){h=f;break}if(f==w.body||f.classList.contains("ListView"))break;f=f.parentNode}return h}
function k(f){Object.keys(f).forEach(x=>{(x=f[x])&&Jb(x.e,"selecting",0)});
for(var h in f)delete f[h]}
function q(f){if(f){var h=f.tD,x=h.path;ib[x]&&(ib[x].data=0);p.pullBkmk(x,function(u){f.v.onRemove();Gb.bind(f,u,Pb(u,h,x))},ua,!0)}}
function n(f){f=f.ada.dPos(Y.pos+1);1==f&&Qb&&Qb.clientY-X.lv.getBoundingClientRect().y<Y.offsetHeight/2-5&&(f=0);return f}
function l(f,h,x,u){var v=Y.data;h=v.url;var y=Y.lst,t=y.salad,E=function(K){K&&q(y);Rb()};
switch(f){case "fold":var Q=prompt(J("sh"),J("vq"));y=Y.lst;if(Q){var O=n(y);chrome.bookmarks.create({parentId:v.parentId,title:Q,index:O},E)}break;case "addThis":O=n(y);1==O&&Qb&&Qb.clientY-X.lv.getBoundingClientRect().y<Y.offsetHeight/2-5&&(O=0);Sb(K=>{!K||u.ctrlKey?chrome.bookmarks.create({parentId:v.parentId,url:ia.url,title:ia.title,index:O},E):chrome.bookmarks.move(K.id,{parentId:v.parentId,index:O},E)});
break;case "newFav":!u||u.ctrlKey?B(v,y,v.parentId,0,v.index+(y.ada.ni?-1:1),!0):Tb(K=>B(v,y,v.parentId,K,v.index+(y.ada.ni?-1:1)));
break;case "addSep":r(u,v,y);break;case "edit":B(v,y);break;case "replace":B(v,y,void 0,ia);break;case "delete":C(v,y);break;case "openFolder":Ub(ob,{path:v.id});break;case "pinTop":(()=>{function K(ta,ea,Pa,xa){Eb.length?(ea&&(xa=qa[ea.pos],ea.id==ta.id&&(ea.title=ta.title),xa==ea&&(ta=qa.splice(ea.pos,1)[0],ea.pos<Pa&&Pa--,ea.pos=Pa,qa.splice(Pa,0,ta))),L(Eb.shift())):E(ta||1)}
function L(ta){var ea=0,Pa=(ta.title||"").startsWith(ja);if(!I)for(var xa;xa=qa[ea];){if(Pa&&!qb&&xa==ta){S="";ea=0;break}if(!(xa.title||"").startsWith(ja))break;ea++}chrome.bookmarks.move(ta.id,{parentId:ta.parentId,index:ea},Wb=>{S&&Wb&&!Pa&&!I?chrome.bookmarks.update(ta.id,{title:S+ta.title},Gc=>{K(Gc,ta,ea)}):K(Wb,ta,ea)})}
var I=!u||u.ctrlKey||u.shiftKey,S="\ud83d\udccc ",ja=S.trim(),qa=listView.arr,qb=D(v,t),Eb=m(v,t,qb,y);qb=1<Eb.length;K()})();
break;case "pinBot":(()=>{function K(ja){var qa=L.length,qb=(ja.title||"").startsWith("\ud83d\udccc ");chrome.bookmarks.move(ja.id,{parentId:ja.parentId,index:qa},Eb=>{qb&&chrome.bookmarks.update(ja.id,{title:ja.title.slice(3)});S.length?K(S.shift()):E(Eb||1)})}
var L=listView.arr,I=D(v,t),S=m(v,t,I,y);I=1<S.length;S.length?K(S.shift()):E(1)})();
break;case "openAll":f="";for(Q in t)f+=y.arr[t[Q].pos].url+"{BKMKBK}";chrome.runtime.sendMessage({urls:f,type:"openAll"},function(K){});
break;case "copyUrl":Ua(v.url);Vb(v.url);break;case "openInCurrent":Nb(v)?X.etLoca.reload(v.id,v.title):h.startsWith("javascript:")?chrome.tabs.executeScript(ia.id,{code:decodeURIComponent(h.slice(11))},function(K){ua&&window.close()}):chrome.tabs.update(ia.id,{url:h},function(K){ua&&window.close()});
ya();break;case "openInNewTab":Xb(v.url,function(K){K&&0<K.length?chrome.tabs.update(K[0].id,{active:!0}):chrome.tabs.create({url:v.url})});
ya();break;case "openInBackgroud":Tb(K=>{chrome.tabs.create({url:v.url,index:K.index+1,active:!1})});
ya();break;case "openInTmp":(()=>{var K=D(v,t),L=m(v,t,K,y);K=1<L.length;for(var I=0;K=L[I];I++)p.addToTmpUrls(K.url,K.title||"",0,()=>{L[I+1]||Ob(Y)})})();
break;case "openInIframe":Q=p.newTab(Ab,v.url,Yb,U);Q.title=v.title;Zb($b([Q],0,ob.nextSibling));U.dirty();break;default:return 1}ac();return 1}
function r(f,h,x,u){u=u?"https://separator.mayastudios.com/index.php?t=horz":"javascript:";bc()&&(u+="&tm="+Date.now());chrome.bookmarks.create({parentId:h.parentId,url:u,title:"───────────",index:x.ada.dPos(Y.pos+1)},function(v){v&&(q(x),ac(),(f.ctrlKey||1==f.button)&&B(v,x))})}
function D(f,h){return h[f.id]&&1<Object.keys(h).length}
function m(f,h,x,u){var v=u.arr,y=[],t=!1;if(x){for(var E in h)if(x=u.ada.d4sa(E,h[E]),x=v[x])t||x!=f||(t=!0),y.push(x);y.sort(function(Q,O){return Q.pos-O.pos})}t||y.push(f);
return y}
function B(f,h,x,u,v,y){cc("assets/dialog.js",function(){var t=showDialog(w,w.body);Ia(t.t,J("i"));Ja(t.t1,dc(J("9p").toUpperCase())+dc(J("ye").toUpperCase()));var E=void 0!==x;Ia(t.btn0,E?J("si"):J("x"));Ia(t.btn1,J("s"));var Q=Fa("TEXTAREA",t.t1);Q[0].value=u?.title||f.title;var O=u?.pendingUrl||u?.url||f.url||"";O.startsWith("javascript:")&&(O=decodeURIComponent(O));Q[1].value=O;t.btn0.onclick=()=>{var K=Q[1].value;y&&bc()&&(K+=(K.includes("?")?"&":"?")+"tm="+Date.now());K.startsWith("javascript:")&&
(K="javascript:"+encodeURIComponent(K.slice(11)));var L=I=>{I&&(q(h),t.s.remove());Rb()};
K={url:K,title:Q[0].value};E?(K.parentId=x,K.index=v,chrome.bookmarks.create(K,L)):chrome.bookmarks.update(f.id,K,L)};
t.btn1.onclick=()=>{t.s.remove()}},A.showDialog)}
function C(f,h){var x=h.salad,u=D(f,x),v=m(f,x,u,h);cc("assets/dialog.js",function(){var y=showDialog(w,w.body);Ja(y.t,J("6l"));Ja(y.t1,J("w8").replace("size",v.length));Ia(y.btn0,J("8q"));Ia(y.btn1,J("s"));y.btn0.onclick=()=>{var t=()=>{chrome.bookmarks.remove(v.shift().id,function(){0==v.length?q(h):t();Rb()})};
t();y.s.remove()};
y.btn1.onclick=()=>{y.s.remove()}},A.showDialog)}
function H(f){if(window.oncontextmenu==ec)ec(f);else{var h=g(f);if(h){fc(h);var x=h.data,u=h.lst,v=D(x,u.salad),y=gc(u.tD),t=hc(x.url,ia.url);v=0==Ic?["",[0,y?"addThis":0,J("77"),1,,[0,"addSep",J("w")],[0,"fold",J("sh"),1],[0,"newFav",J("6"),1]],[0,y?0:"openFolder",J("k"),1],[0,v?"openAll":0,J("8t")],[0,"edit",J("p"),1],[0,"delete",J("4")],[0,t||f.altKey?"replace":0,J("r5")],[0,"pinTop",J("hz"),1],[0,"pinBot",J("lz")]]:["",[0,"openInCurrent",J("k7")],[0,"openInNewTab",J("g")],[0,"openInBackgroud",
J("c1")],[0,"openInTmp",J("n")],[0,"openInIframe",J("h6")],[0,"copyUrl",J("py")]];ic(v,l,f,h,H,[J("g1"),J("o")],Ic,E=>{p.menuPageBkmk=Ic=E;H(f)});
Qb=f;jc=function(){fc()};
if(kc()){v=lc();if(h=G("addSep",v))h.title=J("5j"),h.oncontextmenu=E=>{R(E);r(E,x,u,!0)},h.onmousedown=E=>{1==E.button&&(R(E),r(E,x,u,!0))};
if(h=G("openInCurrent",v))h.title=J("右键不关闭弹窗"),h.oncontextmenu=E=>{chrome.tabs.update(ia.id,{url:x.url},function(Q){ac()});
R(E);ya()};
if(h=G("newFav",v))h.title=J("4r"),h.oncontextmenu=E=>{l("newFav");R(E)};
if(h=G("pinTop",v))h.oncontextmenu=E=>{l("pinTop");R(E)}}}}}
function V(f,h,x){f.innerText=h.ni?"⇈":"⇊";f.title=h.ni?J("9i"):J("xx91");x&&(x=f.title,x=h.ni?"⇈&emsp;"+x:x+"⇊",Vb(x))}
function na(f,h){h=h.icon;return f.clientX>h.offsetLeft+h.offsetWidth}
function T(f,h,x,u){var v=f.ver;f=f.salad;h?(Jb(h,"selecting",x),x?f[h.data.id]={pos:h.pos,e:h,ver:v}:delete f[h.data.id]):void 0!=u&&(f[x.id]={pos:u,ver:v})}
function Xa(f){ma=f;f.lst.sel=qc=f.pos;pa=f.id}
function ya(f){f||=Y;p.navPath=f.lst.tD.path;p.navCtx={idx:f.pos,ni:f.lst.ada.ni};p.navBkmk=f.data.id}
function sa(f){if(!mc){var h=g(f);if(h){fc(h);ya(h);var x=f.target==h.icon;if(na(f,h)||x){var u=h.data;if(h=u.url)x||f.shiftKey||f.ctrlKey?Tb(t=>{x||f.shiftKey?chrome.tabs.update(t.id,{url:u.url},function(){ua&&!f.ctrlKey&&window.close()}):f.ctrlKey&&Xb(u.url,E=>{E&&0<E.length?chrome.tabs.update(E[0].id,{active:!0}):chrome.tabs.create({url:u.url,
active:!1,index:t.index+1})})}):window.open(h);
else if(u.dateGroupModified){if(!f.ctrlKey){h=0;for(var v;v=U.children[h++];)if(v.d?.path==u.id&&v.type==Ra){var y=v;break}}y?Zb(y):(y=p.newTab(Ab,u.id,0,U),y.title=u.title,Zb($b([y],0,ob.nextSibling)));U.dirty()}}}}}
function va(f){if(!mc)if(Ka){if(0==f.button){var h=g(f);h||(h=f.target,h=h.classList.contains("ListView")?{pos:h.ada.size,lst:h,data:{parentId:h.tD.path},getBoundingClientRect:function(){}}:0);
if(h){if(Kb(h.lst.tD))return;var x=h.getBoundingClientRect()||{};x=f.clientY>x.y+x.height/2;var u=h.data,v=$a.data;f=$a.pos-h.pos;var y=$a.lst==h.lst?0:h.lst;if(f||y){f=h.pos+1;x||f--;X.onRemove();var t=$a.lst,E=t.v,Q=t.salad;h=Object.keys(Q);var O=E.tP.pos,K=h[0].ver,L=0;x=t.ada.ni;try{h=h.sort(function(ea,Pa){if(Q[ea].ver!=K)throw L=1,1;return Q[ea].pos-Q[Pa].pos})}catch(ea){}L&&(h=t.ada.sort(Q,h.length));
x&&h.reverse();f<=O&&(O=0);function ta(ea,Pa){chrome.bookmarks.move(ea[ea.nxt],{index:Pa,parentId:u.parentId},function(xa){ea.nxt++;if(xa){var Wb=Q[xa.id],Gc=Wb.pos;O&&Gc<O&&E.tP.pos--;y&&(v.parentId==xa.parentId||Kb(t.tD)||delete Q[xa.id],y.salad[xa.id]={id:Wb.id});ea.nxt<ea.length?ta(ea,xa.index+1):xa=0}if(!xa){var nd=ob.d.path;p.pullBkmk(nd,function(od){P(X.lv,od,Pb(od,ob.d,nd))})}})}
h.nxt=0;t=y||t;f=t.ada.dPos(f);ta(h,f)}}aa()}}else if(h=g(f)){t=h.lst;var I=h.data.id;Q=t.salad;f.ctrlKey||k(Q);x=na(f,h);if(f.shiftKey){if(T(t,h,1),ma&&ma.lst==t){I=h;var S=h.pos-qc,ja=0<S,qa;0>S&&(S=-S);S++;for(qa=S;0<qa;){var qb=h.pos+(ja?-1:1)*(S-qa),Eb=t.ada.getItem(qb);T(t,I,Eb,qb);I&&=t.rowSibling(I,ja);qa--}}}else x&&!Q[I]?T(t,h,1):(T(t,h,0),x||(t.sel=null));!x||ma&&f.shiftKey||Xa(h)}else f.ctrlKey||f.shiftKey||(h=La("ListView",f.target))&&k(h.salad)}
function Qa(f,h){h=f.button;if(h==fa)if(f.clientX<2*w.body.clientWidth/3){if(h=g(f))f.r=h,Ka||fc(h),f.lv=h.lst,f.sy=f.lv.scrollTop,oa=f}else oa=0;else h==da?Ka||fc():h!=ha||Ka||mc||pd.md(f)}
function jb(f){if(f.button==fa){var h=0,x=oa;if(!x)return;var u=x.lv,v=x.r;v&&u&&(f.srcElement==x.srcElement&&u.scrollTop==x.sy&&x.clientX==x.clientX&&x.clientY==x.clientY&&na(x,v)&&(h=1,chrome.tabs.create({url:v.lv.href||"about:blank",active:!1}),ka=u.scrollTop,u.onscroll=F,setTimeout(u.onclick=function(){u.onscroll=0;u.onclick=va},300),Date.now(),nc(),ya(v)),oa=0);
h||Ka||fc()}Ka&&f.button==ha&&(oc(),aa())}
function F(f){f.srcElement.scrollTop=ka}
function z(f){if(f.ctrlKey||f.shiftKey||Ka||mc)ec(f);else{var h=f.target.href;"add"==h&&(h="平典搜索");f.dataTransfer.setData("url",h);$a&&($a.classList.remove("sorting"),$a=0);Ka&&(Ka=0,Hb.hidden=1);if(f=g(f)){h=f.lst;var x=h.salad;x[f.data.id]||k(x);T(h,f,1);$a=f;Xa(f);fc(f)}}}
function M(f){if(f=g(f))Hb||(tb=N(0,0,0,"position:absolute;height:25px;width:50px;background:#2196f3e3;color:#FFF;z-index:9;border-radius:30px;left:10px;text-align:center;z-index:10;pointer-events:none;"),Hb=N(0,0,0,"position:absolute;bottom:0;width:100%;height:39px;background-image:linear-gradient(rgba(0, 0, 0, 0), rgb(90 90 90 / 68%));color:#fff;z-index:9;pointer-events:none;"),N("P",Hb,0,"position:absolute;width:100%;font-size:1em;bottom:0;text-align:center;line-height:0;").innerHTML=J("l")),tb.innerText=
Object.keys(f.lst.salad).length||1,Hb.hidden=0,Ka=f,f=G("tabs"),f.insertBefore(Hb,f.firstChild),f.insertBefore(tb,f.firstChild),w.body.addEventListener("mousemove",W)}
function aa(){Ka&&(Ka=0,Hb.remove(),tb.remove(),w.body.removeEventListener("mousemove",W),ub&&(ub.classList.remove(rc),ub=0),$a.classList.remove("sorting"),$a=0,fc())}
function W(f){if(!Kb(ob.d)){var h=w.elementFromPoint(f.clientX,f.clientY);if(h=g(h)){var x=h.getBoundingClientRect();x=f.clientY>x.y+x.height/2?"drag-below":"drag-above";if(ub!=h||rc!=x)ub&&ub.classList.remove(rc),ub=h;ub.classList.add(rc=x)}}tb.style.left=f.clientX-tb.offsetWidth/2+"px";tb.style.top=f.clientY-tb.offsetHeight+"px"}
function P(f,h,x){var u=f.tP;f.onmousedown=Qa;f.onmouseup=jb;var v={size:h.length,ni:u.ni,bifun:d,getItem:function(y){return h[this.ni?h.length-1-y:y]},
sort:function(y,t){for(var E=[],Q=0;Q<h.length;Q++){var O=h[this.ni?h.length-1-Q:Q],K=y[O.id];if(K&&(K.pos=Q,K.ver=f.ver,E.push(O.id),0>=--t))break}return E},
dPos:function(y){return this.ni?h.length-y:y},
rPos:function(y){return this.ni?h.length-1-y:y},
d4sa:function(y,t,E){var Q=this.rPos(t.pos),O=h[Q];if(O&&O.id==y)return O.pos=Q;Q=-1;if(!E)for(E=0;O=h[E++];)if(O.id==y)return t.pos=this.dPos(E),this.d4sa(y,t,1);return Q}};
f.dVer=x;f.ver=v;f.arr=h;f.ada=v;A.resetLv=()=>{f.reset(v,u.pos||0,u.offset)};
f.reset||p.initListView(f,v,30,"px",A);f.reset(v,u.pos||0,u.offset);pc()}
var ka,oa,pa=-1,ma,qc,$a,ub,rc,Ka,Hb,tb,Ic=p.menuPageBkmk||0,pd={};sc(pd,1,1,g,f=>La("ListView",f.target,c));
Gb={init:function(f,h){function x(L,I){L=L.target;E.ni=!E.ni;null!=t.sel&&(t.sel=t.arr.length-1-t.sel,E.pos=t.sel);I&&(E.pos=0);E.offset=0;P(t,t.arr);V(L,E,!0);t.scrollTop+5<t.scrollHeight-t.offsetHeight&&(t.scrollTop-=t.offsetHeight/2)}
var u=N(0,0,"UiTab"),v=N(0,N(0,u,"UiHead"),0,"display:flex;justify-content:space-between;"),y=N(0,u,"UITabo"),t=N(0,y,"ListView"),E=0;E||(y=tc(f),Za(y,L=>{E=Bb[f.id]=L||{};t.tP=E;V(O,E);h()}));
A.lv=t;y=N(0,v,"folder-icon","padding-left:5px;");N(0,y,"item-icon");y.style.opacity="0.5";var Q=u.etLoca=N("INPUT",v,0,"width:100%");u.etSch=N("INPUT",v,0,"width:65%;margin-left:3px;");u.etSch.placeholder="consider donation to help development";v=N("DIV",v,"tools");var O=N("BUTTON",v,"btn");O.id="top";O.innerText="⇧";O.title=J("8");O=N("BUTTON",v,"btn");O.id="bottom";O.innerText="⇩";O.title=J("qw");O=N("BUTTON",v,"btn");O.innerText="☆";O.id="add";u.star=O;u.reStar=()=>{(L=>{setTimeout(()=>{L.title=
ra?.parentId==f.path?J("c"):ra?J("y5"):J("7u");Ia(L,ra?"★":"☆")},200)})(u.star)};
u.reStar();t.act=L=>{E.pos=E.offset=0;for(var I=t.arr,S=0;S<I.length;S++)if(I[S].id==L){t.tada=t.ada.ni?I.length-1-S:S;E.pos=t.tada-2;break}P(t,I)};
O.oncontextmenu=L=>{R(L);Sb(I=>{uc(u,I)})};
O=N("BUTTON",v,"btn");O.id="sort";O.oncontextmenu=L=>{R(L);x(L,1)};
E&&V(O,E);v.onclick=function(L){var I=L.target;"sort"==I.id?x(L):"top"==I.id?(E.pos=E.offset=0,P(t,t.arr)):"bottom"==I.id?(E.pos=E.offset=0,E.pos=t.arr.length-1,P(t,t.arr)):"add"==I.id&&Sb(S=>{B(S||{url:ia.url,title:ia.title},t,S?void 0:f.path)})};
Q.reload=function(L,I){Pb(null,f);I&&(f.title=I);I=u.taEl;var S=L.startsWith("q="),ja=Ga("title",I);Ia(ja,f.title||J("ar"));Ja(Ga("tabx",I),S?"⌕&nbsp;":"★");S||chrome.bookmarks.get(L,function(qa){qa&&qa.length&&(ja.innerText=qa[0].title)});
f.path=L;p.pullBkmk(L,function(qa){P(u.lv,qa,Pb(qa,f,L))})};
Q.onkeydown=function(L){if("Enter"==L.key){var I=Q.value+"";if(I.startsWith("recent"))f.path=I,Pb(null,f),p.pullBkmk(I,function(ja){P(u.lv,ja,Pb(ja,f,I))});
else if(L=null,L=I.startsWith("chrome://bookmarks/?id=")?parseInt(I.slice(I.indexOf("=")+1)):isNaN(I)?I.startsWith("chrome://bookmarks/?q=")||I.startsWith("q=")?decodeURIComponent(I.slice(I.indexOf("q="))):"q="+I:parseInt(I),null!==L){var S=L+"";S.startsWith("q=")?Q.reload(S,J("81")+S.slice(2)):chrome.bookmarks.get(S,function(ja){ja&&ja.length&&Q.reload(S,ja[0].title)})}U.dirty()}};
u.lv=t;u.tD=f;u.tP=E;t.tabIndex=0;t.v=u;t.ver=0;t.tD=f;t.onclick=va;t.salad=[];A.listView=t;var K;u.onRemove=function(L){try{var I=t.fvp();I&&(E.pos=I.pos,E.offset=t.scrollTop-t.rowOffset(I),db(tc(f),E));K=0}catch(S){Aa(S)}Ba=0};
t.blue=function(){K&&clearTimeout(K);K=setTimeout(u.onRemove,350)};
u.onAttach=function(){u.lv.focus();u.onResume();Ba=u.mu};
u.onResume=function(){var L=f.path,I=ib[L];I&&(!I.data&&I.stl||I.ver!=u.lv.dVer)&&p.pullBkmk(L,function(S){P(u.lv,S,Pb(S,f,L))})};
E&&h();u.mu=jb;return u},
bind:P}}();
var c=Gb.init(a,()=>{p.pullBkmk(b,function(d){if(d){var g=Pb(d,a,b);p.initListView?Gb.bind(c.lv,d,g):p.loadListView(function(){Gb.bind(c.lv,d,a,g)})}else chrome.bookmarks.search(a.title,k=>{k&&(k=k[0],a.path=k.id+"");
p.pullBkmk(a.path,function(q){var n=Pb(q,a,b);p.initListView?Gb.bind(c.lv,q,n):p.loadListView(function(){Gb.bind(c.lv,q,a,n)})})})})});
c.etLoca.value=Oa(a);return c}
function Pb(a,b,c){c||(c=b.path);var d=ib[c];if(!d){if(!a)return;d=ib[c]={s:[],ver:0}}var g=d.s.indexOf(b),k=0<=g;k&&d.s.splice(g,1);if(a){if(d.s.push(b),d.data=a,d.stl=0,!k&&wb){a=[];var q=ib,n;for(n in q)if(c=q[n],c=c.s){g=!0;k=0;for(var l;g&&(l=c[k++]);)if(l.id!=b.id){var r=wb[l.id];void 0!=r&&8>=r&&(g=!1)}else g=!1;g&&a.push(n)}a.forEach(function(D){delete q[D]})}}else 0==d.s.length&&delete ib[c];
return d.ver}
function vc(a,b){return((c,d)=>{function g(F){for(var z,M=0,aa;aa=m.grid(1).el.children[M++];)if(aa.data.url===F){z=!0;break}return z}
function k(F,z,M){var aa=m.grid().el,W=M.ctrlKey;-1==z?(z=ia,M=z.pendingUrl||z.url,!z||!W&&g(M)||(m.layout([{url:M,title:z.title,favIconUrl:z.favIconUrl,tabId:z.id}],0,aa,F),C=H.v)):-2!=z&&-3!=z||chrome.tabs.query(-2==z?{currentWindow:!0}:{},function(P){for(var ka=[],oa=0,pa;pa=P[oa++];)!W&&g(pa.url)||ka.push({url:pa.url,title:pa.title,favIconUrl:pa.favIconUrl,tabId:pa.id});ka.length&&(m.layout(ka,0,aa,F),C=H.v)});
m.dirty()}
function q(F){return F.session?(z=>function(M){chrome.tabs.executeScript(M.id,{code:`var ret=${z.session};
                            for (var key in ret) {
                                sessionStorage.setItem(key, ret[key]);
                            }
                            document.documentElement.scrollTop=ret.scrollTop`},function(aa){})})(F):void 0}
function n(F,z){return 1.25>Math.abs(F-z)}
function l(F,z){chrome.tabs.update(z.id,{active:!0},function(){});
F.tabId=z.id;fb.favTabs[z.id]=F;wc(z.windowId)}
function r(F,z,M){M.navPath=d;M.navCtx={idx:H.data.indexOf(F),tmp:T.tmp,same:T.same};M.navBkmk=0;if(d.startsWith("imp_tmp")){!T.tmp||z||jb&&ua||(xc()&&m.pref("del"),jb=1);var aa=F.url;T.same?chrome.tabs.update(ia.id,{url:aa},q(F)):Tb(W=>{chrome.tabs.create({url:aa,active:!0,index:W.index+1},q(F))});
ua&&window.close()}else chrome.tabs.update(F.tabId||0,{active:!0},function(W){W?(wc(W.windowId),fb.favTabs[W.id]||(fb.favTabs[W.id]=F)):chrome.tabs.query({url:F.url},function(P){(P=P&&P[0])?l(F,P):(P=F.url.lastIndexOf("#"),0<P&&chrome.tabs.query({url:F.url.slice(0,P)},function(ka){ka&&(ka=ka&&ka[0])&&l(F,ka)}))})})}
function D(){setTimeout(()=>m.onAttach(),100)}
d=d||"imp_";var m=N(0,0,"UiTab");m.id=c.id;var B=0,C=0;m.dirty=function(){B=(H.v||0)+1};
m.f1=function(){};
m.onload=function(F){var z=fb.favPlus;z||(z=fb.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`,fixed:1,dyn:1});F.f0=m.layout([z],0,F,0);F.bin=m.bin;F.dirty=m.dirty};
m.onResume=function(){C<H.v&&(C=H.v,m.load())};
var H,V=d,na,T,Xa;m.load=function(){bb(Xa=c.path.includes("tmp")?"opt_imp":"opt_tmp",F=>{T=F||{};void 0==T.tmp&&(T.tmp=c.path.includes("tmp"));void 0==T.same&&(T.same=c.path.includes("tmp"));yc(tc(c),z=>{na=z||{};p.pullImpt(V,M=>{ib[V]=H=M;m.impd=M;B=M.v||0;m.layout(M.data);C=H.v;setTimeout(()=>{m.grid(1).el.parentElement.scrollTop=na.top},10);
setTimeout(()=>{m.grid(1).el.parentElement.scrollTop=na.top},100);
pc()})})})};
m.save=function(){var F=parseInt(m.grid(1).el.parentElement.scrollTop),z=na.top!=F&&m.grid(1).el.children.length;na.top=F;if(B>(H.v||0)){H.v=B;F=[];for(z=m.grid(1).el.firstElementChild;z;){var M=z.data;M&&!M.dyn&&F.push(M);z=z.nextElementSibling}H.data=F;p.log("saving::",V,F);p.saveImportabs(V,H);zc(tc(c),na);C=H.v}else z&&zc(tc(c),na);T.changed&&(delete T.changed,db(Xa,T))};
m.bin=[];m.pref=function(F,z,M,aa){var W=m.grid();M=W.el;var P=Y,ka=0,oa=P.data,pa=q(oa);switch(F){case "del":Y.classList.contains("selected")&&(ka=Ac(W,P));ka||=Bc(W,P,m.bin,W.el);break;case "delSel":ka=Ac(W,P);break;case "restore":ka=Cc(W,P);break;case "moveSel":ka=Dc(W,P);break;case "selAll":Ec(W);break;case "open":Tb(ma=>{chrome.tabs.create({url:oa.url,index:ma.index+1,active:!aa.ctrlKey},pa)});
break;case "addThis":k(!P||P.fixed?0:P.nextSibling,-1,aa);break;case "addWnd":k(!P||P.fixed?P:P.nextSibling,-2,aa);break;case "addAll":k(!P||P.fixed?P:P.nextSibling,-3,aa);break;case "saveSession":Tb(ma=>{chrome.tabs.executeScript(ma.id,{code:"var ret={};\n                                for (var i = 0,key; i < sessionStorage.length; i++) {\n                                    ret[key=sessionStorage.key(i)] = sessionStorage.getItem(key);\n                                }\n                                ret.scrollTop = parseInt(document.documentElement.scrollTop);\n                                JSON.stringify(ret)"},
function(qc){oa.session=qc[0];m.dirty()})});
break;case "restoreSession":aa?pa(ia):Ua(oa.session);break;case "uniImp":return Fb.uniImp=!z,1;case "tweak":return Fb.tkImp=z,1;case "topImp":return Fb.topImp=z,M.f0&&(M.f0.remove(),M.f0=m.layout([M.f0.data],0,M,z?M.firstChild:0)),1;case "isTmp":return T.tmp=!!z,T.changed=1;case "isSame":return T.same=!!z,T.changed=1;case "multi":return P&&W.els(P)||(Fb.mtImp=z),1;case "copyUrl":Ua(oa.url);Vb(oa.url);break;case "openInCurrent":Tb(ma=>{chrome.tabs.update(ma.id,{url:oa.url},function(){pa&&pa(ma);ua&&
void 0!=aa&&window.close()})});
break;case "openInNewTab":Xb(oa.url,function(ma){ma&&0<ma.length?(chrome.tabs.update(ma[0].id,{active:!0}),pa&&pa(ma[0])):chrome.tabs.create({url:oa.url},pa)});
break;case "openInBackgroud":Tb(ma=>{chrome.tabs.create({url:oa.url,index:ma.index+1,active:!1},pa)});
break;case "openInIframe":M=p.newTab(Ab,oa.url,Yb,U);M.title=oa.title;Zb($b([M],0,ob.nextSibling));U.dirty();break;case "topImp1":F=oa.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`};m.layout([F],0,M,P.nextElementSibling);break;case "pinTop":ka=Fc(W,P,1);break;case "pinBot":ka=Fc(W,P);break;case "goTop":X.grid(1).el.parentElement.scrollTop=0;break;case "goBot":X.grid(1).el.parentElement.scrollTop=X.grid(1).el.parentElement.scrollHeight}ac();
ka&&m.dirty();return 1};
var ya=p.menuPageImp||0;m.oncontextmenu=function(F){for(var z=F.target,M=z.S;!M&&z&&!z.classList.contains("item-sqr");)z=z.parentNode;Y=z;var aa=z.data;z||(M=1);M=m.grid();aa=0==ya?["",[0,"open",[J("g"),aa.url]],,[0,"addThis",J("77"),1,,[0,"addWnd",J("97")],[0,"addAll",J("u")]],[0,hc(aa.url,ia.url)?"saveSession":0,J("45"),1,[0,aa.session?"restoreSession":0,J("dt")]],[0,"topImp1",J("2")],[0,"pinTop",J("hz")],[0,"pinBot",J("lz")],[0,"del",J("57"),m.bin.length,[0,"restore",J("3")]],[0,"multi",J("pi"),
Fb.mtImp||M.els(z),[0,"moveSel",J("wy")],[0,"delSel",J("rm")],[0,"selAll",J("8v")]],[1,c.path.includes("tmp")?"isTmp":0,J("7"),T.tmp],[1,c.path.includes("tmp")?"isSame":0,J("k7"),T.same]]:["",[0,"openInCurrent",J("k7")],[0,"openInNewTab",J("g")],[0,"openInBackgroud",J("c1")],[0,"openInIframe",J("h6")],[0,"goTop",J("8")],[0,"goBot",J("qw")],[0,"copyUrl",J("py")]];ic(aa,m.pref,F,z,m.oncontextmenu,[J("g1"),J("o")],ya,W=>{p.menuPageImp=ya=W;m.oncontextmenu(F)});
Qb=F;if(kc()){z=lc();if(Hc=G("open",z))Hc.oncontextmenu=W=>{R(W);m.pref("openInCurrent")};
Hc=G("addSep",z);if(Hc=G("openInCurrent",z))Hc.title=J("i8"),Hc.oncontextmenu=W=>{R(W);m.pref(Hc.id)};
if(Hc=G("restoreSession",z))Hc.title=J("f"),Hc.oncontextmenu=W=>{R(W);m.pref(Hc.id)}}};
var sa,va,Qa;Ma("mousedown",function(F){sa=F.clientX;va=F.clientY;Qa=m.grid(1).el.parentNode.scrollTop},1,m);
var jb;Ma("mouseup",function(F){if(n(sa,F.clientX)&&n(va,F.clientY)&&n(Qa,m.grid(1).el.parentNode.scrollTop)){for(var z=F.target,M=z.S;!M&&z&&!z.classList.contains("item-sqr");)z=z.parentNode;var aa=z.data;if(F.button==fa){var W=q(aa);Tb(P=>{chrome.tabs.create({url:aa.url,active:!1,index:P.index+1},W);!T.tmp||F.ctrlKey||jb&&ua||(Y=z,xc()&&m.pref("del"),jb=1)});
nc()}}},1,m);
m.dblclick=function(F,z){F=z.data;"add"!=F.url&&chrome.tabs.create({active:!0,url:F.url,index:ia.index+1},function(M){})};
m.click=function(F,z){var M=z.data;if("add"==M.url)k(z,-1,z);else{for(F=F.target;F&&!F.classList.contains("item-sqr");)F=F.parentNode;Y=F;r(M)}};
A.initGridTab?(initGridTab(A,w,m),D()):cc("gridtab.js",function(){p.initSortable&&!Mb?(p.initSortable(w,A),initGridTab(A,w,m),D()):p.loadSortable(function(){p.initSortable(w,A);initGridTab(A,w,m);D()})});
return m})(a,b)}
function Jc(a,b){var c=a.firstChild;if(c)return c;for(;a&&a!=b;){if(c=a.nextSibling)return c;a=a.parentNode}}
function Kc(a){a=a.path;a.startsWith("sch:")&&(a=a.slice(4));return a}
function Lc(a,b,c,d,g){p.putSchKey(b);if(!d||b)a?(b=a.replace("%s",b),c?chrome.tabs.update(ia.id,{url:b}):chrome.tabs.create({url:b,active:!g})):chrome.search.query({text:b,disposition:"NEW_TAB"}),ua&&!g?window.close():Mc()}
var Nc;function Oc(a,b){function c(){l=Kc(a);k.schEng.innerText=l||J("b")}
function d(r,D){r=r.value.trim()||k["1"].value.trim()||k["2"].value.trim();r!=n.key&&(n.key=r,db(g,n));Lc(l,r,D)}
b=N(0,0,"UiTab");b.innerHTML='\n        <div class="UiHead">\n        \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div id="pasteIt" style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;" title="获取手机上的剪贴板数据，\n 当安卓无限词典处于前台无需复制只需选择，\n 当处于后台需要打开悬浮按钮。\n点击此处粘贴至浏览器内部的输入框">\n\t\t\t\t\t新的搜索&ensp;\n\t\t\t\t</div>\n                <textarea id=\'1\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="11" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="12" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n            \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;">当前页搜索&ensp;</div>\n                <textarea id=\'2\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="21" title="搜索">\ud83d\udd0d</button>\n                    <button class="btn" id="22" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="23" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n\t\t\t\n            <div class="divider">\n\t\t\t    <HR style=\'margin:15px;opacity:.8;\'>\n                <span class="dividerTitle" id="dt"></span>\n            </div>\n\t\t\t\n            <div style="height:18px;display:flex;flex-direction: row;position:fixed; bottom:0; width:100%; user-select:none; cursor: pointer;">\n                <div id="schEng" class="tools" style="height:30px;width: 100%;font-size:10px;padding-left:5px;color:#888">\n                    默认搜索引擎\n                </div>\n            </div>\n            \n        </div>\n        <div class="UITabo">\n            <div class="ListView" id="key"></div>\n        </div>';
for(var g="v_"+rb.id+"_"+a.id,k={},q=b,n={};q=Jc(q,b);)q.id&&(k[q.id]=q);var l;c();b.et=k["1"];b.et1=k["2"];Ia(k.dt,a.title);N("SPAN",0,"tabx").innerText="";q=N(0,0,"item-icon");N(0,q,"img web").style.backgroundImage=Pc(a.path.slice(4));q.style="display: inline-block;transform: translateY(4px);";k.dt.insertBefore(q,k.dt.firstChild);k["11"].onclick=function(){d(k["1"])};
k["21"].onclick=function(){d(k["2"],!0)};
k["22"].onclick=function(){d(k["2"])};
k.schEng.onclick=function(){var r=prompt("输入搜索引擎地址，用%s代替关键词：",l);void 0!=r&&r!=l&&(a.path="sch:"+r,c(),U.dirty())};
Ma("keydown",function(r){"Enter"!==r.key||r.shiftKey||(R(r),d(r.target))},0,k["1"]);
Ma("keydown",function(r){"Enter"!==r.key||r.shiftKey||(R(r),d(r.target,!0))},0,k["2"]);
Ma("input",function(r){Qc=k["2"].value},0,k["2"]);
b.onAttach=function(){Db==Rc&&setTimeout(()=>{k.schEng.click()},250);
Nc||(Nc=N(0,0,"sch-pane"),Mc());k.key.append(Nc);Sc(r=>{k["2"].value=r})};
b.onRemove=function(){};
Wa(g,r=>{if(r=r[g])n=r,k["1"].value=r.key||"";Sc(D=>{k["2"].value=D})});
return b}
function Tc(a,b){a=N(0,0,"UiTab");var c=N("IFRAME",a);b.includes(":")||(b="https://"+b);c.src=b;c.style.width="100%";c.style.height="100%";return a}
function Uc(a,b){return((c,d)=>{function g(){return l}
function k(m){m=m.src;n.shadow.innerHTML=m;q.s=n.shadow;var B=m.lastIndexOf("<script>");B&&(B=m.slice(B+8,m.indexOf("</script>",B+8)),eval(B.replace("_bg()",g.name+"()")))}
var q=N(0,0,"UiTab disp0"),n=N(0,q);n.src=d;n.style.width="100%";n.style.height="100%";n.shadow||(n.shadow=n.attachShadow?n.attachShadow({mode:"open"}):N(0,n));q.d=c;var l,r=tc(c),D=r+"_";q.k=r;q.tmps=p.d();q.onRemove=()=>{if(l.view.onSave)l.view.onSave();if(l.changed){var m={};Object.assign(m,l);delete l.changed;delete m.changed;delete m.view;delete m.src;db(l.view.k,m)}};
q.reload=m=>{k(m)};
Wa([r,D],m=>{q._bg=l=m[r]||{};l.view=q;l.src=m[D];delete l.changed;if(l.src)k(l);else if("百度高级搜索"==c.title){var B=new XMLHttpRequest;B.open("GET","assets/百度高级搜索.html",!!l);B.onreadystatechange=function(C){4===B.readyState&&200===B.status&&(l.src=B.responseText,k(l))};
B.send()}});
return q})(a,b)}
function Ua(a){function b(c){document.removeEventListener("copy",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("copy",b,!0);document.execCommand("copy")}
function Vc(a){function b(c){document.removeEventListener("paste",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("paste",b,!0);document.execCommand("paste")}
function cc(a,b,c){c?b():(c=document.createElement("script"),c.type="text/javascript",c.onload=b,c.src=a,document.body.appendChild(c))}
var Wc;function Xc(a){p.initSortable(w,A);Wc=new Sortable(U,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabH",root:!0,forceFallback:!1,sort:!0,onMove(b){var c=300;1.5<Math.abs(U.dragScroll-U.scrollTop)&&(c=0,U.dragScroll=U.scrollTop);this.options.animation=c;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){Wc.did(b)&&U.dirty();this.options.animation=300},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;A.disani=0;U.dragScroll=U.scrollTop},click(b){},trace:function(){console.log("trace"+Error().stack)}});
a&&(Wc._onTapStart(a),a.constructor==DragEvent?Wc._onDragStart(a):Wc._onDrop(a),Yc(a,1))}
var Mb=1;function Yc(a,b){Wc?a&&(b?U.lazyS=a.target.ondragstart=void 0:Yc(a,1)):p.initSortable&&!Mb?Xc(a):p.loadSortable(function(){Xc(a)})}
Zc();document.ondblclick=function(a){var b=a.target;b==U?Wc&&Wc.multiDrag._deselectMultiDrag(0,1):X&&X.contains(b)&&X.dblclick&&X.dblclick(a,b)};
var $c={};
document.onkeydown=function(a){var b=a.key;if(!$c[b]){$c[b]=1;var c=a.target;"gridview"==c.id&&(c=c.parentElement.parentElement);c.grido&&(c=c.grido());if(c.S){var d=0;a.ctrlKey?"a"==b?(Ec(c.S),d=1):"z"==b&&(Cc(c.S),d=1):"Delete"==b&&(Ac(c.S,0),d=1);if(d){c.dirty();R(a);return}}var g;if("Escape"==b&&Z)ac(),R(a);else if(ad()||Z||bd||a.ctrlKey||a.shiftKey||(c=w.activeElement,d=a.keyCode,(c?.ada||c==w.body)&&(65<=d&&90>=d||48<=d&&57>=d||"A"<=d&&"Z">=d||"a"<=d&&"z">=d)?g=1:" "==b&&(g=1)),g)if(R(a),a=
" "!=b,cd(1,0,a),a)etSearch.value=b,etSearch.dispatchEvent(new Event("input",{bubbles:!0}));else if((a=p.schTabKey)&&etSearch.value!=a||dd)etSearch.value=a,etSearch.dispatchEvent(new Event("input",{bubbles:!0}))}};
document.onkeyup=function(a){$c[a.key]=0};
var ed,fd;function gd(){p.initTabs(function(a,b,c){var d=!ed;Ab={};if(0==a.length){var g=0;function C(H,V,na){void 0===na&&(na=Rc);var T="v"==H;T&&(g+=100,H="");H=p.newTab(Ab,H,na,0,V,924+g+a.length+1);T&&(H.br=1);a.push(H)}
if(b.name==J("ip")||2==b.t0){var k=new XMLHttpRequest;k.open("GET","assets/default_sch_engines.js",!1);k.onreadystatechange=function(H){4===k.readyState&&200===k.status&&eval(k.responseText.replaceAll("doit",C.name))};
k.send();b.t0=2}else if(b.name==J("5i")||3==b.t0)C("recent",0,Ra),C("",0,hd),C("",J("b"),Rc),C("imp_tmp",J("iv"),Sa);else if("tabs1"==b.id||1==b.t0)C("0",0,Ra),C("1",0,Ra),C("2",0,Ra),C("recent",0,Ra)}if(b.type==id&&c.bar){for(var q=[],n={},l=a.length-1;0<=l;l--){var r=a[l];r.pos=l;r.auto&&r.type==Ra&&(a.splice(l,1),n[r.path]=r);Ab[r.id]=r}function C(H){if(void 0!=H.dateGroupModified){H=H.id;var V=n[H];V?(delete n[H],delete Ab[H]):(V=p.newTab(Ab,H,Ra,0,0,H),V.auto=1);q.push(V)}}
C({dateGroupModified:1,id:"1",title:J("hg")});for(l=0;l<c.bar.length;l++)C(c.bar[l]);for(l=0;l<a.length;l++)q.splice(a[l].pos||0,0,a[l]);a=q;for(var D in n)l=n[D],delete Ab[D],eb(tc(l,b)),l.type==hd&&eb(tc(l,b)+"_")}sb=0;vb=void 0===c.scroll?null:parseInt(c.scroll)||0;rb=b;wb=c.hots||{};xb=Fb.expTab=c.exp;yb=c.one;zb=c.rec;void 0===zb&&(zb=2!=b.t0);lb.innerText="";ob=X=hb=0;pb=[];Bb=b.tPs||{};var m=d?U:U.cloneNode();b=U;ba=xb?6:3;ua&&(ba=xb?6:4);ed=Math.ceil(fd*ba);m.style.maxHeight=ed+"px";jd(m);
m.bin=kd;var B=0;m.dirty=function(){B=fb.tabsVer+1};
m.save=function(){if(B>fb.tabsVer){fb.tabsVer=B;gb.length=0;for(var C=m.firstElementChild;C;){var H=C.d;H&&gb.push(H);C=C.nextElementSibling}gb.now=hb.id;p.saveTabs(rb,gb,()=>{})}C=parseInt(yb?U.scrollLeft:U.scrollTop);
if(rb&&wb&&(sb||C!=vb&&ua&&(zb||void 0!=vb))){H="v_"+rb.id+"__";sb=0;vb=zb?C:C=void 0;var V=gb.indexOf(ob.d)||0;0>V&&(V=0);zc(H,{tix:V,hots:wb,scroll:C,exp:xb,rec:zb,one:yb})}};
gb=a;hb=0;c=$b(gb,c.tix,0,m);hb||(hb=a[0],c=m.firstElementChild,c==mb&&(c=c.nextElementSibling));m.append(mb);m.style.minHeight="";m.ada={};d||(ld.observe(m),m.style.position="absolute",m.style.visibility="hidden",nb.insertBefore(m,U),U=m,md(),ld.unobserve(b));Zb(c,1);mb.fixed=1;m.oncontextmenu=qd;U.onclick||(Wc=0,Zc());rd.dirty||sd();d?setTimeout(()=>{fd=Math.max(mb.offsetHeight,U.firstElementChild.offsetHeight);ed=Math.ceil(fd*ba);m.style.maxHeight=ed+"px";m.MH=ed;md();td()},1):td();
d||(m.style.position="",m.style.visibility="",b.remove())},ua?0:window)}
gd();function ud(a){var b=Object.create(Object.getPrototypeOf(a));Object.getOwnPropertyNames(a).forEach(function(c){var d=Object.getOwnPropertyDescriptor(a,c);Object.defineProperty(b,c,d)});
return b}
function $b(a,b,c,d){var g=d||U;d||(c||=mb);for(var k=0,q=0;q<a.length;q++){var n=a[q];d&&(a[q]=n=ud(n));var l=n.type,r=n.title,D=n.ico;r||(l==Ra&&(r=n.path?.startsWith("recent")?J("gk"):J("ar")),l==Sa&&(r=n.path?.includes("tmp")?J("iv"):J("ib")),l==vd&&(r="无限词典"),l==hd&&(r=J("xb")));D||(l==Ra&&(D=n.path.startsWith("q=")?"⌕&nbsp;":"★"),n.type==Yb&&(D="\ud83c\udf10"),n.type==Rc&&(D="\ud83c\udf10"));l=N("LI",0,"tab");n.type==wd&&(l.classList.add("tab-sep"),n.path&&(l.style=n.path));if(D){var m=
N("SPAN",l,"tabx");(1<D.length?Ja:Ia)(m,D)}n.type==Rc&&n.path&&(m.innerText="",l.con=N(0,l,"item-icon"),l.icon=N(0,l.con,"img web"),l.icon.style.backgroundImage=Pc(n.path.slice(4)));let B=N("SPAN",l,"tabx title");(n.type==wd?Ja:Ia)(B,r);n.type!=Ra||Kb(n)||chrome.bookmarks.get(n.path,function(C){C&&C.length&&(B.innerText=C[0].title)});
l.ondblclick=xd;l.oncontextmenu=qd;l.id="tab_"+n.id;Ab[n.id]=n;Wc||(l.draggable=!0,l.ondragstart=Yc);l.d=n;d&&wb&&(r=1/(ca+1),D=wb[n.id],void 0!=D&&(l.classList.add("tab-hot"),l.style.setProperty("--bg",yd(132,175,255,255,255,255,999==D?.85:r*D)),l.lev1=D,999!=D&&pb.push(l)));c&&c.parentNode==g?g.insertBefore(l,c):g.append(l);n.type==wd&&n.br&&(r=N("div",0,"flex-break"),g.insertBefore(r,l),r.fixed=l.fixed=1,r.fix=l.fix=1,l.br=r);k||(void 0!=b?q==b&&(hb=n,k=l):k=l)}d&&(pb.sort(function(B,C){return-B.lev1+
C.lev1}),zd());
return k}
const md=a=>{a=U.scrollHeight>ed;var b=U.style;!a^"visible"==b.overflowY&&(b.overflowY=a?"scroll":"visible",b.minHeight&&(b.minHeight=""))},ld=new ResizeObserver(md);
ld.observe(U);var kd=[];function Ad(a){if(a.shiftKey||a.altKey||a.ctrlKey)U.lazyS&&U.lazyS(a);else{var b=La("tab",a.target,U);b?(Zb(b),sb=1,clearTimeout(U.saving),U.saving=setTimeout(Bd,800)):Wc&&a.target==U&&Wc.multiDrag._deselectMultiDrag(0,1)}}
mb.onclick=function(a){Y=0;Cd(a)};
function xd(a){if(!a.ctrlKey&&!a.shiftKey){for(a=a.srcElement;a&&!a.classList.contains("tab");)a=a.parentNode;xb=!xb;Dd(a)}}
function Ed(a){return a&&a.parentNode==U&&a!=mb}
function Dd(a){ba=xb?6:3;ua&&(ba=xb?6:4);U.MH=ed=Math.ceil(fd*ba);U.style.maxHeight=ed+"px";md()}
function Fd(a){if(Ed(a)){var b={};Object.assign(b,a.d);var c=a.cloneNode(1);c.onclick=Ad;c.ondblclick=xd;c.oncontextmenu=qd;b.id=p.newTabid(Ab,U.children.length);Wc||(c.draggable=!0,c.ondragstart=Yc);c.d=b;U.insertBefore(c,a.nextSibling);Zb(c)}}
function Bc(a,b,c,d){if(!b.fixed||b.fix){d=c?{e:b,idx:[].indexOf.call(d.children,b)}:{};var g=a?a.els().indexOf(b):-1;~g&&(a.els().splice(g,1),d.sel=1);b.remove();c&&c.push(d);return!0}}
function Ac(a,b,c){if(a&&(b=a.els(),b.length)){a.el.bin.push({es:b.concat(),idx:[].indexOf.call(a.el.children,b[0])});a=0;for(var d;d=b[a++];)if(d.remove(),d.br&&d.br.remove(),c)try{c(d)}catch(g){Aa(g)}b.length=0;return!0}}
function Fc(a,b,c){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var d=a.els();d.length||(d=[b]);if(d.length){b=0;for(var g;g=d[b++];)g.remove();for(b=0;g=d[b++];)c?a.el.insertBefore(g,a.el.firstElementChild):a.el.append(g);return!0}}}
function Dc(a,b){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var c=a.els();if(c.length&&-1==c.indexOf(b)){for(var d=0,g;g=c[d++];)g.remove();b=b.nextElementSibling;for(d=0;g=c[d++];)a.el.insertBefore(g,b),b=g.nextElementSibling;return!0}}}
function Cc(a,b){if(a){var c=a.el.bin.pop();if(c){var d=a.el,g=d.children[c.idx||0];if(b=c.e)d.insertBefore(b,g),c.sel&&a&&a.els().push(b);else{b=c.es;c=0;for(var k;k=b[c++];)d.insertBefore(k,g),a&&a.els().push(k);b=b[0]}return b}}}
function Ec(a){if(a){var b=a.els(),c=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||(b.push(d),d.classList.add("selected"))}}
function Gd(a){if(a){var b=a.els(),c=b.length=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||d.classList.remove("selected")}}
function ic(a,b,c,d,g,k,q,n){Y=d;kc()?(Z=Hd(0,a,b),Id(c),k?setTimeout(()=>Jd(k,q,n),5):Kd&&Kd.remove()):cc("settings.js",function(){initSettings(A,w,"settings.css");
kc()&&g(c)});
ec(c)}
function Rb(){hb?.type==Ra&&Sb(()=>X.reStar())}
function Ld(a,b){var c=a.d.path,d=function(g){Ob(a);if(a.d==hb&&X&&X.onResume)X.onResume();Rb()};
Sb(g=>{!g||b.ctrlKey?chrome.bookmarks.create({parentId:c,url:ia.url,title:ia.title,index:b.shiftKey?0:void 0},d):g.parentId!=c?chrome.bookmarks.move(g.id,{parentId:c,index:b.shiftKey?0:void 0},d):Vb("已经添加到该文件夹！<br>"+J("qs"))})}
function Ub(a,b){chrome.bookmarks.get(b.path,function(c){if(c=c?c[0]:0)ac(),uc(a.tabView,c)})}
function uc(a,b){if(b)if(b.parentId==a?.lv.tD.path)a.lv.act(b.id);else{for(var c,d=0,g;g=U.children[d++];)if(g.d?.path==b.parentId&&g.type==Ra){c=g;break}c?Zb(c):(c=p.newTab(Ab,b.parentId,Ra,U),Zb($b([c],0,a.taEl.nextSibling)));sb=1;c&&(U.dirty(),setTimeout(()=>{X.lv&&X.lv.act(b.id)},500))}}
function Cd(a){var b=Y,c=["",[0,["tabFav",0],[J("v")],1,,[0,"tabRec",J("gk"),1]],[0,["tabImp",0],[J("ib")],1,,[0,"tabTmp",J("iv"),1]],[0,"tabSch",J("ia"),1],[0,"tabWeb",J("h6"),1],[0,["tabCustomX",0],[J("m")],1,,[0,"tabBaidu",J("百度高级搜索"),1],[0,"tabCustom",J("xb"),1]]];ic(c,Md,a,b,Cd);if(kc()){a=lc();if(b=G("tabImp",a))b.title=J("右击保存到新的位置"),b.oncontextmenu=d=>{Md("tabImp");R(d)};
if(b=G("tabTmp",a))b.title=J("右击保存到新的位置"),b.oncontextmenu=d=>{Md("tabTmp");R(d)}}}
function qd(a){Wc||Yc(a);if(window.oncontextmenu==ec)ec(a);else{for(var b=a.target,c=b==U;!c&&b&&!b.classList.contains("tab");)b=b.parentNode;c||fc(b);if(b==mb)b.onclick(a);else{c=b.d.type==Ra;var d=gc(b.d),g=b.d.type==Rc,k=b.d.type==Sa,q=b.d.type==Yb;c=["",[0,d?["addFav",0]:0,[J("7u")],1,,[0,d?["newFavFolder",0]:0,[J("e")],1],[0,d?["openLocatedFoler",0]:0,[J("k")],1]],[0,g?["schNew",0]:0,J("vb"),1,[0,g?["schThis",0]:0,J("6x"),1]],[0,q||g||c?["openWeb",0]:0,J("g"),1],[0,b.d.type==hd?["editSrc",0]:
0,J("8k"),1],[0,k?["setTemp",0]:0,[J("hx")],1],[0,b.d.type==wd?["brSep",0]:0,[J("切换换行")],1],[0,["copyUrl",0],[J("z1")],1],[0,["newTab",0],[J("3j")],1,,[0,["dupTab",0],[J("j")]],[0,["newSep",0],[J("w")]]],[0,["closeTab",0],[J("sj")],kd.length,[0,["resumeTab",0],[J("9")]]],[0,["multiTab",0],[J("vk")],Fb.mt||Wc&&Wc.els(b),[0,["moveTabs",0],[J("d")]],[0,["selTabs",0],[J("8v")]]],[1,"oneRow",[J("单行标签栏")],yb],[1,"expTab",[J("td")],xb],[1,ua?"recPos":0,[J("nv")],zb]];ic(c,Md,a,b,qd);if(kc()){Z.e=a;a=lc();
if(b=G("selTabs",a))b.title=J("1"),b.oncontextmenu=n=>{Gd(Wc);R(n);ac()};
if(b=G("copyUrl",a))b.title=J("5r"),b.oncontextmenu=n=>{R(n);Nd()},b.onmousedown=n=>{1==n.button&&(R(n),Od())};
if(b=G("addFav",a))b.title=J("qs");if(b=G("addImp",a))b.title=J("qs");if(b=G("schNew",a))b.oncontextmenu=n=>{Md("schNew");R(n)};
if(b=G("schThis",a))b.oncontextmenu=n=>{Md("schThis");R(n)};
if(b=G("newSep",a))b.title=J("右击换行"),b.oncontextmenu=n=>{Md("newSep");R(n)}}}}}
function Od(){var a=Y,b=a.d;if(gc(b))chrome.bookmarks.get(b.path,function(g){if(g=g?g[0]:0)ac(),cc("assets/dialog.js",function(){var k=showDialog(w,w.body);Ia(k.t,"Edit");Ja(k.t1,dc("NAME"));Ia(k.btn0,"Save");var q=Fa("TEXTAREA",k.t1);q[0].value=g.title;k.btn0.onclick=()=>{var n=q[0].value;chrome.bookmarks.update(b.path,{title:n},l=>{l&&(Ia(Ga("tabx title",a),n),k.s.remove())})};
k.btn1.onclick=()=>{k.s.remove()}},A.showDialog)});
else{var c=Y.d.title,d=prompt("标题：",c);d!=c&&void 0!=d&&(ac(),U.dirty(),(b.type==wd?Ja:Ia)(Ga("tabx title",a),b.title=d),Ob(a))}}
function Nd(){var a=Y,b=a.d,c=Oa(Y.d),d=prompt("请输入新地址（可以是书签url或者http网址）",c),g="v_"+rb.id+"_"+b.id,k=d!=c;if(d){ac();function n(l,r){Va.remove(g);var D=b.id;Object.keys(b).forEach(function(m){delete b[m]});
b.id=D;b.type=q;b.title=l;q==Sa&&(d.startsWith("important://")&&(d=d.slice(12)),d.startsWith("imp_")||(d="imp_"+d));b.path=d;k&&U.dirty();l=a.nextElementSibling;Bc(Wc,a,0,U);$b([b],0,l);a==ob&&Zb(a);Ob(a,r)}
if(d.startsWith("chrome://bookmarks")||!isNaN(d)){var q=Ra;n(e[0].title,350)}else d.startsWith("imp")?(q=Sa,c=b.type==q?b.title:0,b.path.includes("tmp")!=d.includes("tmp")&&(c=0),n(c)):d.startsWith("custom")?(q=hd,c=b.type==q?b.title:0,n(c||J("xb"))):d.startsWith("sch:")?(q=Rc,n(Pd(d,!0)||J("ia"))):(q=Yb,n(Pd(d,!0)))}}
function Pd(a,b){var c=a,d=c.indexOf(":");for(0<=d&&(c=c.slice(d+1));c.startsWith("/");)c=c.slice(1);d=c.indexOf(".");if(0<d){if(a=c.slice(0,d),"www"==a){var g=c.indexOf(".",d+1);0<g&&(a=c.slice(d+1,g))}}else a=c;b&&(a=a.toUpperCase());return a}
function Qd(a){a.delay?setTimeout(ac,10):ac()}
function yd(a,b,c,d,g,k,q){a=Math.round(a*(1-q)+d*q);b=Math.round(b*(1-q)+g*q);c=Math.round(c*(1-q)+k*q);return"rgb("+a+" "+b+" "+c+")"}
const Ra=0,Sa=1,vd=2,Yb=4,hd=5,Rc=6,wd=7;
function Zb(a,b){if(Ed(a))if(a.d&&a.d.type!=wd){if(ob){ob.classList.remove("tab-now");var c=X;c&&!c.hidden&&(c.hidden=1,Rd(),c.style.display="none")}ob=a;if(wb){var d=ca;c=1/(d+1);var g=pb.indexOf(a);0<g&&pb.splice(g,1);pb.push(a);pb.length>d&&(d=pb.shift(),delete wb[d.d.id],d.lev1=999,d.style.setProperty("--bg",yd(132,175,255,255,255,255,.85)));a.classList.add("tab-hot");d=pb.length-1;for(g=d-1;0<=g;g--){var k=pb[g];wb[k.d.id]=k.lev1=d-g;k.style.setProperty("--bg",yd(132,175,255,255,255,255,c*(d-
g)))}}a.classList.add("tab-now");d=hb=a.d;c=a.tabView;if(!c){c=d.type;try{c==Ra?(c=Lb(d,d.path,a),c.taEl=a):c=c==Sa?vc(d,d.path):c==vd?newTabPlainDict(d,d.path):c==Yb?Tc(d,d.path):c==hd?Uc(d,d.path):c==Rc?Oc(d,d.path):""}catch(n){console.error(n),c=""}c||=N(0,lb,0,"错误");a.tabView=c}(d=X!==c)&&(X=c);g=c.parentNode!=lb;if(c.hidden||g){if(c.hidden=0,c.style.display="",g&&lb.append(c),c.onAttach)try{c.onAttach()}catch(n){Aa(n)}}else if(d&&c.onResume)try{c.onResume()}catch(n){Aa(n)}if(yb)td(1);else{c=
a.offsetHeight;d=a.offsetTop+c;g=U.scrollTop;k=U.clientHeight;var q=null;d<g+c/2+9?q=a.offsetTop:d>g+k&&(q=d-k);null!==q&&U.scrollTo({top:q,behavior:b?"auto":"smooth"})}}else Zb(a.nextElementSibling)}
A.onfocus=function(a){if(A._blr&&(A._blr=0,X&&X.onResume))X.onResume()};
A.onblur=function(a){A._blr=1;Rd(1);Bd();Sd()};
A.onbeforeunload=function(){Td();Rd(1);U.save();Sd();ua||delete p.bkWnds[ia.id]};
function Md(a,b,c,d){function g(){ac();q&&(Zb($b([q],0,Y?.nextElementSibling)),sb=dd=k=1);k&&U.dirty()}
var k=0,q=0,n=Y?.d;switch(a){case "addFav":Ld(Y,d);break;case "newFavFolder":chrome.bookmarks.get(n.path,function(m){if(m=m?m[0]:0){var B=m.title||"",C=B.replace(/\d+$/g,function(H){return(parseInt(H)+1).toString()});
(B=prompt("新建文件夹",C!==B?C:B+" 1"))&&chrome.bookmarks.create({parentId:m.parentId,title:B,index:m.index+1},function(H){H&&(q=p.newTab(Ab,H.id,Ra,U),g(),U.save())})}});
return;case "openLocatedFoler":return Ub(Y,n),1;case "newTab":return Cd(Z.e),1;case "tabFav":q=p.newTab(Ab,ra?ra.parentId:"0",Ra,U);break;case "tabRec":q=p.newTab(Ab,"recent=1000",Ra,U);break;case "tabImp":case "tabTmp":var l="tabImp"==a;if(d)q=p.newTab(Ab,l?"imp_":"imp_tmp",Sa,U);else{b=l?J("ib"):J("iv");var r=l?"important://":"important://tmp";Ud(m=>{var B=m[0].value;m=m[1].value;B=(l?"imp_":"imp_tmp")+(B.startsWith(r)?B.slice(r.length):"");q=p.newTab(Ab,B,Sa,U);q.title=m;g()},r,b)}break;
case "tabAll":q=p.newTab(Ab,"all",Sa,U);q.title="全部页面";break;case "tabSch":q=p.newTab(Ab,"sch:",Db=Rc,U);q.title=J("ia");setTimeout(()=>{Db=0},250);
break;case "tabPDict":q=p.newTab(Ab,"",vd,U);break;case "tabWeb":b=prompt("输入网址：","");if(void 0!=b)b=b||"about:blank",q=p.newTab(Ab,b,Yb,U,Pd(b,!0));else return;break;case "tabBaidu":q=p.newTab(Ab,"custom://",hd,U,"百度高级搜索");break;case "tabCustom":q=p.newTab(Ab,"custom://",hd,U,J("xb"));break;case "schNew":case "schThis":Sc(m=>Lc(Kc(Y.d),m||X.et1?.value||X.et?.value,"T"==a[3],!0,!d));
break;case "setTemp":p.setTmpUrlPath(n.path);break;case "openWeb":var D=n.path;n.type==Rc&&(D=(new URL(D.slice(4))).origin+"");n.type==Ra&&(D=Oa(n));Xb(D,function(m){m&&0<m.length&&!d.ctrlKey?chrome.tabs.update(m[0].id,{active:!0}):Tb(B=>{chrome.tabs.create({active:!d.ctrlKey,url:D,index:B.index+1})})});
break;case "copyUrl":b=Oa(Y.d);Ua(b);Vb(b);Ob(Y);break;case "dupTab":Fd(Y);k=1;break;case "editSrc":Vd(Y);break;case "newSep":q=p.newTab(Ab,"",wd,U,"&emsp;&emsp;");d||(q.br=1);break;case "brSep":(b=!Y.br)?(b=Y.br=N("div",0,"flex-break"),U.insertBefore(b,Y),b.fixed=Y.fixed=1,b.fix=Y.fix=1):Y.br&&(Y.br.remove(),Y.br=Y.fixed=Y.fix=0);n.br=b;k=1;break;case "oneRow":yb=b;sb=1;jd(U);setTimeout(()=>td(1),10);
break;case "expTab":Fb[a]=xb=b;sb=1;Dd(Y);break;case "recPos":zb=b;sb=1;break;case "closeTab":if(Y.classList.contains("selected"))k=Ac(Wc,Y,m=>{n=m.d;Va.remove(tc(n));n.type==hd&&Va.remove(tc(n)+"_")});
else if(b=Wc&&ob==Y?ob.previousElementSibling||U.firstElementChild:0,k=Bc(Wc,Y,kd,U))Zb(b),Va.remove(tc(n)),n.type==hd&&Va.remove(tc(n)+"_"),Y.br&&Y.br.remove();dd=1;break;case "resumeTab":(k=Cc(Wc,Y))&&Zb(k);dd=1;break;case "moveTabs":k=Dc(Wc,Y);break;case "selTabs":Ec(Wc);break;case "multiTab":return Yc(),Y&&Wc&&Wc.els(Y)||(Fb.mt=b),1;default:return Fb[a]=b,1}g();return 1}
var Wd,Z,Y,jc,Qb,Kd;
function Id(a,b){if(b){if(window.e=a,kc()){b=Z.style;Z.p.style.display="block";b.visibility="";var c=a.clientX,d=a.clientY;b.maxHeight="";if(Z.revert)b.right=A.innerWidth-c+5+"px",b.bottom=A.innerHeight-d+5+"px";else{var g=Z.parentNode.offsetWidth,k=Z.parentNode.offsetHeight;c+Z.offsetWidth/2>g&&(c=g-Z.offsetWidth/2,d+=2);b.left=c+"px";d+Z.offsetHeight>=k+45&&Z.offsetHeight/2>k-d&&150>k-d?(b.bottom=k-d+5+"px",b.top=b.maxHeight="",c=Z.cards[0].style,c.display="flex",c.flexDirection="column-reverse",
b.maxHeight=Z.parentNode.offsetHeight-(k-d+5)+"px",setTimeout(()=>{Z.cards[0].firstElementChild.scrollIntoView()},5)):(b.maxHeight=Z.parentNode.offsetHeight-d-5+"px",b.top=d+"px")}}}else setTimeout(()=>{Id(a,1)},5)}
function ec(a){R(a)}
function Hd(a,b,c){if(Wd){if(a&&Wd.n===a)return Wd.p.parentNode||document.body.append(Wd.p),Wd;Wd.parentNode&&Wd.remove()}var d=G("menup");d||(d=N(0,document.body),d.id="menup",d.onmousewheel=function(q){q.srcElement==d&&ac()},d.onmouseup=function(q){var n=q.target;
n===d?ac():1==g.type&&(R(q),2==q.button&&(A.oncontextmenu=ec),n.classList.contains("sep")||n==g||(q.delay=!0,Qd(q)),2==q.button&&oc())});
var g=N(0,d,"menu","max-width:35%;overflow:overlay;overflow-x:hidden;visibility:hidden"),k=g;k.cards&&(k.cards.forEach(function(q){q.remove()}),k.cards=0);
SettingsBuildCard(c,b,k);g.n=a;g.l=b;g.p=d;return Wd=g}
function ac(){Z&&(Z.p.style.display="none",jc&&jc(Z),Z=null)}
if(ua)chrome.tabs.query({active:!0,lastFocusedWindow:!0},function(a){if(ia=a[0])Sb(b=>{}),la&&la()});
else{var Hc=document.title;document.title+=Math.random();chrome.tabs.query({title:document.title},function(a){if(ia=a[0])Sb(b=>{}),p.bkWnds[ia.id]=1;
document.title=Hc;ia.title=Hc})}function pc(){}
setTimeout(function(){kb.remove();kb=0},95);
ua||chrome.runtime.onMessage.addListener(function(a,b,c){if("focus"==a.name)A.onfocus();if("blur"==a.name)A.onblur()});
xb&&Dd();var rd=G("tabgroup"),Xd,Yd;function sd(){rd.dirty||(rd.dirty=()=>{rd._dirty=p.verTG+1;rd._dirty<=p.verTG&&(p.verTG=0,rd._dirty=1)},Ma("mousewheel",function(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;
(b=Math[1<=b?"floor":"ceil"](b))&&rd.scrollTo({left:rd.scrollLeft+80*b,behavior:"auto"});R(a)},1,rd));
Za("tab_groups",a=>{a&&a.constructor===Array||(a=[]);0==a.length&&(a.push({id:"tabs",name:J("hg"),type:id}),a.push({id:"tabs1",name:J("ea")}),a.push({id:"tabs2",name:J("ip"),t0:2}),a.push({id:"tabs3",name:J("5i"),t0:3}));Xd=a;Zd(Xd)})}
function $d(a){Sd();a=a.target;a.d&&(a.d.id==rb.id?td(1):(Yd&&Yd.classList.remove("sel"),Bd(),ae(a.d),a.classList.add("sel"),Yd=a))}
function ae(a){Rd(1);Bd();Sd();rb=a;wb=0;zc("sel_tab_gp",rb,()=>gd())}
function Bd(){U.save()}
function zc(a,b,c){ua?db(a,b,c):(sessionStorage.setItem(a,JSON.stringify(b)),c&&c())}
function yc(a,b,c){if(ua||c)Za(a,b);else{c=sessionStorage.getItem(a,null);try{c=JSON.parse(c)}catch(d){c=0}c?b&&b(c):yc(a,b,1)}}
function Zd(a){rd.innerHTML="";N(0,rd,"tgpd");for(var b=Yd=0,c;c=a[b++];){var d=N(0,rd,"tg");d.innerText=c.name;d.id="tg_"+c.id;d.d=c;d.onclick=$d;d.oncontextmenu=be;ce||(d.draggable=!0,d.ondragstart=de);c.id==rb.id&&(Yd=d,rb=c,d.classList.add("sel"))}N(0,rd,"tgpd");Yd&&requestAnimationFrame(()=>{rd.scrollLeft=Yd.offsetLeft-(rd.offsetWidth-Yd.offsetWidth-45)/2})}
const ee=0,id=1;function fe(a,b,c){function d(D,m,B){r=Xd.indexOf(n);0>r?r=Xd.length:r++;for(var C=0,H=0,V;V=Xd[H++];)V=1+(parseInt(V.id.slice(4))||0),V>C&&(C=V);var na=C;Za("rcy_bin_tg",T=>{function Xa(Qa){if(!ya[Qa]&&!G("tg_tabs"+(Qa||"")))return C=Qa,l={id:"tabs"+(C||""),name:D,type:B||ee,t0:m},Xd.splice(r,0,l),ae(l),k(),1}
T=T||[];for(var ya={},sa=0,va;void 0!=(va=T[sa++]);)va=va.id||va,va?.slice&&(va=parseInt(va.slice(4))||0,ya[va]=1);for(T=0;!Xa(C)&&T<na+1024;)T++,C=T})}
function g(D){r=Xd.indexOf(n);q=1;if(D){Xd.splice(r,1);if(n.id==rb.id){(l=Xd[r])||(l=Xd[r-1]);if(!l){d(J("t"));return}ae(l)}Za("rcy_bin_tg",m=>{m=m||[];if(25<=m.length+1)for(var B=m.splice(0,10),C=0;C<B.length;C++){var H=B[C].id||B[C]+"";G("tg_tabs"+(H||""))||(p._DEBUG&&(za("delete tabgroup #"+H),Ya(H)),Va.remove(H))}m.push(n);db("rcy_bin_tg",m)});
Za(n.id,m=>{"string"===typeof m&&(m=JSON.parse(m));if(m)for(var B=0,C;C=m[B++];)Va.remove(tc(C,n))});
Va.remove("v_"+n.id+"__");k()}else r++,Za("rcy_bin_tg",m=>{m=m||[];l=m.pop();Xd.splice(r,0,l);ae(l);k();db("rcy_bin_tg",m)})}
function k(){ac();if(q||l)rd.dirty(),Zd(Xd)}
var q=0,n=Y.d,l,r;switch(a){case "rename":if(a=prompt(J("cb"),n.name))n.name=a,q=1;break;case "newGroup":(a=prompt(J("h"),J("x9")))&&d(a,3);return;case "ngpEmpty":d(J("t"));return;case "ngpBar":d(J("hg"),0,id);return;case "ngpBkmk":d("bookmarks",1);return;case "ngpSch":d(J("ip"),2);return;case "close":g(!0);return;case "restore":g(!1);return;default:return Fb[a]=b,1}k();return 1}
function be(a){if(window.oncontextmenu==ec)ec(a);else{Sd();for(var b=a.target,c=b==rd;!c&&b&&!b.classList.contains("tg");)b=b.parentNode;c=["",[0,["rename",0],[J("px")],1],[0,["newGroup",0],[J("5")],1,,[0,["ngpEmpty",0],[J("t")]],[0,["ngpBar",0],[J("hg")]],[0,["ngpBkmk",0],[J("ar")]],[0,["ngpSch",0],[J("ip")]]],[0,["close",0],[J("r")],1,[0,["restore",0],[J("x5")]]]];ic(c,fe,a,b,be);if(kc()){Z.e=a;if(a=G("selTabs",lc()))a.title=J("1"),a.oncontextmenu=d=>{Gd(Wc);R(d);ac()};
if(a=G("rename",lc()))a.onmousedown=d=>{1==d.button&&(R(d),d.target.click())}}}}
function Sd(){if(rd._dirty>p.verTG){for(var a=[],b=0,c;c=rd.children[b++];)c.d&&void 0!=c.d.id&&a.push(c.d);db("tab_groups",a,()=>{p.verTG=rd._dirty})}}
var ge=-1,he;function ie(){clearTimeout(ge);var a=G("toastview");a.style.opacity=0;ge=setTimeout(function(){ge=-1;a.style.display="none"},300)}
function Vb(a,b,c,d,g){-1!=ge&&clearTimeout(ge);d||(d=w.body);var k=G("toastview");k||(k=N(0,d),k.id="toastview",N(0,k).id="toasttext");var q=k.parentNode;q!=d&&(q&&k.remove(),d.appendChild(k));d=k.firstChild;d.innerHTML=a;d.className=1<=b?"warn":"info";ge=setTimeout(ie,c||1E3);setTimeout(function(){k.style.opacity=1},16);
k.style.display="block";d.style.opacity=g||1}
function Ob(a,b){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},b||599)}
var Qc;
function Sc(a){if(Qc)a(Qc);else{var b=ia.pendingUrl||ia.url,c=(new URL(b)).searchParams,d=c.get("q")||c.get("wd")||c.get("search")||c.get("searchkey")||c.get("keyword")||c.get("query")||c.get("sokeytm")||c.get("char")||c.get("text")||c.get("queryField_a")||c.get("w")||c.get("q1")||c.get("terms")||c.get("term");null===d&&(c=b.indexOf("zdic.net/hans/"),0<c&&(d=b.slice(14)),0>c&&(c=b.indexOf("dictionary/"),0<c&&(d=b.slice(11))),0>c&&(c=b.indexOf("/zh/"),0<c&&(d=b.slice(4))),0>c&&(c=b.indexOf("/search/"),0<
c&&(d=b.slice(c+8))),d&&(c=d.indexOf("?"),0<c&&(d=d.slice(0,c))));null===d&&(d="");d=decodeURIComponent(d).replace(/\+/g," ");ua?chrome.tabs.executeScript(ia.id,{code:"window.getSelection().toString()"},function(g){g&&g[0]?a(g[0]):a(d)}):a(d)}}
function tc(a,b){return"v_"+(b||rb).id+"_"+a.id}
function Pc(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return'url("chrome://favicon/'+a+'")'}
function je(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return"chrome://favicon/"+a}
function ke(a){for(var b=0,c=0,d=0,g=a.length/4,k=0;k<a.length;k+=4)b+=a[k],c+=a[k+1],d+=a[k+2];return"rgb("+Math.round(b/g)+","+Math.round(c/g)+","+Math.round(d/g)+")"}
function le(a){for(var b={},c=0,d=null,g=0;g<a.length;g+=4){var k=a[g],q=a[g+1],n=a[g+2];255==a[g+3]&&(k=k+","+q+","+n,b[k]?b[k]++:b[k]=1,b[k]>c&&(c=b[k],d=k))}return"rgb("+d+")"}
var ce;function me(a){p.initSortable(w,A);ce=new Sortable(rd,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabG",root:!0,forceFallback:!1,sort:!0,anisk:1,onMove(b){this.options.animation=300;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){ce.did(b)&&rd.dirty()},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;A.disani=0},click(b){$d(b)},trace:function(){console.log("trace"+Error().stack)}});
a&&(ce._onTapStart(a),a.constructor==DragEvent?ce._onDragStart(a):ce._onDrop(a),de(a,1))}
function de(a,b){ce?a&&(b?rd.onclick=a.target.ondragstart=void 0:de(a,1)):p.initSortable&&!Mb?me(a):p.loadSortable(function(){me(a)})}
function dc(a){return`<div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">
            <div style="white-space:nowrap;font-size:.89em;padding-right:10px;text-align:center;padding-top:7.9px;">${a}</div>
            <textarea class='eta' style="flex:1;resize:vertical;min-height:30px;font-size: large;padding-left: 17px; padding-top: 10px;"></textarea>
        </div>`}
function gc(a){return a.type==Ra&&!a.path.startsWith("q=")&&!a.path.startsWith("recent")}
function Jd(a,b,c){function d(l){Ga("hot",Kd)?.classList.remove("hot");l.target.classList.add("hot");c(l.target.idx)}
var g=Z.style;if(!Kd){Kd=N(0,0,"tabG");var k=Kd.style;k.position="fixed";k.height="auto";k.background="white";k.borderRadius="4px";k.transform="scale(0.9)";k.transformOrigin="left";k.boxShadow=getComputedStyle(Z.cards[0]).boxShadow}k=Kd.style;Kd.innerText="";for(var q=0;q<a.length;q++){var n=N(0,Kd,"tg"+(b==q?" hot":""));n.idx=q;Ia(n,a[q]);n.onclick=d}k.left=parseInt(g.left)+1.5+"px";g.top?(k.bottom=Z.parentNode.offsetHeight-parseInt(g.top)-.75+"px",k.top=""):(k.top=Z.parentNode.offsetHeight-parseInt(g.bottom)+
"px",k.bottom="");G("menup").insertBefore(Kd,Z)}
function kc(){return!!A.SettingsBuildCard}
function lc(){return Z.shadowRoot||w}
function Ob(a){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},599)}
function Sb(a){chrome.bookmarks.search({url:ia.url},function(b){a(ra=b?b[0]:0)})}
function Tb(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(ia=b?b[0]:0)})}
function Xb(a,b){chrome.tabs.query({url:a},b)}
function Td(){var a=fb.bkmks.indexOf(ib);0<=a&&fb.bkmks.splice(a,1)}
function Nb(a){return void 0!=a.dateGroupModified}
function hc(a,b){try{return(new URL(a)).hostname===(new URL(b)).hostname}catch(c){}}
function ne(a){X.et.value=a.target.innerText}
function Mc(){p.getSchKeys(a=>{Nc.innerHTML="";for(var b=a.length-1;0<=b;b--){var c=a[b],d=N(0,Nc,"sch-item");d.onclick=ne;Ia(d,c)}})}
function Ud(a,b,c){cc("assets/dialog.js",function(){var d=showDialog(w,w.body);Ia(d.t,"Edit");Ja(d.t1,dc(J("路径").toUpperCase())+dc(J("9p").toUpperCase()));Ia(d.btn0,"Save");var g=Fa("TEXTAREA",d.t1),k=b,q=c;g[0].value=b;g[0].oninput=function(n){n=n.target;n.value.startsWith(k)?b=n.value:n.value=b;g[1].value==c&&(c=g[1].value=q+b.slice(k.length))};
g[1].value=c;d.btn0.onclick=()=>{k="xyz";a(g);d.s.remove()};
d.btn1.onclick=()=>{d.s.remove()}},A.showDialog)}
function Vd(a){cc("assets/dialog.js",function(){var b=showDialog(w,w.body);Ia(b.t,"Edit");Ja(b.t1,dc("CODE"));Ia(b.btn0,"Save");var c=a.tabView,d=c?._bg,g=Fa("TEXTAREA",b.t1);c?(g[0].value=d.src,b.btn0.onclick=()=>{var k=g[0].value;db(c.k+"_",k,q=>{d.src=k;c.reload(d);b.s.remove()})}):Za(tc(a.d)+"_",k=>{g[0].value=k;
b.btn0.onclick=()=>{var q=g[0].value;db(tc(a.d)+"_",q,n=>{b.s.remove()})}});
b.btn1.onclick=()=>{b.s.remove()}},A.showDialog)}
function bc(){return navigator.userAgent.includes("Edg/")}
function oe(a){var b=La("result",a.target),c=Ga("up",b);a.clientX>=c.getBoundingClientRect().left?pe(Ga("title",b).innerText):(Zb(b.el,1),cd(),U.scrollTop=b.el.offsetTop-b.el.offsetHeight)}
function qe(a){var b=La("result",a.target),c=Ga("up",b);a.clientX>=c.getBoundingClientRect().left?(pe("t: "+Ga("tabx",b).innerText),re()):(chrome.tabs.update(b.d.id,{active:!0}),wc(b.d.windowId))}
function se(a){p.schTabKey=a;dd=0;var b=a;if("t"!=b[0]||":"!=b[1]&&" "!=b[1]){a=a.trim();(n=A._py&&/[a-z]/g.test(a))&&(n=A._py_cp(a));b=0;for(var c,d=U.children;c=d[b++];)if(c!=mb){var g=Ga("title",c).innerText;if(n&&_py(g,n)||!n&&g.includes(a)){g=N(0,te,"result tab");var k=N(0,g);k.style="display:flex;align-items:center;gap:1px;";k.style.flex="1";var q=c.cloneNode(1);g.el=c;g.d=c.d;[].slice.call(q.children).forEach(l=>{k.append(l)});
g.onclick=oe;g.oncontextmenu=qd;c=N(0,g,"up");c.innerText="︿";c.style="transform:translateY(-15%);"}}}else{a=a.slice(2).trim();var n=A._py&&/[a-z]/g.test(a);n&&=A._py_cp(a);chrome.tabs.query({},function(l){for(var r=0,D;D=l[r++];){var m=D.title;if(n&&_py(m,n)||!n&&m.includes(a)){var B=N(0,te,"result tab"),C=N(0,B);C.style="display:flex;align-items:center;gap:1px;";C.style.flex="1";N(0,C,"tabx").innerText=m;B.d=D;B.onclick=qe;D=N(0,B,"up");D.innerText="︿";D.style="transform:translateY(-15%);"}}})}ue(te.firstElementChild)}
var ve,te,bd=se,we,dd;bd=0;function ue(a){a!=we&&(we&&we.classList.remove("hot"),a&&a.classList.add("hot"),we=a)}
function pe(a){etSearch.value=a;etSearch.dispatchEvent(new Event("input",{bubbles:!0}))}
function re(){etSearch.select();var a=etSearch.value;if("t"==a[0]&&(":"==a[1]||" "==a[1])){var b=" "==a[2];a=getSelection();a.modify("extend","backward","line");a.modify("move","forward","character");a.modify("move","forward","character");b&&a.modify("move","forward","character");a.modify("extend","forward","line")}}
function cd(a,b,c){if(a){if(!ve){ve=G("search-box");te=Ga("results",ve);te.innerHTML="";Ma("input",g=>{var k=etSearch.value;te.innerHTML="";/[a-z]/g.test(k)?cc("assets/pinyin.js",()=>bd(k),A._py):bd(k)},1,etSearch);
var d=ve.parentNode;Ma("keydown",g=>{"Escape"==g.key&&cd()&&R(g);"Enter"==g.key&&(we&&we.click(),R(g));"ArrowUp"==g.key&&(ue(we?.previousElementSibling||we),R(g));"ArrowDown"==g.key&&(ue(we?.nextElementSibling||we),R(g))},1,d);
Ma("mousemove",g=>{ue(La("result",g.target))},1,te);
Ga("icon-close",ve).onclick=()=>etSearch.value="";
d.onclick=g=>{g.target==ve.parentNode&&cd()}}b||=se;
if(bd==b)return}d=ve.parentNode.style;if(a||"none"!=d.display)return d.display=a?"":"none",a&&(etSearch.focus(),c||(etSearch.select(),setTimeout(()=>{re()},200))),bd=b,ua&&(p.popSching=!!b),1}
function ad(){var a=w.activeElement;if(a&&(a.shadowRoot&&(a=a.shadowRoot.activeElement),a=a?.tagName,"INPUT"==a||"TEXTAREA"==a))return 1}
function zd(){ua&&p.popSching&&(cd(1),etSearch.value=p.schTabKey,etSearch.dispatchEvent(new Event("input",{bubbles:!0})))}
function wc(a){chrome.windows.update(a,{focused:!0},function(b){})}
var xe,ye,ze,Ae,Be=-1,Ce,mc,De={},Ee,Fe,Ge,He;
function sc(a,b,c,d,g){return(()=>{function k(l){if(void 0!=l.clientX){xe=l;var r=d(l)}else l=xe,r=d(document.elementFromPoint(l.clientX,l.clientY));r?mc||=r:(c&&(r=q(l)),r||=mc);if(r){-1==Be&&(Be=n(mc));if(-1==Ee&&(b&&r.pos!=Be||3<Math.abs(De.y0-l.clientY))){ye.lazyS&&U.lazyS(l,1);c?(Ee=n(r),ye=r.lst||g(l),He=ye.topPos()):(Ee=-100,Fe=r);var D=ye,m=D.append;Ae||=N(0,0,"BoxSel");m.call(D,Ae);ye.style.position="relative";Ma("scroll",k,Da,ye)}if(-1!=Ee){var B=ye;m=De.x;var C=l.clientX;D=De.y;var H=B.scrollTop+
l.clientY-Ge;l=C-m;var V=H-D;0>V&&(V=-V,D=H);0>l&&(l=-l,m=C);c&&(Ee=n(r),B.topPos()!=He&&(Be<r.pos?(D=0,V=H):(D=H,V=B.scrollHeight+5)));B=Ae.style;m+=ye.scrollLeft;B.top=D+"px";B.left=m+"px";B.height=V+"px";B.width=l+"px";fc(r)}}}
var q=l=>{},n=b?l=>l.pos:l=>99;
c&&(q=l=>{if(l=g(l)){var r=l.findRow(l.ada.size-1);if(r&&r.offsetTop<l.scrollTop+l.offsetHeight)return r}});
a.mv=k;a.md=function(l){if(l.button==ha&&!Z){var r=d(l),D=r;r?Ce=0:(r=q(l),Ce=!!r);if(r||!c)D&&(mc=r),ye=D=r?.lst||g(l),Ma("mousemove",k,Da,w.body),Ee=Be=-1,De.x=l.clientX,Ge=D.getBoundingClientRect().y,De.y0=l.clientY,De.y=D.scrollTop+De.y0-Ge,fc(r),A.box=a}};
a.mu=function(l){if(l.button==ha&&ye){var r=l.altKey;if(-1!=Ee){Ce&&mc==ze&&!d(xe)&&(mc=0);if(mc)try{var D=ye;if(c){var m=Be,B=Ee;Be>Ee&&(m=B,B=Be);var C;l=0;var H=1,V=D.topPos(),na=D.salad;r=r?0:1;for(C=m;C<=B;C++){var T=D.ada.getItem(C);H&&C>=V&&(l=D.findRow(C),H=0);l&&(l.pos==C?Jb(l,"selecting",r):l=0);r?na[T.id]={pos:C,id:T.id,e:l}:delete na[T.id];l&&=D.rowSibling(l)}}else{m=U.S.els();B=parseInt(Ae.style.left);H=parseInt(Ae.style.top);var Xa=B+Ae.offsetWidth,ya=H+Ae.offsetHeight;C=0;for(var sa;sa=
D.children[C++];){var va=sa.offsetLeft,Qa=sa.offsetTop,jb=va+sa.offsetWidth,F=Qa+sa.offsetHeight;if(sa.d&&!(jb<=B||va>=Xa||F<=H||Qa>=ya)&&r^!sa.classList.contains("selected")){var z=m.indexOf(sa);r?0<=z&&m.splice(z,1):0>z&&m.push(sa);Jb(sa,"selected",!r)}}}}catch(M){Aa(M)}Ee=-1;oc();Na("scroll",k,Da,ye);fc();Ae.remove()}Na("mousemove",k,Da,w.body);mc=0;Be=-1;ye=0}}})()}
function oc(){A.oncontextmenu=ec;setTimeout(function(){A.oncontextmenu=0},20)}
var Ie;function Zc(){Ie||(Ie={},sc(Ie,0,0,a=>La("tab",a.target||a,U),a=>U));
U.lazyS=function(a,b){if(b||a.ctrlKey||a.shiftKey)(b||a.target!=U)&&Yc(a),U.lazyS=0};
U.onclick=Ad;U.onmousedown=Ie.md}
function fc(a){ze!=a&&(Jb(ze,"hot"),ze=a,Jb(ze,"hot",null!=a))}
function Je(a){A.box&&A.box.mu(a);Ba&&Ba(a)}
function Rd(a){if(X?.onRemove)try{X.onRemove(a)}catch(b){Aa(b)}}
Ma("mouseup",Je,1,w);function Ke(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;(b=Math[1<=b?"floor":"ceil"](b))&&U.scrollTo({left:U.scrollLeft+80*b,behavior:"auto"});R(a)}
function jd(a){var b=a.style;yb?(b.overflowX="auto",b.flexFlow="nowrap",a.classList.add("r1"),Ma("mousewheel",Ke,1,a)):(b.overflowX="",b.flexFlow="wrap",a.classList.remove("r1"),Na("mousewheel",Ke,1,a))}
function td(a){if(yb){if(!a&&null!==vb&&ua&&zb)try{U.scrollLeft=vb;return}catch(b){}try{U.scrollLeft=ob.offsetLeft-A.innerWidth/3}catch(b){}}else{if(!a&&null!==vb&&ua&&zb)try{U.scrollTop=vb;return}catch(b){}try{U.scrollTop=ob.offsetTop-ba/3*fd}catch(b){}}}
function nc(){ua||(p.fakePP=Date.now(),chrome.browserAction.openPopup(function(a){a&&a.close();chrome.runtime.lastError}))}
function xc(){var a=Date.now();if(250<=a-Ca)return Ca=a,1}
;