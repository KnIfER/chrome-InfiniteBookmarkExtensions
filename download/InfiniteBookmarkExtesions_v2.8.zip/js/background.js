'use strict';var data={},fakePP=0,debug=console.log,log=console.log,verTG=0,_DEBUG=1,num_tabs=0;function geVal(a,b){chrome.storage.local.get(a,b)}
function getVal(a,b){geVal(a,c=>{b(c[a])})}
function tVal(a){}
function seVal(a,b){chrome.storage.local.set(a,b)}
function setVal(a,b,c){var l={};l[a]=b;seVal(l,c)}
function gm(a){return chrome.i18n.getMessage(a)||a}
var menu=chrome.contextMenus;_DEBUG&&menu.removeAll();(function(){function a(e){if(1>e)throw Error("长度不能小于1");var g={};g.data=new Map;g.sz=e;g.set=function(k,m){var n=g.data,q=g.sz;n.delete(k);n.set(k,m);n.size>q&&(k=n.keys().next().value,n.delete(k))};
g.get=function(k){var m=g.data;if(m.has(k)){var n=m.get(k);m.delete(k);m.set(k,n);k=n}else k=null;return k};
return g}
function b(e,g){var k=popupCache.bkmk?.id;if(k==e||k==g)popupCache.bkmk=0;(k=c!=e&&(!g||g!=l))||(h=Date.now(),k=100<=h-p);if(k){p=h;c=e;l=g;k=0;for(var m,n;m=data.bkmks[k++];){if(n=m[e])n.data=null,n.stl=!0,n.ver++;g&&(n=m[g])&&(n.data=null,n.stl=!0,n.ver++)}}}
(function(){chrome.bookmarks.onMoved.addListener(function(e,g){b(g.oldParentId,g.parentId);e==navBkmk&&fixNav()});
chrome.bookmarks.onRemoved.addListener(function(e,g){b(g.parentId);e==navBkmk&&fixNav()});
chrome.bookmarks.onCreated.addListener(function(e,g){b(g.parentId)});
chrome.bookmarks.onChanged.addListener(function(e,g){chrome.bookmarks.get(e,function(k){k&&k.length&&b(k[0].parentId)})});
chrome.bookmarks.onChildrenReordered.addListener(function(e,g){b(e)})})();
var c,l,p=0,h=0,f=a(5);window.newLru=a;window.pullBkmk=function(e,g,k,m){if(m){k&&(popupCache={});for(var n=0,q;q=data.bkmks[n++];)if(q=q[e])q.data=null,q.stl=!0,q.ver++}if(popupCache.bkmk?.id===e&&popupCache.bkmk?.data)g(popupCache.bkmk?.data);else if(e.startsWith("recent"))m=parseInt(e.slice(6).replaceAll("=","").trim())||1E3,chrome.bookmarks.getRecent(m,function(r){g(r);k&&(popupCache.bkmk={id:e,data:r})});
else if(e.startsWith("q="))chrome.bookmarks.search(e.slice(2),function(r){g(r);k&&(popupCache.bkmk={id:e,data:r})});
else{var t=0;if(!m){n=0;for(var u;q=data.bkmks[n++];)if((u=q[e])&&u.data){t=u.data;break}}t?(setTimeout(function(){g(t)},0),k&&(popupCache.bkmk={id:e,
data:t})):chrome.bookmarks.getChildren(e,function(r){f.set(e,r);g(r);k&&(popupCache.bkmk={id:e,data:r})})}}})();
data.bkmks=[];function d(){return data}
loadJs("tabModel.js",function(){});
menu.create({id:"open_page",title:gm("a"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp",title:gm("n"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp1",title:gm("n")+" ("+gm("jl")+")",contexts:["browser_action","page_action"]},()=>{});
var _MD;menu.onClicked.addListener(func);function func(a){a=a.menuItemId;"open_page"==a&&chrome.tabs.create({url:`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html`});"add_tmp"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b)});
"add_tmp1"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b,0,!0)});
_DEBUG&&_MD&&_MD(a)}
var tmpUrlData,tmpUrlPath,tmpUrlDataDirty,impUrlTd={};function getImpd(a){if(a==tmpUrlPath&&tmpUrlData)return tmpUrlData}
function cacheImpd(a,b){getTmpUrlPath(c=>{a==c&&(tmpUrlData=b)})}
function getTmpUrlPath(a){tmpUrlPath?a(tmpUrlPath):getVal("sel_tmp_url",b=>{b||="";b.startsWith("imp_")||(b="imp_tmp");tmpUrlPath=b;a(tmpUrlPath)})}
function setTmpUrlPath(a,b){tmpUrlPath!=a&&(tmpUrlDataDirty&&saveTmpUrls(),tmpUrlData=tmpUrlPath=0,setVal("sel_tmp_url",a,b))}
getTmpUrlPath(()=>{});
function getTmpUrlData(a){tmpUrlData?a(tmpUrlData):getTmpUrlPath(b=>{getVal(b,c=>{c||={};c.data||(c.data=[]);tmpUrlData=c;a(c)})})}
function pullImpt(a,b){var c=tmpUrlPath===a;if(c&&tmpUrlData)b(tmpUrlData);else{var l=0;if(!l){for(var p=0,h;(h=data.bkmks[p++])&&!(l=h[a]););l?(setTimeout(function(){b(l)},0),c&&(tmpUrlData=l)):getVal(a,f=>{f||={};
f.data||(f.data=[]);parseInt(f.v)&&(f.v=0);"string"==typeof f.data&&(f.data=JSON.parse(f.data));b(f);c&&(tmpUrlData=f)})}}}
function addToTmpUrls(a,b,c,l,p){getTmpUrlData(h=>{function f(m){p?h.data.splice(0,0,m):"add"==h.data[h.data.length-1]?.url?h.data.splice(h.data.length-1,0,m):h.data.push(m);tmpUrlDataDirty=!0;h.v=(h.v||0)+1}
for(var e=!1,g=0;g<h.data.length;g++)if(h.data[g].url===a){p?h.data.splice(g,1):e=!0;break}if(!e){var k=c?.url;function m(){b=k.slice(k.indexOf(":")+3);0<b.indexOf("/",5)&&(b=b.slice(0,b.indexOf("/",5)))}
void 0!==b||k.startsWith("chrome")||k.startsWith("edge")?(b||m(),f({url:a,title:b,favIconUrl:c.favIconUrl}),l&&l(h.data)):chrome.tabs.executeScript(c.id,{code:`window._tmpUrl=\"${a.replace('"',"")}\";window._tmpTop=${p}`},function(n){chrome.tabs.executeScript(c.id,{file:"js/tada_active.js"},function(q){(b=q[0])&&"undefined"!=b||m();f({url:a,title:b,favIconUrl:c.favIconUrl});l&&l(h.data)})})}})}
menu.create({title:gm("cq"),contexts:["link"],onclick:function(a,b){setTimeout(()=>{var c=Date.now()-topTempTime;addToTmpUrls(a.linkUrl,void 0,b,0,100>c&&0<=c)},50)}});
function loadSortable(a){loadJs("popup/Sortable.js",function(){a()})}
function loadListView(a){loadJs("popup/ListView.js",function(){a&&a()})}
function loadJs(a,b){var c=document.createElement("script");c.type="text/javascript";c.onload=b;c.src=a;document.body.appendChild(c)}
var lastAct,bkWnds={};chrome.tabs.onActivated.addListener(function(a){bkWnds[lastAct]&&chrome.tabs.sendMessage(lastAct,{name:"blur"},function(b){});
bkWnds[lastAct=a.tabId]&&chrome.tabs.sendMessage(a.tabId,{name:"focus"},function(b){});
tmpUrlDataDirty&&saveTmpUrls()});
data.favTabsVer=data.favTabsSave=data.tabsVer=0;function saveImportabs(a,b){cacheImpd(a,b);setVal(a,b,function(){})}
chrome.tabs.onUpdated.addListener(function(a,b,c){if(a=data.favTabs[a])data.favTabsVer++,a.lastUrl=a.url!=c.url?c.url:void 0});
chrome.tabs.getAllInWindow(null,function(a){num_tabs=a.length});
chrome.tabs.onCreated.addListener(function(a){num_tabs++});
chrome.tabs.onRemoved.addListener(function(a){num_tabs--;0==num_tabs&&onClose()});
function onUnLoad(){chrome.storage.local.set({date:Date.now()},function(){})}
function saveTmpUrls(){tmpUrlDataDirty=0;tmpUrlData&&setVal(tmpUrlPath,tmpUrlData)}
function onClose(){data.favTabsSave!=data.favTabsVer&&saveImportabs();onUnLoad();tmpUrlDataDirty&&saveTmpUrls()}
chrome.runtime.onMessage.addListener(function(a,b,c){if(a&&a.type){if("bkmk"==a.type){var l=b.tab.url;a.url&&(l=a.url);function f(e){e={ret:e||[]};a.cb&&chrome.tabs.executeScript(b.tab.id,{code:`var backEvt = new CustomEvent("${a.cb}", {detail : ${JSON.stringify(e)}});
						window.dispatchEvent(backEvt);`},()=>{})}
a.get?chrome.bookmarks.search({url:l},e=>f(e)):a.update?chrome.bookmarks.search({url:l},function(e){e&&e.length?chrome.bookmarks.update(e[0].id,{title:a.name},g=>f(g)):chrome.bookmarks.create({title:a.name,
url:l},function(g){f(g)})}):chrome.bookmarks.create({title:a.name,
url:l},function(e){f(e)});
c("nores")}"load_url"==a.type&&(a.sch?chrome.tabs.query({url:a.sch},function(f){(f=f?f[0]:0)&&chrome.tabs.update(f.id,{url:a.url})}):searchActiveTab(f=>{chrome.tabs.update(f.id,{url:a.url})}));
"paste"==a.type&&sendPasteToContentScript(a.data);if("openAll"==a.type){c=a.urls.split("{BKMKBK}");var p=0,h;for(h in c){let f=c[h];setTimeout(function(){f&&chrome.tabs.create({url:f,active:!1})},500*p);
p++}}}});
function getContentFromClipboard(){var a="",b=document.getElementById("sandbox");b.value="";b.select();document.execCommand("paste")&&(a=b.value,console.log("got value from sandbox: "+a));b.value="";return a}
function sendPasteToContentScript(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){chrome.tabs.sendMessage(b[0].id,{data:a})})}
var topTempTime,delTm=0,navPath,navCtx,navBkmk;function fixNav(){navBkmk&&navCtx.idx--}
function checkDeltm(){var a=Date.now();if(250<=a-delTm)return delTm=a,1}
function navNxt(a){if(void 0===a){a=!0;var b=Date.now()-topTempTime;100>b&&0<=b&&(a=!1)}var c=navPath;c.startsWith("q=")||!isNaN(c)?pullBkmk(c,l=>{function p(e){return e.startsWith("javascript:")||e.startsWith("https://separator")}
var h=navCtx.idx;h+=a?1:-1;0>h&&(h=0);h>=l.length&&(h=l.length-1);navCtx.idx=h;navCtx.ni&&(h=l.length-h-1);for(var f=l[h];f&&(!f.url||p(f.url));)f=l[h+(a?1:-1)*(navCtx.ni?-1:1)],navCtx.idx+=a?1:-1;f&&(navBkmk=f.id,searchActiveTab(e=>{chrome.tabs.update(e.id,{url:f.url})}))}):c.startsWith("imp")&&pullImpt(c,l=>{var p=navCtx.idx;
navCtx.tmp&&a||(p+=a?1:-1);0>p&&(p=0);p>=l.data.length&&(p=l.data.length-1);var h=l.data[navCtx.idx=p];h&&(navCtx.tmp&&checkDeltm()&&(p=l.data.splice(navCtx.idx,1),log("deleted ……",p),saveImportabs(c,l)),searchActiveTab(f=>{chrome.tabs.update(f.id,{url:h.url})}))})}
chrome.commands.onCommand.addListener(function(a){"top-temp-url"==a&&(topTempTime=Date.now());"next-item"==a&&navPath&&navNxt();"prev-item"==a&&navPath&&navNxt(!1)});
var schKeys=void 0;function getSchKeys(a){void 0==schKeys?getVal("sch_keys",b=>{a(schKeys=b||[])}):a(schKeys)}
function putSchKey(a){getSchKeys(b=>{if(b[b.length-1]!=a){for(var c=0;c<b.length;c++)if(b[c]==a){b.splice(c,1);break}b.push(a);25<b.length&&b.splice(0,b.length-20);setVal("sch_keys",b)}})}
function exportSettings(a){chrome.storage.local.get(null,function(b){log("exportSettings::",b);window.backup=b;a&&a(b)})}
function importSettings(a,b){try{a=JSON.parse(a)}catch(c){console.log(c)}"object"===typeof a&&chrome.storage.local.set(a,function(c){b&&b(c)})}
function searchActiveTab(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(b?b[0]:0)})}
function reload(){chrome.runtime.reload()}
;