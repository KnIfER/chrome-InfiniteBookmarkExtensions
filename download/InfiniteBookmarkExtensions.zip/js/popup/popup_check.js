'use strict';var bg=chrome.extension.getBackgroundPage(),defH=4;if(bg.fakePP){if(400>(new Date).getTime()-bg.fakePP)throw setTimeout(function(){window.close()},200),1;
bg.fakePP=0};