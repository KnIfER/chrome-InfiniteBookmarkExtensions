'use strict';var l=chrome.extension.getBackgroundPage(),ba=4;if(l.fakePP){if(400>(new Date).getTime()-l.fakePP)throw setTimeout(function(){window.close()},200),1;
l.fakePP=0}var y,da,ea,ha=location.href==`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html?popup=1`,la=console.log,ma=console.error,z=document,E=window;E.isPopup=ha;function na(a,b){return(b||z).getElementById(a)}
function pa(a,b){return(b||z).getElementByTagName(a)[0]}
function qa(a,b){return(b||z).getElementsByTagName(a)}
function ra(a,b){return(b||z).getElementsByClassName(a)[0]}
function ua(a,b){return(b||z).getElementsByClassName(a)}
function M(a){return chrome.i18n.getMessage(a)||a}
function va(a,b){a.innerText=b}
function za(a,b){a.innerHTML=b}
function Aa(a){var b=a.path||"";a=a.type;a==Ea?b.startsWith("recent")||(/^\d+$/g.test(b)?b="chrome://bookmarks/?id="+b:(b.startsWith("q=")&&(b=b.slice(2)),b="chrome://bookmarks/?q="+b)):a==Fa&&(b.startsWith("recent")||(b="important://"+b.slice(4)));return b}
function N(a,b,c,d){a=z.createElement(a||"DIV");c&&(a.className=c);d&&(a.style=d);b&&b.appendChild(a);return a}
function Ga(a,b){try{b?a.stopImmediatePropagation():a.stopPropagation(),a.preventDefault()}catch(c){ma(c)}}
function Ha(a,b,c,d){(d||E).addEventListener(a,b,c)}
function Ja(a,b,c,d){(d||E).removeEventListener(a,b,c)}
function Ka(a){function b(c){Ja("copy",b,!0,z);Ga(c,1);c.clipboardData.setData("text/plain",a)}
Ha("copy",b,!0,z);z.execCommand("copy");Ja("copy",b,!0,z)}
const La=chrome.storage.local;function Qa(a,b){La.get(a,b)}
function Ra(a){La.get(a,b=>{console.log(b[a])})}
function Sa(a,b){Qa(a,c=>{b(c[a])})}
var Ta={};function Ua(a,b){Ta[a]?b(Ta[a]):Sa(a,c=>{b(Ta[a]=c)})}
function Va(a,b){La.set(a,b)}
function Xa(a,b,c){var d={};d[a]=b;Va(d,c)}
function Ya(a,b){La.remove(a,b)}
var Za=l.d(),$a,ab,eb={},fb=N("style",document.head);eb.reload=()=>{setTimeout(()=>{location.reload()},350)};
Za.bkmks.push(eb);N("style",document.head).innerText=`.folder-icon > .item-icon{-webkit-mask-image:url("chrome-extension://${chrome.runtime.id}/images/folder_open.svg")}`;fb.innerText=".img,IMG,.fico{display:none!important}";var gb=na("tabos"),hb=na("tabNew"),P=hb.parentNode,ib=P.parentNode,jb,Q,kb=[],lb,mb,nb,qb,rb,sb,T={},tb={},wb={},xb,yb=Za.opt;yb||(Za.opt=yb={autoExp:1,mcTab:1,tkImp:0,topImp:0,uniImp:1});z.title=M("pd");var zb,Bb;
function Cb(a,b,c){if(a){a=a.classList;var d=a.contains(b);if(void 0===c||d^!!c)d?a.remove(b):a.add(b)}}
function Db(a){return a.path.startsWith("recent")}
function Eb(a,b){l.initListView&&!Fb||l.loadListView();zb||function(){function d(f,g,r){if(!g.t){var w=g._=g;w.classList.add("item-wrap");g.dot=N("P",w,"dot");g.con=N(0,w,"item-icon");g.icon=N(0,g.con,"img");g.lv=N("DIV",w,"item-tlv");g.t=N("P",g.lv,"item-title");g.st=N("P",g.lv,"item-subtitle");g.lv.draggable=!0;g.lv.ondragstart=wa;g.lv.ondragend=ub;g.onmousedown=V;g.ondblclick=B;g.oncontextmenu=J;g.lst=f}w=f.ada.getItem(r);var u=f.salad;w||={title:""};g.data=w;var n=w.title||" ";if(n.startsWith("(")){var v=
n.indexOf(")");0<v&&(n=n.slice(v+1).trim())}g.t.innerText=n;n=w.url;v=g.icon;g.lv.href=n;Gb(w)^g.folder&&(g.folder=!g.folder,g.folder?(g._.classList.add("folder-icon"),v.style.backgroundImage=""):g._.classList.remove("folder-icon"));var D=u&&u[w.id];Cb(g._,"selecting",D||null);D&&D.e!=g._&&(u[w.id].e=g._);Gc==w.id&&vb!=g&&A(vb);n?(g.st.innerText=n,g.folder||("javascript:"==n||n.startsWith("javascript:&tm=")||n.startsWith("https://separator")?v.style.backgroundImage="":(w=v.style,u=n,n=u.indexOf("/",
u.indexOf(":")+3),0<n&&(u=u.slice(0,n)),w.backgroundImage='url("chrome://favicon/'+u+'")'))):v.style.backgroundImage="";f.tada===r&&(Hb(g,15),f.tada=void 0)}
function k(f){f=f.target||f;for(var g=0;f;){if(f.data&&f.classList.contains("item")){g=f;break}if(f==z.body||f.classList.contains("ListView"))break;f=f.parentNode}return g}
function h(f){Object.keys(f).forEach(r=>{(r=f[r])&&Cb(r.e,"selecting",0)});
for(var g in f)delete f[g]}
function p(f){if(f){var g=f.tD,r=g.path;eb[r]&&(eb[r].data=0);l.pullBkmk(r,function(w){f.v.onRemove();zb.bind(f,w,Ib(w,g,r))},ha,!0)}}
function q(f){f=f.ada.dPos(U.pos+1);1==f&&Jb&&Jb.clientY-Q.lv.getBoundingClientRect().y<U.offsetHeight/2-5&&(f=0);return f}
function t(f,g,r,w){var u=U.data,n=U.lst,v=n.salad,D=function(C){C&&p(n)};
switch(f){case "fold":var F=prompt(M("2j"),M("h9"));n=U.lst;if(F){var S=q(n);chrome.bookmarks.create({parentId:u.parentId,title:F,index:S},D)}break;case "addThis":S=q(n);1==S&&Jb&&Jb.clientY-Q.lv.getBoundingClientRect().y<U.offsetHeight/2-5&&(S=0);Kb(C=>{!C||w.ctrlKey?chrome.bookmarks.create({parentId:u.parentId,url:y.url,title:y.title,index:S},D):chrome.bookmarks.move(C.id,{parentId:u.parentId,index:S},D)});
break;case "addSep":m(w,u,n);break;case "edit":K(u,n);break;case "replace":K(u,n,void 0,y);break;case "delete":G(u,n);break;case "openFolder":Lb(jb,{path:u.id});break;case "pinTop":(()=>{function C(ia,ja,ka,Ma){bb.length?(ja&&(Ma=xa[ja.pos],ja.id==ia.id&&(ja.title=ia.title),Ma==ja&&(ia=xa.splice(ja.pos,1)[0],ja.pos<ka&&ka--,ja.pos=ka,xa.splice(ka,0,ia))),L(bb.shift())):D(ia||1)}
function L(ia){for(var ja=0,ka=(ia.title||"").startsWith(Y),Ma;Ma=xa[ja];){if(ka&&!Na&&Ma==ia){O="";ja=0;break}if(!(Ma.title||"").startsWith(Y))break;ja++}chrome.bookmarks.move(ia.id,{parentId:ia.parentId,index:ja},Ia=>{O&&Ia&&!ka?chrome.bookmarks.update(ia.id,{title:O+ia.title},Qb=>{C(Qb,ia,ja)}):C(Ia,ia,ja)})}
var O="\ud83d\udccc ",Y=O.trim(),xa=listView.arr,Na=I(u,v),bb=x(u,v,Na,n);Na=1<bb.length;C()})();
break;case "pinBot":(()=>{function C(xa){var Na=L.length,bb=(xa.title||"").startsWith("\ud83d\udccc ");chrome.bookmarks.move(xa.id,{parentId:xa.parentId,index:Na},ia=>{bb&&chrome.bookmarks.update(xa.id,{title:xa.title.slice(3)});Y.length?C(Y.shift()):D(ia||1)})}
var L=listView.arr,O=I(u,v),Y=x(u,v,O,n);O=1<Y.length;Y.length?C(Y.shift()):D(1)})();
break;case "openAll":f="";for(F in v)f+=n.arr[v[F].pos].url+"{BKMKBK}";chrome.runtime.sendMessage({urls:f,type:"openAll"},function(C){});
break;case "copyUrl":Ka(u.url);Mb(u.url);break;case "openInCurrent":Gb(u)?Q.etLoca.reload(u.id,u.title):chrome.tabs.update(y.id,{url:u.url},function(C){ha&&window.close()});
break;case "openInNewTab":Nb(u.url,function(C){C&&0<C.length?chrome.tabs.update(C[0].id,{active:!0}):chrome.tabs.create({url:u.url})});
break;case "openInBackgroud":Ob(C=>{chrome.tabs.create({url:u.url,index:C.index+1,active:!1})});
break;case "openInTmp":l.addToTmpUrls(u.url,u.title||"",0,()=>{Hb(U)});
break;case "openInIframe":F=l.newTab(T,u.url,Pb,P);F.title=u.title;Rb(Sb([F],0,jb.nextSibling));P.dirty();break;default:return 1}Tb();return 1}
function m(f,g,r,w){w=w?"https://separator.mayastudios.com/index.php?t=horz":"javascript:";navigator.userAgent.includes("Edg/")&&(w+="&tm="+Date.now());chrome.bookmarks.create({parentId:g.parentId,url:w,title:"───────────",index:r.ada.dPos(U.pos+1)},function(u){u&&(p(r),Tb(),(f.ctrlKey||1==f.button)&&K(u,r))})}
function I(f,g){return g[f.id]&&1<Object.keys(g).length}
function x(f,g,r,w){var u=w.arr,n=[],v=!1;if(r){for(var D in g)if(r=w.ada.d4sa(D,g[D]),r=u[r])v||r!=f||(v=!0),n.push(r);n.sort(function(F,S){return F.pos-S.pos})}v||n.push(f);
return n}
function K(f,g,r,w){Yb("assets/dialog.js",function(){var u=showDialog(z,z.body);va(u.t,M("v"));za(u.t1,Zb(M("ke").toUpperCase())+Zb(M("yq").toUpperCase()));var n=void 0!==r;va(u.btn0,n?M("3c"):M("u"));va(u.btn1,M("6"));var v=qa("TEXTAREA",u.t1);v[0].value=w?.title||f.title;v[1].value=w?.pendingUrl||w?.url||f.url||"";u.btn0.onclick=()=>{var D=S=>{S&&(p(g),u.s.remove())},F={url:v[1].value,
title:v[0].value};n?(F.parentId=r,chrome.bookmarks.create(F,D)):chrome.bookmarks.update(f.id,F,D)};
u.btn1.onclick=()=>{u.s.remove()}},E.showDialog)}
function G(f,g){var r=g.salad,w=I(f,r),u=x(f,r,w,g);Yb("assets/dialog.js",function(){var n=showDialog(z,z.body);za(n.t,M("yy"));za(n.t1,M("hj").replace("size",u.length));va(n.btn0,M("b8"));va(n.btn1,M("6"));n.btn0.onclick=()=>{var v=()=>{chrome.bookmarks.remove(u.shift().id,function(){0==u.length?p(g):v()})};
v();n.s.remove()};
n.btn1.onclick=()=>{n.s.remove()}},E.showDialog)}
function J(f){if(window.oncontextmenu==$b)$b(f);else{var g=k(f);if(g){aa(g);var r=g.data,w=g.lst,u=I(r,w.salad),n=ac(w.tD),v=bc(r.url,y.url);u=0==kc?["",[0,n?"addThis":0,M("sa"),1,,[0,"addSep",M("9")],[0,"fold",M("2j"),1]],[0,n?0:"openFolder",M("1"),1],[0,u?"openAll":0,M("jv")],[0,"edit",M("b"),1],[0,"delete",M("k")],[0,v?"replace":0,M("kb")],[0,"pinTop",M("eh"),1],[0,"pinBot",M("32")]]:["",[0,"openInCurrent",M("7z")],[0,"openInNewTab",M("g")],[0,"openInBackgroud",M("zh")],[0,"openInTmp",M("f")],
[0,"openInIframe",M("s6")],[0,"copyUrl",M("8x")]];cc(u,t,f,g,J,[M("dz"),M("i")],kc,D=>{l.menuPageBkmk=kc=D;J(f)});
Jb=f;dc=function(){aa()};
if(ec()){u=fc();if(g=na("addSep",u))g.title=M("h2"),g.oncontextmenu=D=>{Ga(D);m(D,r,w,!0)},g.onmousedown=D=>{1==D.button&&(Ga(D),m(D,r,w,!0))};
if(g=na("openInCurrent",u))g.title="右键不关闭弹窗",g.oncontextmenu=D=>{chrome.tabs.update(y.id,{url:r.url},function(F){Tb()});
Ga(D)}}}}}
function fa(f,g){f.innerText=g.ni?"⇈":"⇊";f.title=g.ni?M("8"):M("u4")}
function ya(f,g){g=g.icon;return f.clientX>g.offsetLeft+g.offsetWidth}
function oa(f,g,r,w){var u=f.ver;f=f.salad;g?(Cb(g,"selecting",r),r?f[g.data.id]={pos:g.pos,e:g,ver:u}:delete f[g.data.id]):void 0!=w&&(f[r.id]={pos:w,ver:u})}
function A(f){vb=f;f.lst.sel=Hc=f.pos;Gc=f.id}
function B(f){if(!sa){var g=k(f);if(g&&(aa(g),ya(f,g))){var r=g.data;if(g=r.url)f.shiftKey||f.ctrlKey?Ob(n=>{f.shiftKey?chrome.tabs.update(n.id,{url:r.url},function(){ha&&!f.ctrlKey&&window.close()}):f.ctrlKey&&Nb(r.url,v=>{v&&0<v.length?chrome.tabs.update(v[0].id,{active:!0}):chrome.tabs.create({url:r.url,
active:!1,index:n.index+1})})}):window.open(g);
else if(r.dateGroupModified){if(!f.ctrlKey){g=0;for(var w;w=P.children[g++];)if(w.d?.path==r.id&&w.type==Ea){var u=w;break}}u?Rb(u):(u=l.newTab(T,r.id,0,P),u.title=r.title,Rb(Sb([u],0,jb.nextSibling)));P.dirty()}}}}
function H(f){if(!sa)if(Ba){if(0==f.button){var g=k(f);g||(g=f.target,g=g.classList.contains("ListView")?{pos:g.ada.size,lst:g,data:{parentId:g.tD.path},getBoundingClientRect:function(){}}:0);
if(g){if(Db(g.lst.tD))return;var r=g.getBoundingClientRect()||{};r=f.clientY>r.y+r.height/2;var w=g.data,u=Oa.data;f=Oa.pos-g.pos;var n=Oa.lst==g.lst?0:g.lst;if(f||n){f=g.pos+1;r||f--;Q.onRemove();var v=Oa.lst,D=v.v,F=v.salad;g=Object.keys(F);var S=D.tP.pos,C=g[0].ver,L=0;r=v.ada.ni;try{g=g.sort(function(ka,Ma){if(F[ka].ver!=C)throw L=1,1;return F[ka].pos-F[Ma].pos})}catch(ka){}L&&(g=v.ada.sort(F,g.length));
r&&g.reverse();f<=S&&(S=0);function ja(ka,Ma){chrome.bookmarks.move(ka[ka.nxt],{index:Ma,parentId:w.parentId},function(Ia){ka.nxt++;if(Ia){var Qb=F[Ia.id],od=Qb.pos;S&&od<S&&D.tP.pos--;n&&(u.parentId==Ia.parentId||Db(v.tD)||delete F[Ia.id],n.salad[Ia.id]={id:Qb.id});ka.nxt<ka.length?ja(ka,Ia.index+1):Ia=0}if(!Ia){var Ic=jb.d.path;l.pullBkmk(Ic,function(Jc){Ca(Q.lv,Jc,Ib(Jc,jb.d,Ic))})}})}
g.nxt=0;v=n||v;f=v.ada.dPos(f);ja(g,f)}}Ub()}}else if(g=k(f)){v=g.lst;var O=g.data.id;F=v.salad;f.ctrlKey||h(F);r=ya(f,g);if(f.shiftKey){if(oa(v,g,1),vb&&vb.lst==v){O=g;var Y=g.pos-Hc,xa=0<Y,Na;0>Y&&(Y=-Y);Y++;for(Na=Y;0<Na;){var bb=g.pos+(xa?-1:1)*(Y-Na),ia=v.ada.getItem(bb);oa(v,O,ia,bb);O&&=v.rowSibling(O,xa);Na--}}}else r&&!F[O]?oa(v,g,1):(oa(v,g,0),r||(v.sel=null));!r||vb&&f.shiftKey||A(g)}}
function V(f){if(1==f.button)if(f.clientX<2*z.body.clientWidth/3){var g=k(f);g&&(f.r=g,Ba||aa(g),f.lv=g.lst,f.sy=f.lv.scrollTop,Vb=f)}else Vb=0;else if(0==f.button)Ba||aa();else if(2==f.button&&!Ba&&!sa&&(g=k(f))){var r=g.lst;z.body.addEventListener("mousemove",R);Ab=g.pos;Wa=-1;sa=g;sa.x=f.clientX;mc=r.getBoundingClientRect().y;sa.y0=f.clientY;sa.y=r.scrollTop+sa.y0-mc;aa(g)}}
function R(f){if(void 0!=f.clientX){Kc=f;var g=k(f)}else f=Kc,g=k(document.elementFromPoint(f.clientX,f.clientY));if(g&&(-1==Wa&&(g.pos!=Ab||3<Math.abs(sa.y0-f.clientY))&&(Wa=g.pos,Da=g.lst,Lc=Da.topPos(),ob||=N(0,0,"BoxSel"),Da.append(ob),Da.style.position="relative",Da.addEventListener("scroll",R)),-1!=Wa)){Wa=g.pos;var r=g.lst,w=sa.x,u=f.clientX,n=sa.y;f=r.scrollTop+f.clientY-mc;var v=u-w,D=f-n;0>D&&(D=-D,n=f);0>v&&(v=-v,w=u);Da.topPos()!=Lc&&(Ab<g.pos?(n=0,D=f):(n=f,D=r.scrollHeight+5));ob.style.top=
n+"px";ob.style.left=w+"px";ob.style.height=D+"px";ob.style.width=v+"px";aa(g)}}
function ca(f){if(-1!=Wa){var g=Ab,r=Wa;Ab>Wa&&(g=r,r=Ab);var w=0,u=1,n=Da.topPos(),v=Da.salad;for(f=f?0:1;g<=r;g++){var D=Da.ada.getItem(g);u&&g>=n&&(w=Da.findRow(g),u=0);w&&(w.pos==g?Cb(w,"selecting",f):w=0);f?v[D.id]={pos:g,id:D.id,e:w}:delete v[D.id];w&&=Da.rowSibling(w)}Wa=-1;window.oncontextmenu=$b;setTimeout(function(){window.oncontextmenu=0},20);
Da.removeEventListener("scroll",R);aa();ob.remove()}sa&&(z.body.removeEventListener("mousemove",R),sa=0)}
function aa(f){Wb!=f&&(Cb(Wb,"hot"),Wb=f,Cb(Wb,"hot",null!=f))}
function ta(f){f.srcElement.scrollTop=Mc}
function wa(f){if(f.ctrlKey||f.shiftKey||Ba||sa)$b(f);else{var g=f.target.href;"add"==g&&(g="平典搜索");f.dataTransfer.setData("url",g);Oa&&(Oa.classList.remove("sorting"),Oa=0);Ba&&(Ba=0,pb.hidden=1);if(f=k(f)){g=f.lst;var r=g.salad;r[f.data.id]||h(r);oa(g,f,1);Oa=f;A(f);aa(f)}}}
function ub(f){if(f=k(f))pb||(cb=N(0,0,0,"position:absolute;height:25px;width:50px;background:#2196f3e3;color:#FFF;z-index:9;border-radius:30px;left:10px;text-align:center;z-index:10;pointer-events:none;"),pb=N(0,0,0,"position:absolute;bottom:0;width:100%;height:39px;background-image:linear-gradient(rgba(0, 0, 0, 0), rgb(90 90 90 / 68%));color:#fff;z-index:9;pointer-events:none;"),N("P",pb,0,"position:absolute;width:100%;font-size:1em;bottom:0;text-align:center;line-height:0;").innerHTML=M("t")),
cb.innerText=1,pb.hidden=0,Ba=f,f=na("tabs"),f.insertBefore(pb,f.firstChild),f.insertBefore(cb,f.firstChild),z.body.addEventListener("mousemove",Pa)}
function Ub(){Ba&&(Ba=0,pb.remove(),cb.remove(),z.body.removeEventListener("mousemove",Pa),db&&(db.classList.remove(Xb),db=0),Oa.classList.remove("sorting"),Oa=0,aa())}
function Pa(f){if(!Db(jb.d)){var g=z.elementFromPoint(f.clientX,f.clientY);if(g=k(g)){var r=g.getBoundingClientRect();r=f.clientY>r.y+r.height/2?"drag-below":"drag-above";if(db!=g||Xb!=r)db&&db.classList.remove(Xb),db=g;db.classList.add(Xb=r)}}cb.style.left=f.clientX-cb.offsetWidth/2+"px";cb.style.top=f.clientY-cb.offsetHeight+"px"}
function Ca(f,g,r){var w=f.tP,u={size:g.length,ni:w.ni,bifun:d,getItem:function(n){return g[this.ni?g.length-1-n:n]},
sort:function(n,v){for(var D=[],F=0;F<g.length;F++){var S=g[this.ni?g.length-1-F:F],C=n[S.id];if(C&&(C.pos=F,C.ver=f.ver,D.push(S.id),0>=--v))break}return D},
dPos:function(n){return this.ni?g.length-n:n},
rPos:function(n){return this.ni?g.length-1-n:n},
d4sa:function(n,v,D){var F=this.rPos(v.pos),S=g[F];if(S&&S.id==n)return S.pos=F;F=-1;if(!D)for(D=0;S=g[D++];)if(S.id==n)return v.pos=this.dPos(D),this.d4sa(n,v,1);return F}};
f.dVer=r;f.ver=u;f.arr=g;f.ada=u;E.resetLv=()=>{f.reset(u,w.pos||0,w.offset)};
f.reset||l.initListView(f,u,30,"px",E);f.reset(u,w.pos||0,w.offset);gc()}
var Wb,Mc,Vb,Gc=-1,vb,Hc,Oa,db,Xb,Ba,pb,cb,Kc,Da,ob,Ab,sa,Wa,Lc,mc,kc=l.menuPageBkmk||0;z.addEventListener("mouseup",function(f){if(1==f.button){var g=0,r=Vb;if(!r)return;var w=r.lv,u=r.r;u&&w&&(f.srcElement==r.srcElement&&w.scrollTop==r.sy&&r.clientX==r.clientX&&r.clientY==r.clientY&&ya(r,u)&&(g=1,chrome.tabs.create({url:u.lv.href||"about:blank",active:!1}),Mc=w.scrollTop,w.onscroll=ta,setTimeout(w.onclick=function(){w.onscroll=0;w.onclick=H},300),u=Date.now(),l.fakePP=u,chrome.browserAction.openPopup(function(n){n&&
n.close();
r=chrome.runtime.lastError})),Vb=0);
g||Ba||aa()}Ba?2==f.button&&(window.oncontextmenu=$b,setTimeout(function(){window.oncontextmenu=0},20),Ub()):2==f.button&&sa&&ca(f.altKey)},1);
zb={init:function(f,g){var r=N(0,0,"UiTab"),w=N(0,N(0,r,"UiHead"),0,"display:flex;justify-content:space-between;"),u=N(0,r,"UITabo"),n=N(0,u,"ListView"),v=0;v||(u=hc(f),Sa(u,C=>{v=tb[f.id]=C||{};n.tP=v;fa(F,v);g()}));
E.lv=n;u=N(0,w,"folder-icon","padding-left:5px;");N(0,u,"item-icon");u.style.opacity="0.5";var D=r.etLoca=N("INPUT",w,0,"width:100%");r.etSch=N("INPUT",w,0,"width:65%;margin-left:3px;");r.etSch.placeholder="consider donation to help development";w=N("DIV",w,"tools");var F=N("BUTTON",w,"btn");F.id="top";F.innerText="⇧";F.title=M("h");F=N("BUTTON",w,"btn");F.id="bottom";F.innerText="⇩";F.title=M("q");F=N("BUTTON",w,"btn");F.innerText="☆";F.id="add";(()=>{var C=F;setTimeout(()=>{C.title=ea?.parentId==
f.path?M("p"):ea?M("3"):M("xz");ea&&va(C,"★")},500)})();
n.act=C=>{v.pos=v.offset=0;for(var L=n.arr,O=0;O<L.length;O++)if(L[O].id==C){v.pos=O-2;n.tada=O;break}Ca(n,L)};
F.oncontextmenu=C=>{Ga(C);Kb(L=>{ic(r,L)})};
F=N("BUTTON",w,"btn");F.id="sort";v&&fa(F,v);w.onclick=function(C){C=C.target;"sort"==C.id?(v.ni=!v.ni,null!=n.sel&&(n.sel=n.arr.length-1-n.sel,v.pos=n.sel),v.offset=0,Ca(n,n.arr),fa(C,v),n.scrollTop+5<n.scrollHeight-n.offsetHeight&&(n.scrollTop-=n.offsetHeight/2)):"top"==C.id?(v.pos=v.offset=0,Ca(n,n.arr)):"bottom"==C.id?(v.pos=v.offset=0,v.pos=n.arr.length-1,Ca(n,n.arr)):"add"==C.id&&Kb(L=>{var O=L||{url:y.url,title:y.title};K(O,O.parentId==f.path?n:0,L?void 0:f.path)})};
D.reload=function(C,L){Ib(null,f);L&&(f.title=L);r.taEl.getElementsByClassName("title")[0].innerText=f.title||M("5p");f.path=C;l.pullBkmk(C,function(O){Ca(r.lv,O,Ib(O,f,C))})};
D.onkeydown=function(C){if("Enter"==C.key){var L=D.value+"";if(L.startsWith("recent"))f.path=L,Ib(null,f),l.pullBkmk(L,function(Y){Ca(r.lv,Y,Ib(Y,f,L))});
else if(C=null,C=L.startsWith("chrome://bookmarks/?id=")?parseInt(L.slice(L.indexOf("=")+1)):isNaN(L)?L.startsWith("chrome://bookmarks/?q=")||L.startsWith("q=")?decodeURIComponent(L.slice(L.indexOf("q="))):"q="+L:parseInt(L),null!==C){var O=C+"";O.startsWith("q=")?D.reload(O,M("yh")+O.slice(2)):chrome.bookmarks.get(O,function(Y){Y&&Y.length&&D.reload(O,Y[0].title)})}P.dirty()}};
r.lv=n;r.tD=f;r.tP=v;n.tabIndex=0;n.v=r;n.ver=0;n.tD=f;n.onclick=H;n.salad=[];E.listView=n;var S;r.onRemove=function(){try{var C=n.fvp();C&&(v.pos=C.pos,v.offset=n.scrollTop-n.rowOffset(C),Xa(hc(f),v));S=0}catch(L){ma(L)}};
n.blue=function(){S&&clearTimeout(S);S=setTimeout(r.onRemove,350)};
r.onAttach=function(){r.lv.focus();r.onResume()};
r.onResume=function(){var C=f.path,L=eb[C];L&&(!L.data&&L.stl||L.ver!=r.lv.dVer)&&l.pullBkmk(C,function(O){Ca(r.lv,O,Ib(O,f,C))})};
v&&g();return r},
bind:Ca}}();
var c=zb.init(a,()=>{l.pullBkmk(b,function(d){if(d){var k=Ib(d,a,b);l.initListView?zb.bind(c.lv,d,k):l.loadListView(function(){zb.bind(c.lv,d,a,k)})}else chrome.bookmarks.search(a.title,h=>{h&&(h=h[0],a.path=h.id+"");
l.pullBkmk(a.path,function(p){var q=Ib(p,a,b);l.initListView?zb.bind(c.lv,p,q):l.loadListView(function(){zb.bind(c.lv,p,a,q)})})})})});
c.etLoca.value=Aa(a);return c}
function Ib(a,b,c){c||(c=b.path);var d=eb[c];if(!d){if(!a)return;d=eb[c]={s:[],ver:0}}var k=d.s.indexOf(b),h=0<=k;h&&d.s.splice(k,1);if(a){if(d.s.push(b),d.data=a,d.stl=0,!h&&qb){a=[];var p=eb,q;for(q in p)if(c=p[q],c=c.s){k=!0;h=0;for(var t;k&&(t=c[h++]);)if(t.id!=b.id){var m=qb[t.id];void 0!=m&&8>=m&&(k=!1)}else k=!1;k&&a.push(q)}a.forEach(function(I){delete p[I]})}}else 0==d.s.length&&delete eb[c];
return d.ver}
function jc(a,b){return((c,d)=>{function k(A,B,H){var V=m.grid().el;yb.topImp&&(A&&=A==V.f0?A.nextSibling:A.previousSibling,A||=V.f0?V.f0.nextSibling:V.firstChild);var R=!yb.uniImp||H.ctrlKey;H=y;if(d.includes("tmp"))for(var ca=0,aa;aa=m.grid(1).el.children[ca++];)if(aa.data.url===H.url){var ta=!0;break}-1==B?!H||!R&&x.data[H.id]||ta||(B={url:H.url,title:H.title,favIconUrl:H.favIconUrl,tabId:H.id},x.data[H.id]=B,m.layout([B],0,V,A)):-2==B&&chrome.tabs.query({currentWindow:!0},function(wa){for(var ub=
[],Ub=0,Pa;Pa=wa[Ub++];)if((R||!Za.favTabs[Pa.id])&&!ta){var Ca={url:Pa.url,title:Pa.title,favIconUrl:Pa.favIconUrl,tabId:Pa.id};Za.favTabs[Pa.id]=Ca;ub.push(Ca)}ub.length&&m.layout(ub,0,V,A)});
m.dirty()}
function h(A){chrome.windows.update(A,{focused:!0},function(B){})}
function p(A,B){chrome.tabs.update(B.id,{active:!0},function(){});
A.tabId=B.id;Za.favTabs[B.id]=A;h(B.windowId)}
function q(A){if(d.startsWith("imp_tmp")){!J.tmp||oa&&ha||(m.pref("del"),oa=1);var B=A.url;J.same?chrome.tabs.update(y.id,{url:B}):window.open(B);ha&&window.close()}else chrome.tabs.update(A.tabId||0,{active:!0},function(H){H?(h(H.windowId),Za.favTabs[H.id]||(Za.favTabs[H.id]=A)):chrome.tabs.query({url:A.url},function(V){(V=V&&V[0])?p(A,V):(V=A.url.lastIndexOf("#"),0<V&&chrome.tabs.query({url:A.url.slice(0,V)},function(R){R&&(R=R&&R[0])&&p(A,R)}))})})}
function t(){setTimeout(()=>m.onAttach(),100)}
d=d||"imp_";var m=N(0,0,"UiTab");m.id=c.id;var I=0;m.dirty=function(){I=(x.v||0)+1};
m.f1=function(){};
m.onload=function(A){var B=Za.favPlus;B||(B=Za.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`,fixed:1,dyn:1});A.f0=m.layout([B],0,A,0);A.bin=m.bin;A.dirty=m.dirty};
var x,K=d,G,J,fa;m.load=function(){Ua(fa=c.path.includes("tmp")?"opt_imp":"opt_tmp",A=>{J=A||{};void 0==J.tmp&&(J.tmp=c.path.includes("tmp"));void 0==J.same&&(J.same=c.path.includes("tmp"));lc(hc(c),B=>{G=B||{};l.pullImpt(K,H=>{eb[K]=x=H;m.layout(H.data);setTimeout(()=>{m.grid(1).el.parentElement.scrollTop=G.top},10);
setTimeout(()=>{m.grid(1).el.parentElement.scrollTop=G.top},100);
gc()})})})};
m.save=function(){var A=parseInt(m.grid(1).el.parentElement.scrollTop),B=G.top!=A&&m.grid(1).el.children.length;G.top=A;if(I>(x.v||0)){x.v=I;A=[];for(B=m.grid(1).el.firstElementChild;B;){var H=B.data;H&&!H.dyn&&A.push(H);B=B.nextElementSibling}x.data=A;l.log("saving::",K,A);l.saveImportabs(K,x);nc(hc(c),G)}else B&&nc(hc(c),G);J.changed&&(delete J.changed,Xa(fa,J))};
m.bin=[];m.pref=function(A,B,H,V){var R=m.grid();H=R.el;var ca=U,aa=0,ta=ca.data;switch(A){case "del":aa=oc(R,ca,m.bin,R.el);break;case "delSel":aa=pc(R,ca);break;case "restore":aa=qc(R,ca);break;case "moveSel":aa=rc(R,ca);break;case "selAll":sc(R);break;case "open":Ob(wa=>{chrome.tabs.create({active:!V.ctrlKey,url:ta.url,index:wa.index+1},function(ub){})});
break;case "addThis":k(!ca||ca.fixed?0:ca.nextSibling,-1,V);break;case "openFolder":Lb(jb,ca.data);break;case "addWnd":k(!ca||ca.fixed?0:ca.nextSibling,-2,V);break;case "uniImp":return yb.uniImp=!B,1;case "tweak":return yb.tkImp=B,1;case "topImp":return yb.topImp=B,H.f0&&(H.f0.remove(),H.f0=m.layout([H.f0.data],0,H,B?H.firstChild:0)),1;case "isTmp":return J.tmp=!!B,J.changed=1;case "isSame":return J.same=!!B,J.changed=1;case "multi":return ca&&R.els(ca)||(yb.mtImp=B),1;case "copyUrl":Ka(ta.url);Mb(ta.url);
break;case "openInCurrent":Ob(wa=>{chrome.tabs.update(wa.id,{url:ta.url},function(){ha&&void 0!=V&&window.close()})});
break;case "openInNewTab":Nb(ta.url,function(wa){wa&&0<wa.length?chrome.tabs.update(wa[0].id,{active:!0}):chrome.tabs.create({url:ta.url})});
break;case "openInBackgroud":Ob(wa=>{chrome.tabs.create({url:ta.url,index:wa.index+1,active:!1})});
break;case "openInIframe":H=l.newTab(T,ta.url,Pb,P);H.title=ta.title;Rb(Sb([H],0,jb.nextSibling));P.dirty();break;case "topImp1":A=ta.favPlus={url:"add",title:"添加当前标签页",favIconUrl:`chrome-extension://${chrome.runtime.id}/images/icon_add.ico`};m.layout([A],0,H,ca.nextElementSibling);break;case "pinTop":aa=tc(R,ca,1);break;case "pinBot":aa=tc(R,ca);break;case "goTop":Q.grid(1).el.parentElement.scrollTop=0;break;case "goBot":Q.grid(1).el.parentElement.scrollTop=Q.grid(1).el.parentElement.scrollHeight}Tb();
aa&&m.dirty();return 1};
var ya=l.menuPageImp||0;m.oncontextmenu=function(A){for(var B=A.target,H=B.S;!H&&B&&!B.classList.contains("item-sqr");)B=B.parentNode;U=B;var V=B.data;B||(H=1);H=m.grid();V=0==ya?["",[0,"open",[M("g"),V.url]],,[0,"addThis",M("sa"),1,,[0,"addWnd",M("3u")],[0,"addAll",M("4")]],[0,"topImp1",M("s")],[0,"pinTop",M("eh")],[0,"pinBot",M("32")],[0,"del",M("dg"),m.bin.length,[0,"restore",M("r")]],[0,"multi",M("mz"),yb.mtImp||H.els(B),[0,"moveSel",M("24")],[0,"delSel",M("jc")],[0,"selAll",M("tm")]],[1,c.path.includes("tmp")?
"isTmp":0,M("y"),J.tmp],[1,c.path.includes("tmp")?"isSame":0,M("7z"),J.same]]:["",[0,"openInCurrent",M("7z")],[0,"openInNewTab",M("g")],[0,"openInBackgroud",M("zh")],[0,"openInIframe",M("s6")],[0,"goTop",M("h")],[0,"goBot",M("q")],[0,"copyUrl",M("8x")]];cc(V,m.pref,A,B,m.oncontextmenu,[M("dz"),M("i")],ya,R=>{l.menuPageImp=ya=R;m.oncontextmenu(A)});
Jb=A;if(ec()){B=fc();if(uc=na("open",B))uc.oncontextmenu=R=>{Ga(R);m.pref("openInCurrent")};
uc=na("addSep",B);if(uc=na("openInCurrent",B))uc.title="右键不关闭弹窗",uc.oncontextmenu=R=>{Ga(R);m.pref(uc.id)}}};
m.dblclick=function(A,B){A=B.data;"add"!=A.url&&chrome.tabs.create({active:!0,url:A.url,index:y.index+1},function(H){})};
m.click=function(A,B){var H=B.data;if("add"==H.url)k(B,-1,B);else{for(A=A.target;A&&!A.classList.contains("item-sqr");)A=A.parentNode;U=A;q(H)}};
var oa;E.initGridTab?(initGridTab(E,z,m),t()):Yb("gridtab.js",function(){l.initSortable&&!Fb?(l.initSortable(z,E),initGridTab(E,z,m),t()):l.loadSortable(function(){l.initSortable(z,E);initGridTab(E,z,m);t()})});
return m})(a,b)}
function vc(a,b){var c=a.firstChild;if(c)return c;for(;a&&a!=b;){if(c=a.nextSibling)return c;a=a.parentNode}}
function wc(a){a=a.path;a.startsWith("sch:")&&(a=a.slice(4));return a}
function xc(a,b,c,d){l.putSchKey(b);if(!d||b)a?(b=a.replace("%s",b),c?chrome.tabs.update(y.id,{url:b}):window.open(b)):chrome.search.query({text:b,disposition:"NEW_TAB"}),ha?window.close():yc()}
var zc;function Ac(a,b){function c(){t=wc(a);h.schEng.innerText=t||M("5")}
function d(m,I){m=m.value.trim()||h["1"].value.trim()||h["2"].value.trim();m!=q.key&&(q.key=m,Xa(k,q));xc(t,m,I)}
b=N(0,0,"UiTab");b.innerHTML='\n        <div class="UiHead">\n        \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div id="pasteIt" style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;" title="获取手机上的剪贴板数据，\n 当安卓无限词典处于前台无需复制只需选择，\n 当处于后台需要打开悬浮按钮。\n点击此处粘贴至浏览器内部的输入框">\n\t\t\t\t\t新的搜索&ensp;\n\t\t\t\t</div>\n                <textarea id=\'1\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="11" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="12" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n            \n            <div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">\n                <div style="white-space:nowrap;padding-left:5px;font-size:.89em;width:100px;text-align:center;padding-top:7.9px;">当前页搜索&ensp;</div>\n                <textarea id=\'2\' class=\'eta\' style="resize:vertical;min-height:30px"></textarea>\n                <div class="tools" style="margin-top:2.8px;height:30px">\n                    <button class="btn" id="21" title="搜索">\ud83d\udd0d</button>\n                    <button class="btn" id="22" title="新标签页打开" style="">\ud83d\udd17</button>\n                    <!--button class="btn" id="23" title="复制 | 右键粘贴">\ud83d\udccb</button-->\n                </div>\n            </div>\n\t\t\t\n            <div class="divider">\n\t\t\t    <HR style=\'margin:15px;opacity:.8;\'>\n                <span class="dividerTitle" id="dt"></span>\n            </div>\n\t\t\t\n            <div style="height:18px;display:flex;flex-direction: row;position:fixed; bottom:0; width:100%; user-select:none; cursor: pointer;">\n                <div id="schEng" class="tools" style="height:30px;width: 100%;font-size:10px;padding-left:5px;color:#888">\n                    默认搜索引擎\n                </div>\n            </div>\n            \n        </div>\n        <div class="UITabo">\n            <div class="ListView" id="key"></div>\n        </div>';
for(var k="v_"+lb.id+"_"+a.id,h={},p=b,q={};p=vc(p,b);)p.id&&(h[p.id]=p);var t;c();b.et=h["1"];va(h.dt,a.title);N("SPAN",0,"tabx").innerText="";p=N(0,0,"item-icon");N(0,p,"img web").style.backgroundImage=Bc(a.path.slice(4));p.style="display: inline-block;transform: translateY(4px);";h.dt.insertBefore(p,h.dt.firstChild);h["11"].onclick=function(){d(h["1"])};
h["21"].onclick=function(){d(h["2"],!0)};
h["22"].onclick=function(){d(h["2"])};
h.schEng.onclick=function(){var m=prompt("输入搜索引擎地址，用%s代替关键词：",t);void 0!=m&&m!=t&&(a.path="sch:"+m,c(),P.dirty())};
Ha("keydown",function(m){"Enter"!==m.key||m.shiftKey||(Ga(m),d(m.target))},0,h["1"]);
Ha("keydown",function(m){"Enter"!==m.key||m.shiftKey||(Ga(m),d(m.target,!0))},0,h["2"]);
b.onAttach=function(){xb==Cc&&setTimeout(()=>{h.schEng.click()},250);
zc||(zc=N(0,0,"sch-pane"),yc());h.key.append(zc)};
b.onRemove=function(){};
Qa(k,m=>{if(m=m[k])q=m,h["1"].value=m.key||"";Dc(I=>{h["2"].value=I})});
return b}
function Ec(a,b){a=N(0,0,"UiTab");var c=N("IFRAME",a);b.includes(":")||(b="https://"+b);c.src=b;c.style.width="100%";c.style.height="100%";return a}
function Fc(a,b){return((c,d)=>{function k(){return t}
function h(x){x=x.src;q.shadow.innerHTML=x;p.s=q.shadow;var K=x.lastIndexOf("<script>");K&&(K=x.slice(K+8,x.indexOf("</script>",K+8)),eval(K.replace("_bg()",k.name+"()")))}
var p=N(0,0,"UiTab disp0"),q=N(0,p);q.src=d;q.style.width="100%";q.style.height="100%";q.shadow||(q.shadow=q.attachShadow?q.attachShadow({mode:"open"}):N(0,q));p.d=c;var t,m=hc(c),I=m+"_";p.k=m;p.tmps=l.d();p.onRemove=()=>{if(t.view.onSave)t.view.onSave();if(t.changed){var x={};Object.assign(x,t);delete t.changed;delete x.changed;delete x.view;delete x.src;Xa(t.view.k,x)}};
p.reload=x=>{h(x)};
Qa([m,I],x=>{p._bg=t=x[m]||{};t.view=p;t.src=x[I];delete t.changed;if(t.src)h(t);else if("百度高级搜索"==c.title){var K=new XMLHttpRequest;K.open("GET","assets/百度高级搜索.html",!!t);K.onreadystatechange=function(G){4===K.readyState&&200===K.status&&(t.src=K.responseText,h(t))};
K.send()}});
return p})(a,b)}
function Ka(a){function b(c){document.removeEventListener("copy",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("copy",b,!0);document.execCommand("copy")}
function Nc(a){function b(c){document.removeEventListener("paste",b,!0);c.stopImmediatePropagation();c.preventDefault();c.clipboardData.setData("text/plain",a)}
document.addEventListener("paste",b,!0);document.execCommand("paste")}
function Yb(a,b,c){c?b():(c=document.createElement("script"),c.type="text/javascript",c.onload=b,c.src=a,document.body.appendChild(c))}
var W;function Oc(a){l.initSortable(z,E);W=new Sortable(P,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabH",root:!0,forceFallback:!1,sort:!0,onMove(b){this.options.animation=rb?300:0;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){W.did(b)&&P.dirty()},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;E.disani=0},click(b){},trace:function(){console.log("trace"+Error().stack)}});
a&&(W._onTapStart(a),a.constructor==DragEvent?W._onDragStart(a):W._onDrop(a),Pc(a,1))}
var Fb=1;function Pc(a,b){W?a&&(b?P.onclick=a.target.ondragstart=void 0:Pc(a,1)):l.initSortable&&!Fb?Oc(a):l.loadSortable(function(){Oc(a)})}
P.onclick=function(a){(a.ctrlKey||a.shiftKey)&&a.target!=P&&Pc(a)};
document.ondblclick=function(a){var b=a.target;b==P?W&&W.multiDrag._deselectMultiDrag():Q&&Q.contains(b)&&Q.dblclick&&Q.dblclick(a,b)};
var Qc={};document.onkeydown=function(a){if(!Qc[a.key]){Qc[a.key]=1;var b=a.target;b.grido&&(b=b.grido());if(b.S){var c=0;a.ctrlKey?"a"==a.key?(sc(b.S),c=1):"z"==a.key&&(qc(b.S),c=1):"Delete"==a.key&&(pc(b.S,0),c=1);c&&(b.dirty(),$b(a))}}};
document.onkeyup=function(a){Qc[a.key]=0};
var Rc,Sc;function Tc(){l.initTabs(function(a,b,c){function d(){if(null!==nb&&ha&&2!=lb.t0&&sb)try{x.scrollTop=nb;return}catch(G){}try{x.scrollTop=jb.offsetTop-ba/3*Sc}catch(G){}}
var k=!Rc;T={};if(0==a.length){function G(J,fa,ya){void 0===ya&&(ya=Cc);"v"==J&&(J="");J=l.newTab(T,J,ya,0,fa,a.length+1);a.push(J)}
if(b.name==M("sk")||2==b.t0){var h=new XMLHttpRequest;h.open("GET","assets/default_sch_engines.js",!1);h.onreadystatechange=function(J){4===h.readyState&&200===h.status&&eval(h.responseText.replaceAll("doit",G.name))};
h.send();b.t0=2}else if(b.name==M("fv")||3==b.t0)G("recent",0,Ea),G("",0,Uc),G("",M("5"),Cc),G("imp_tmp",M("xx1k"),Fa);else if("tabs1"==b.id||1==b.t0)G("0",0,Ea),G("1",0,Ea),G("2",0,Ea),G("recent",0,Ea)}W&&(W=0,P.onclick=function(G){(G.ctrlKey||G.shiftKey)&&G.target!=P&&Pc(G)});
if(b.type==Vc&&c.bar){for(var p=[],q={},t=a.length-1;0<=t;t--){var m=a[t];m.pos=t;m.auto&&m.type==Ea&&(a.splice(t,1),q[m.path]=m);T[m.id]=m}function G(J){if(void 0!=J.dateGroupModified){J=J.id;var fa=q[J];fa?(delete q[J],delete T[J]):(fa=l.newTab(T,J,Ea),fa.auto=1);p.push(fa)}}
G({dateGroupModified:1,id:"1",title:M("n3")});for(t=0;t<c.bar.length;t++)G(c.bar[t]);for(t=0;t<a.length;t++)p.splice(a[t].pos||0,0,a[t]);a=p;for(var I in q)t=q[I],delete T[I],Ya(hc(t,b)),t.type==Uc&&Ya(hc(t,b)+"_")}mb=0;nb=void 0===c.scroll?null:parseInt(c.scroll)||0;lb=b;qb=c.hots||{};rb=yb.expTab=c.exp;sb=c.rec;void 0===sb&&(sb=2!=b.t0);gb.innerText="";jb=Q=ab=0;kb=[];tb=b.tPs||{};var x=k?P:P.cloneNode();b=P;ba=rb?6:3;ha&&(ba=rb?6:4);Rc=Math.ceil(Sc*ba);x.style.maxHeight=Rc+"px";x.bin=Wc;var K=
0;x.dirty=function(){K=Za.tabsVer+1};
x.save=function(){if(K>Za.tabsVer){Za.tabsVer=K;$a.length=0;for(var G=x.firstElementChild;G;){var J=G.d;J&&$a.push(J);G=G.nextElementSibling}$a.now=ab.id;l.saveTabs(lb,$a,()=>{})}};
window.tmpTabH=x;$a=a;ab=0;c=Sb($a,c.tix,0,x);ab||(ab=a[0],c=x.firstElementChild,c==hb&&(c=c.nextElementSibling));x.append(hb);x.style.minHeight="";k||(Xc.observe(x),x.style.position="absolute",x.style.visibility="hidden",ib.insertBefore(x,P),P=x,Yc(),Xc.unobserve(b));Rb(c,1);hb.fixed=1;x.oncontextmenu=Zc;X.dirty||$c();k?setTimeout(()=>{Sc=Math.max(hb.offsetHeight,P.firstElementChild.offsetHeight);Rc=Math.ceil(Sc*ba);x.style.maxHeight=Rc+"px";x.MH=Rc;Yc();d()},1):d();
k||(x.style.position="",x.style.visibility="",b.remove())},ha?0:window)}
Tc();function ad(a){var b=Object.create(Object.getPrototypeOf(a));Object.getOwnPropertyNames(a).forEach(function(c){var d=Object.getOwnPropertyDescriptor(a,c);Object.defineProperty(b,c,d)});
return b}
function Sb(a,b,c,d){var k=d||P;d||(c||=hb);for(var h=0,p=0;p<a.length;p++){var q=a[p];d&&(a[p]=q=ad(q));var t=q.type,m=q.title,I=q.ico;m||(t==Ea&&(m=q.path?.startsWith("recent")?M("65"):M("5p")),t==Fa&&(m=q.path?.includes("tmp")?M("xx1k"):M("fq")),t==bd&&(m="无限词典"),t==Uc&&(m=M("gl")));I||(t==Ea&&(I="★"),q.type==Pb&&(I="\ud83c\udf10"),q.type==Cc&&(I="\ud83c\udf10"));t=N("LI",0,"tab");q.type==cd&&(t.classList.add("tab-sep"),q.path&&(t.style=q.path));if(I){var x=N("SPAN",t,"tabx");x.innerText=I}q.type==
Cc&&q.path&&(x.innerText="",t.con=N(0,t,"item-icon"),t.icon=N(0,t.con,"img web"),t.icon.style.backgroundImage=Bc(q.path.slice(4)));let K=N("SPAN",t,"tabx title");(q.type==cd?za:va)(K,m);0!=q.type||Db(q)||chrome.bookmarks.get(q.path,function(G){G&&G.length&&(K.innerText=G[0].title)});
t.onclick=dd;t.ondblclick=ed;t.oncontextmenu=Zc;t.id="tab_"+q.id;T[q.id]=q;W||(t.draggable=!0,t.ondragstart=Pc);t.d=q;d&&qb&&(m=qb[q.id],void 0!=m&&(t.classList.add("tab-hot"),t.style.setProperty("--bg",fd(132,175,255,255,255,255,999==m?.85:.0625*m)),999!=m&&kb.push(t)));c&&c.parentNode==k?k.insertBefore(t,c):k.append(t);q.type==cd&&q.br&&(m=N("div",0,"flex-break"),k.insertBefore(m,t));h||(void 0!=b?p==b&&(ab=q,h=t):h=t)}d&&kb.sort(function(K,G){return-K.lev1+G.lev1});
return h}
const Yc=a=>{a=P.scrollHeight>Rc;var b=P.style;!a^"visible"==b.overflowY&&(b.overflowY=a?"scroll":"visible",b.minHeight&&(b.minHeight=""))},Xc=new ResizeObserver(Yc);
Xc.observe(P);var Wc=[];function dd(a){if(!a.shiftKey&&!a.altKey&&!a.ctrlKey){for(a=a.target;a&&!a.classList.contains("tab");)a=a.parentNode;Rb(a);mb=1;clearTimeout(P.saving);P.saving=setTimeout(gd,800)}}
hb.onclick=function(a){U=0;hd(a)};
P.ondblclick=function(a){W&&a.srcElement==P&&W.multiDrag._deselectMultiDrag()};
function ed(a){if(!a.ctrlKey&&!a.shiftKey){for(a=a.srcElement;a&&!a.classList.contains("tab");)a=a.parentNode;rb=!rb;id(a)}}
function jd(a){return a&&a.parentNode==P&&a!=hb}
function id(a){ba=rb?6:3;ha&&(ba=rb?6:4);P.MH=Rc=Math.ceil(Sc*ba);P.style.maxHeight=Rc+"px";Yc()}
function kd(a){if(jd(a)){var b={};Object.assign(b,a.d);var c=a.cloneNode(1);c.onclick=dd;c.ondblclick=ed;c.oncontextmenu=Zc;b.id=l.newTabid(T,P.children.length);W||(c.draggable=!0,c.ondragstart=Pc);c.d=b;P.insertBefore(c,a.nextSibling);Rb(c)}}
function oc(a,b,c,d){if(!b.fixed){d=c?{e:b,idx:[].indexOf.call(d.children,b)}:{};var k=a?a.els().indexOf(b):-1;~k&&(a.els().splice(k,1),d.sel=1);b.remove();c&&c.push(d);return!0}}
function pc(a,b,c){if(a&&(b=a.els(),b.length)){a.el.bin.push({es:b.concat(),idx:[].indexOf.call(a.el.children,b[0])});a=0;for(var d;d=b[a++];)if(d.remove(),c)try{c(d)}catch(k){ma(k)}b.length=0;return!0}}
function tc(a,b,c){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var d=a.els();d.length||(d=[b]);if(d.length){b=0;for(var k;k=d[b++];)k.remove();for(b=0;k=d[b++];)c?a.el.insertBefore(k,a.el.firstElementChild):a.el.append(k);return!0}}}
function rc(a,b){if(!b.fixed&&a){a.multiDrag.dragStartGlobal(0,1);var c=a.els();if(c.length&&-1==c.indexOf(b)){for(var d=0,k;k=c[d++];)k.remove();b=b.nextElementSibling;for(d=0;k=c[d++];)a.el.insertBefore(k,b),b=k.nextElementSibling;return!0}}}
function qc(a,b){if(a){var c=a.el.bin.pop();if(c){var d=a.el,k=d.children[c.idx||0];if(b=c.e)d.insertBefore(b,k),c.sel&&a&&a.els().push(b);else{b=c.es;c=0;for(var h;h=b[c++];)d.insertBefore(h,k),a&&a.els().push(h);b=b[0]}return b}}}
function sc(a){if(a){var b=a.els(),c=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||(b.push(d),d.classList.add("selected"))}}
function ld(a){if(a){var b=a.els(),c=b.length=0;a=a.el.children;for(var d;d=a[c++];)d.fixed||-1!=b.indexOf(d)||d.classList.remove("selected")}}
function cc(a,b,c,d,k,h,p,q){U=d;ec()?(Z=md(0,a,b),nd(c),h?setTimeout(()=>pd(h,p,q),5):qd&&qd.remove()):Yb("settings.js",function(){initSettings(E,z,"settings.css");
ec()&&k(c)});
$b(c)}
function rd(a,b){var c=a.d.path,d=function(k){Hb(a);if(a.d==ab&&Q&&Q.onResume)Q.onResume()};
Kb(k=>{!k||b.ctrlKey?chrome.bookmarks.create({parentId:c,url:y.url,title:y.title,index:b.shiftKey?0:void 0},d):k.parentId!=c?chrome.bookmarks.move(k.id,{parentId:c,index:b.shiftKey?0:void 0},d):Mb("已经添加到该文件夹！<br>"+M("85"))})}
function Lb(a,b){chrome.bookmarks.get(b.path,function(c){if(c=c?c[0]:0)Tb(),ic(a.tabView,c)})}
function ic(a,b){if(b)if(b.parentId==a?.lv.tD.path)a.lv.act(b.id);else{for(var c,d=0,k;k=P.children[d++];)if(k.d?.path==b.parentId&&k.type==Ea){c=k;break}c?Rb(c):(c=l.newTab(T,b.parentId,Ea,P),Rb(Sb([c],0,a.taEl.nextSibling)));c&&(P.dirty(),setTimeout(()=>{Q.lv&&Q.lv.act(b.id)},500))}}
function hd(a){var b=U,c=["",[0,["tabFav",0],[M("m")],1,,[0,"tabRec",M("65"),1]],[0,["tabImp",0],[M("fq")],1,,[0,"tabTmp",M("xx1k"),1]],[0,"tabSch",M("gv"),1],[0,"tabWeb",M("s6"),1],[0,["tabCustomX",0],[M("d")],1,,[0,"tabBaidu",M("百度高级搜索"),1],[0,"tabCustom",M("gl"),1]]];cc(c,sd,a,b,hd)}
function Zc(a){W||Pc(a);if(window.oncontextmenu==$b)$b(a);else{for(var b=a.target,c=b==P;!c&&b&&!b.classList.contains("tab");)b=b.parentNode;c=b.d.type==Ea;var d=ac(b.d),k=b.d.type==Cc,h=b.d.type==Fa,p=b.d.type==Pb;c=["",[0,d?["addFav",0]:0,[M("xz")],1,,[0,d?["newFavFolder",0]:0,[M("x")],1],[0,d?["openLocatedFoler",0]:0,[M("1")],1]],[0,k?["schNew",0]:0,M("iq"),1,[0,k?["schThis",0]:0,M("d5"),1]],[0,p||k||c?["openWeb",0]:0,M("g"),1],[0,b.d.type==Uc?["editSrc",0]:0,M("e5"),1],[0,h?["setTemp",0]:0,[M("m5")],
1],[0,["copyUrl",0],[M("r5")],1],[0,["newTab",0],[M("qg")],1,,[0,["dupTab",0],[M("j")]],[0,["newSep",0],[M("9")]]],[0,["closeTab",0],[M("tg")],Wc.length,[0,["resumeTab",0],[M("n")]]],[0,["multiTab",0],[M("hv")],yb.mt||W&&W.els(b),[0,["moveTabs",0],[M("2")]],[0,["closeTabs",0],[M("uv")]],[0,["selTabs",0],[M("tm")]]],[1,ha?"recPos":0,[M("bc")],sb],[1,"expTab",[M("uy")],rb]];cc(c,sd,a,b,Zc);if(ec()){Z.e=a;a=fc();if(b=na("selTabs",a))b.title=M("a"),b.oncontextmenu=q=>{ld(W);Ga(q);Tb()};
if(b=na("copyUrl",a))b.title=M("x1"),b.oncontextmenu=q=>{Ga(q);td()},b.onmousedown=q=>{1==q.button&&(Ga(q),ud())};
if(b=na("addFav",a))b.title=M("85");if(b=na("addImp",a))b.title=M("85")}}}
function ud(){var a=U,b=a.d;if(ac(b))chrome.bookmarks.get(b.path,function(k){if(k=k?k[0]:0)Tb(),Yb("assets/dialog.js",function(){var h=showDialog(z,z.body);va(h.t,"Edit");za(h.t1,Zb("NAME"));va(h.btn0,"Save");var p=qa("TEXTAREA",h.t1);p[0].value=k.title;h.btn0.onclick=()=>{var q=p[0].value;chrome.bookmarks.update(b.path,{title:q},t=>{t&&(va(ra("tabx title",a),q),h.s.remove())})};
h.btn1.onclick=()=>{h.s.remove()}},E.showDialog)});
else{var c=U.d.title,d=prompt("标题：",c);d!=c&&void 0!=d&&(Tb(),P.dirty(),(b.type==cd?za:va)(ra("tabx title",a),b.title=d),Hb(a))}}
function td(){var a=U,b=a.d,c=Aa(U.d),d=prompt("请输入新地址（可以是书签url或者http网址）",c),k="v_"+lb.id+"_"+b.id,h=d!=c;if(d){Tb();function q(t,m){La.remove(k);var I=b.id;Object.keys(b).forEach(function(x){delete b[x]});
b.id=I;b.type=p;b.title=t;p==Fa&&(d.startsWith("important://")&&(d=d.slice(12)),d.startsWith("imp_")||(d="imp_"+d));b.path=d;h&&P.dirty();t=a.nextElementSibling;oc(W,a,0,P);Sb([b],0,t);a==jb&&Rb(a);Hb(a,m)}
if(d.startsWith("chrome://bookmarks")||!isNaN(d)){var p=Ea;q(e[0].title,350)}else d.startsWith("imp")?(p=Fa,c=b.type==p?b.title:0,b.path.includes("tmp")!=d.includes("tmp")&&(c=0),q(c)):d.startsWith("custom")?(p=Uc,c=b.type==p?b.title:0,q(c||M("gl"))):d.startsWith("sch:")?(p=Cc,q(vd(d,!0)||M("gv"))):(p=Pb,q(vd(d,!0)))}}
function vd(a,b){var c=a,d=c.indexOf(":");for(0<=d&&(c=c.slice(d+1));c.startsWith("/");)c=c.slice(1);d=c.indexOf(".");if(0<d){if(a=c.slice(0,d),"www"==a){var k=c.indexOf(".",d+1);0<k&&(a=c.slice(d+1,k))}}else a=c;b&&(a=a.toUpperCase());return a}
function wd(a){a.delay?setTimeout(Tb,10):Tb()}
function fd(a,b,c,d,k,h,p){a=Math.round(a*(1-p)+d*p);b=Math.round(b*(1-p)+k*p);c=Math.round(c*(1-p)+h*p);return"rgb("+a+" "+b+" "+c+")"}
const Ea=0,Fa=1,bd=2,Pb=4,Uc=5,Cc=6,cd=7;
function Rb(a,b){if(jd(a))if(a.d.type==cd)Rb(a.nextElementSibling);else{if(jb){jb.classList.remove("tab-now");var c=Q;if(c&&!c.hidden){if(c.onRemove)try{c.onRemove()}catch(q){}c.hidden=1;c.style.display="none"}}jb=a;if(qb){c=kb.indexOf(a);0<c&&kb.splice(c,1);kb.push(a);15<kb.length&&(c=kb.shift(),delete qb[c.d.id],c.lev1=999,c.style.setProperty("--bg",fd(132,175,255,255,255,255,.85)));a.classList.add("tab-hot");c=kb.length-1;for(var d=c-1;0<=d;d--){var k=kb[d];qb[k.d.id]=k.lev1=c-d;k.style.setProperty("--bg",
fd(132,175,255,255,255,255,.0625*(c-d)))}}a.classList.add("tab-now");d=ab=a.d;c=a.tabView;if(!c){c=d.type;try{c==Ea?(c=Eb(d,d.path,a),c.taEl=a):c=c==Fa?jc(d,d.path):c==bd?newTabPlainDict(d,d.path):c==Pb?Ec(d,d.path):c==Uc?Fc(d,d.path):c==Cc?Ac(d,d.path):""}catch(q){console.error(q),c=""}c||=N(0,gb,0,"错误");a.tabView=c}Q=c;d=c.parentNode!=gb;if(c.hidden||d)if(c.hidden=0,c.style.display="",d&&gb.append(c),c.onAttach)try{c.onAttach()}catch(q){ma(q)}c=a.offsetHeight;d=a.offsetTop+c;k=P.scrollTop;var h=
P.clientHeight,p=null;d<k+c/2+9?p=a.offsetTop:d>k+h&&(p=d-h);null!==p&&P.scrollTo({top:p,behavior:b?"auto":"smooth"})}}
E.onfocus=function(a){if(E._blr&&(E._blr=0,Q&&Q.onResume))Q.onResume()};
E.onblur=function(a){E._blr=1;if(Q&&Q.onRemove)Q.onRemove(1);gd();xd()};
E.onbeforeunload=function(){yd();if(Q&&Q.onRemove)Q.onRemove(1);P.save();xd();ha||delete l.bkWnds[y.id]};
function sd(a,b,c,d){function k(){Tb();p&&(Rb(Sb([p],0,U?.nextElementSibling)),h=1);h&&P.dirty()}
var h=0,p=0,q=U?.d;switch(a){case "addFav":rd(U,d);break;case "newFavFolder":chrome.bookmarks.get(q.path,function(m){if(m=m?m[0]:0){var I=m.title||"",x=I.replace(/\d+$/g,function(K){return(parseInt(K)+1).toString()});
(I=prompt("新建文件夹",x!==I?x:I+" 1"))&&chrome.bookmarks.create({parentId:m.parentId,title:I,index:m.index+1},function(K){K&&(p=l.newTab(T,K.id,Ea,P),k(),P.save())})}});
return;case "openLocatedFoler":return Lb(U,q),1;case "newTab":return hd(Z.e),1;case "tabFav":p=l.newTab(T,ea?ea.parentId:"0",Ea,P);break;case "tabRec":p=l.newTab(T,"recent=1000",Ea,P);break;case "tabImp":p=l.newTab(T,"imp_",Fa,P);break;case "tabTmp":p=l.newTab(T,"imp_tmp",Fa,P);break;case "tabAll":p=l.newTab(T,"all",Fa,P);p.title="全部页面";break;case "tabSch":p=l.newTab(T,"sch:",xb=Cc,P);p.title=M("gv");setTimeout(()=>{xb=0},250);
break;case "tabPDict":p=l.newTab(T,"",bd,P);break;case "tabWeb":b=prompt("输入网址：","");if(void 0!=b)b=b||"about:blank",p=l.newTab(T,b,Pb,P,vd(b,!0));else return;break;case "tabBaidu":p=l.newTab(T,"custom://",Uc,P,"百度高级搜索");break;case "tabCustom":p=l.newTab(T,"custom://",Uc,P,M("gl"));break;case "schNew":case "schThis":Dc(m=>xc(wc(U.d),m,"T"==a[3],!0));
break;case "setTemp":l.setTmpUrlPath(q.path);break;case "openWeb":var t=q.path;q.type==Cc&&(t=(new URL(t.slice(4))).origin+"");q.type==Ea&&(t=Aa(q));Nb(t,function(m){m&&0<m.length&&!d.ctrlKey?chrome.tabs.update(m[0].id,{active:!0}):Ob(I=>{chrome.tabs.create({active:!d.ctrlKey,url:t,index:I.index+1})})});
break;case "copyUrl":b=Aa(U.d);Ka(b);Mb(b);Hb(U);break;case "dupTab":kd(U);h=1;break;case "editSrc":zd(U);break;case "newSep":p=l.newTab(T,"",cd,P,"&emsp;&emsp;");break;case "expTab":yb[a]=rb=b;mb=1;id(U);break;case "recPos":sb=b;mb=1;break;case "closeTab":b=W&&jb==U?jb.previousElementSibling||P.firstElementChild:0;if(h=oc(W,U,Wc,P))Rb(b),La.remove(hc(q)),q.type==Uc&&La.remove(hc(q)+"_");break;case "closeTabs":h=pc(W,U,m=>{q=m.d;La.remove(hc(q));q.type==Uc&&La.remove(hc(q)+"_")});
break;case "resumeTab":(h=qc(W,U))&&Rb(h);break;case "moveTabs":h=rc(W,U);break;case "selTabs":sc(W);break;case "multiTab":return Pc(),U&&W&&W.els(U)||(yb.mt=b),1;default:return yb[a]=b,1}k();return 1}
var Ad,Z,U,dc,Jb,qd;
function nd(a,b){if(b){if(window.e=a,ec()){b=Z.style;Z.p.style.display="block";var c=a.clientX,d=a.clientY;b.maxHeight="";if(Z.revert)b.right=E.innerWidth-c+5+"px",b.bottom=E.innerHeight-d+5+"px";else{var k=Z.parentNode.offsetWidth,h=Z.parentNode.offsetHeight;c+Z.offsetWidth/2>k&&(c=k-Z.offsetWidth/2,d+=2);b.left=c+"px";d+Z.offsetHeight>=h+45&&Z.offsetHeight/2>h-d&&150>h-d?(b.bottom=h-d+5+"px",b.top=b.maxHeight="",c=Z.cards[0].style,c.display="flex",c.flexDirection="column-reverse",b.maxHeight=Z.parentNode.offsetHeight-
(h-d+5)+"px",setTimeout(()=>{Z.cards[0].firstElementChild.scrollIntoView()},5)):(b.maxHeight=Z.parentNode.offsetHeight-d-5+"px",b.top=d+"px")}}}else setTimeout(()=>{nd(a,1)},5)}
function $b(a){Ga(a)}
function md(a,b,c){if(Ad){if(a&&Ad.n===a)return Ad.p.parentNode||document.body.append(Ad.p),Ad;Ad.parentNode&&Ad.remove()}var d=na("menup");d||(d=N(0,document.body),d.id="menup",d.onmousewheel=function(p){p.srcElement==d&&Tb()},d.onmouseup=function(p){var q=p.target;
q===d?Tb():1==k.type&&(Ga(p),2==p.button&&(window.oncontextmenu=$b),q.classList.contains("sep")||q==k||(p.delay=!0,wd(p)),2==p.button&&setTimeout(function(){window.oncontextmenu=0},20))});
var k=N(0,d,"menu","max-width:35%;overflow:overlay;overflow-x:hidden;"),h=k;h.cards&&(h.cards.forEach(function(p){p.remove()}),h.cards=0);
SettingsBuildCard(c,b,h);k.n=a;k.l=b;k.p=d;return Ad=k}
function Tb(){Z&&(Z.p.style.display="none",dc&&dc(Z),Z=null)}
if(ha)chrome.tabs.query({active:!0,lastFocusedWindow:!0},function(a){if(y=a[0])Kb(b=>{}),da&&da()});
else{var uc=document.title;document.title+=Math.random();chrome.tabs.query({title:document.title},function(a){if(y=a[0])Kb(b=>{}),l.bkWnds[y.id]=1;
document.title=uc;y.title=uc})}function gc(){}
setTimeout(function(){fb.remove();fb=0},95);
ha||chrome.runtime.onMessage.addListener(function(a,b,c){if("focus"==a.name)E.onfocus();if("blur"==a.name)E.onblur()});
rb&&id();var X=na("tabgroup"),Bd,Cd;function $c(){X.dirty||(X.dirty=()=>{X._dirty=l.verTG+1;X._dirty<=l.verTG&&(l.verTG=0,X._dirty=1)},Ha("mousewheel",function(a){var b=a.detail?-a.detail/3:-a.wheelDelta/120;
(b=Math[1<=b?"floor":"ceil"](b))&&X.scrollTo({left:X.scrollLeft+80*b,behavior:"auto"});Ga(a)},1,X));
Sa("tab_groups",a=>{a&&a.constructor===Array||(a=[]);0==a.length&&(a.push({id:"tabs",name:M("n3"),type:Vc}),a.push({id:"tabs1",name:M("ttg3")}),a.push({id:"tabs2",name:M("sk"),t0:2}),a.push({id:"tabs3",name:M("fv"),t0:3}));Bd=a;Dd(Bd)})}
function Ed(a){xd();a=a.target;if(a.d){if(a.d.id==lb.id)try{P.scrollTop=jb.offsetTop-ba/3*Sc;return}catch(b){}Cd&&Cd.classList.remove("sel");gd();Fd(a.d);a.classList.add("sel");Cd=a}}
function Fd(a){if(Q&&Q.onRemove)try{Q.onRemove(1)}catch(b){ma(b)}gd();xd();lb=a;qb=0;nc("sel_tab_gp",lb,()=>Tc())}
function gd(){P.save();var a=parseInt(P.scrollTop);if(lb&&qb&&(mb||a!=nb&&ha&&2!=lb.t0&&sb)){var b="v_"+lb.id+"__";mb=0;nb=a;var c=$a.indexOf(jb.d)||0;0>c&&(c=0);nc(b,{tix:c,hots:qb,scroll:a,exp:rb})}}
function nc(a,b,c){ha?Xa(a,b,c):(sessionStorage.setItem(a,JSON.stringify(b)),c&&c())}
function lc(a,b,c){if(ha||c)Sa(a,b);else{c=sessionStorage.getItem(a,null);try{c=JSON.parse(c)}catch(d){c=0}c?b&&b(c):lc(a,b,1)}}
function Dd(a){X.innerHTML="";N(0,X,"tgpd");for(var b=Cd=0,c;c=a[b++];){var d=N(0,X,"tg");d.innerText=c.name;d.id="tg_"+c.id;d.d=c;d.onclick=Ed;d.oncontextmenu=Gd;Hd||(d.draggable=!0,d.ondragstart=Id);c.id==lb.id&&(Cd=d,lb=c,d.classList.add("sel"))}N(0,X,"tgpd");Cd&&requestAnimationFrame(()=>{X.scrollLeft=Cd.offsetLeft-(X.offsetWidth-Cd.offsetWidth-45)/2})}
const Jd=0,Vc=1;function Kd(a,b,c){function d(I,x,K){m=Bd.indexOf(q);0>m?m=Bd.length:m++;for(var G=0,J=0,fa;fa=Bd[J++];)fa=1+(parseInt(fa.id.slice(4))||0),fa>G&&(G=fa);var ya=G;Sa("rcy_bin_tg",oa=>{function A(H){if(void 0===B[H]&&!na("tg_tabs"+(H||"")))return t={id:"tabs"+(G||""),name:I,type:K||Jd,t0:x},Bd.splice(m,0,t),Fd(t),h(),1}
var B=oa||[];for(oa=0;void 0!=B[oa++];);for(oa=0;!A(G)&&oa<ya+1024;)oa++,G=oa})}
function k(I){m=Bd.indexOf(q);p=1;if(I){Bd.splice(m,1);if(q==lb){(t=Bd[m])||(t=Bd[m-1]);if(!t){d(M("l"));return}Fd(t)}Sa("rcy_bin_tg",x=>{x=x||[];x.push(q);75<x.length&&x.splice(0,25);Xa("rcy_bin_tg",x)});
Sa(q.id,x=>{"string"===typeof x&&(x=JSON.parse(x));if(x)for(var K=0,G;G=x[K++];)La.remove(hc(G,q))});
La.remove("v_"+q.id+"__");h()}else m++,Sa("rcy_bin_tg",x=>{x=x||[];t=x.pop();Bd.splice(m,0,t);Fd(t);h();Xa("rcy_bin_tg",x)})}
function h(){Tb();if(p||t)X.dirty(),Dd(Bd)}
var p=0,q=U.d,t,m;switch(a){case "rename":if(a=prompt(M("2h"),q.name))q.name=a,p=1;break;case "newGroup":(a=prompt(M("z"),M("of")))&&d(a,3);return;case "ngpEmpty":d(M("l"));return;case "ngpBar":d(M("n3"),0,Vc);return;case "ngpBkmk":d("bookmarks",1);return;case "ngpSch":d(M("sk"),2);return;case "close":k(!0);return;case "restore":k(!1);return;default:return yb[a]=b,1}h();return 1}
function Gd(a){if(window.oncontextmenu==$b)$b(a);else{xd();for(var b=a.target,c=b==X;!c&&b&&!b.classList.contains("tg");)b=b.parentNode;c=["",[0,["rename",0],[M("hg")],1],[0,["newGroup",0],[M("7")],1,,[0,["ngpEmpty",0],[M("l")]],[0,["ngpBar",0],[M("n3")]],[0,["ngpBkmk",0],[M("5p")]],[0,["ngpSch",0],[M("sk")]]],[0,["close",0],[M("e")],1,[0,["restore",0],[M("sv")]]]];cc(c,Kd,a,b,Gd);if(ec()){Z.e=a;if(a=na("selTabs",fc()))a.title=M("a"),a.oncontextmenu=d=>{ld(W);Ga(d);Tb()};
if(a=na("rename",fc()))a.onmousedown=d=>{1==d.button&&(Ga(d),d.target.click())}}}}
function xd(){if(X._dirty>l.verTG){for(var a=[],b=0,c;c=X.children[b++];)c.d&&void 0!=c.d.id&&a.push(c.d);Xa("tab_groups",a,()=>{l.verTG=X._dirty})}}
var Ld=-1,Md;function Nd(){clearTimeout(Ld);var a=na("toastview");a.style.opacity=0;Ld=setTimeout(function(){Ld=-1;a.style.display="none"},300)}
function Mb(a,b,c,d,k){-1!=Ld&&clearTimeout(Ld);d||(d=z.body);var h=na("toastview");h||(h=N(0,d),h.id="toastview",N(0,h).id="toasttext");var p=h.parentNode;p!=d&&(p&&h.remove(),d.appendChild(h));d=h.firstChild;d.innerHTML=a;d.className=1<=b?"warn":"info";Ld=setTimeout(Nd,c||1E3);setTimeout(function(){h.style.opacity=1},16);
h.style.display="block";d.style.opacity=k||1}
function Hb(a,b){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},b||599)}
var Od;
function Dc(a){if(Od)a(Od);else{var b=y.pendingUrl||y.url,c=(new URL(b)).searchParams,d=c.get("q")||c.get("wd")||c.get("search")||c.get("searchkey")||c.get("keyword")||c.get("query")||c.get("sokeytm")||c.get("char")||c.get("text")||c.get("queryField_a")||c.get("w")||c.get("q1")||c.get("terms")||c.get("term");null===d&&(c=b.indexOf("zdic.net/hans/"),0<c&&(d=b.slice(14)),0>c&&(c=b.indexOf("dictionary/"),0<c&&(d=b.slice(11))),0>c&&(c=b.indexOf("/zh/"),0<c&&(d=b.slice(4))),0>c&&(c=b.indexOf("/search/"),0<
c&&(d=b.slice(c+8))),d&&(c=d.indexOf("?"),0<c&&(d=d.slice(0,c))));null===d&&(d="");d=decodeURIComponent(d).replace(/\+/g," ");ha?chrome.tabs.executeScript(y.id,{code:"window.getSelection().toString()"},function(k){k&&k[0]?a(k[0]):a(d)}):a(d)}}
function hc(a,b){return"v_"+(b||lb).id+"_"+a.id}
function Bc(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return'url("chrome://favicon/'+a+'")'}
function Pd(a){var b=a.indexOf("/",a.indexOf(":")+3);0<b&&(a=a.slice(0,b));return"chrome://favicon/"+a}
function Qd(a){for(var b=0,c=0,d=0,k=a.length/4,h=0;h<a.length;h+=4)b+=a[h],c+=a[h+1],d+=a[h+2];return"rgb("+Math.round(b/k)+","+Math.round(c/k)+","+Math.round(d/k)+")"}
function Rd(a){for(var b={},c=0,d=null,k=0;k<a.length;k+=4){var h=a[k],p=a[k+1],q=a[k+2];255==a[k+3]&&(h=h+","+p+","+q,b[h]?b[h]++:b[h]=1,b[h]>c&&(c=b[h],d=h))}return"rgb("+d+")"}
var Hd;function Sd(a){l.initSortable(z,E);Hd=new Sortable(X,{multiDrag:!0,revertOnSpill:!0,swapThreshold:.34,invertSwap:!0,selectedClass:"selected",animation:300,ghostClass:"blue-background-class",group:"tabG",root:!0,forceFallback:!1,sort:!0,anisk:1,onMove(b){this.options.animation=300;if(b.dragged.fixed||b.related.fixed)return!1},onEnd:function(b){Hd.did(b)&&X.dirty()},
down(b){this.d=b.target;this.gridis=b.altKey&&b.shiftKey;E.disani=0},click(b){Ed(b)},trace:function(){console.log("trace"+Error().stack)}});
a&&(Hd._onTapStart(a),a.constructor==DragEvent?Hd._onDragStart(a):Hd._onDrop(a),Id(a,1))}
function Id(a,b){Hd?a&&(b?X.onclick=a.target.ondragstart=void 0:Id(a,1)):l.initSortable&&!Fb?Sd(a):l.loadSortable(function(){Sd(a)})}
function Zb(a){return`<div style="margin-top:8px;display:flex;justify-content: space-between;flex-direction: row;">
            <div style="white-space:nowrap;font-size:.89em;padding-right:10px;text-align:center;padding-top:7.9px;">${a}</div>
            <textarea class='eta' style="flex:1;resize:vertical;min-height:30px;font-size: large;padding-left: 17px; padding-top: 10px;"></textarea>
        </div>`}
function ac(a){return a.type==Ea&&!a.path.startsWith("q=")&&!a.path.startsWith("recent")}
function pd(a,b,c){function d(t){ra("hot",qd)?.classList.remove("hot");t.target.classList.add("hot");c(t.target.idx)}
var k=Z.style;if(!qd){qd=N(0,0,"tabG");var h=qd.style;h.position="fixed";h.height="auto";h.background="white";h.borderRadius="4px";h.transform="scale(0.9)";h.transformOrigin="left";h.boxShadow=getComputedStyle(Z.cards[0]).boxShadow}h=qd.style;qd.innerText="";for(var p=0;p<a.length;p++){var q=N(0,qd,"tg"+(b==p?" hot":""));q.idx=p;va(q,a[p]);q.onclick=d}h.left=parseInt(k.left)+1.5+"px";k.top?(h.bottom=Z.parentNode.offsetHeight-parseInt(k.top)-.75+"px",h.top=""):(h.top=Z.parentNode.offsetHeight-parseInt(k.bottom)+
"px",h.bottom="");na("menup").insertBefore(qd,Z)}
function ec(){return!!E.SettingsBuildCard}
function fc(){return Z.shadowRoot||z}
function Hb(a){a=a.style;a._transf_ybd||(a._transf_ybd=a.transform);a.transition="transform 0.4s";a.transform="scale(1.5)";setTimeout(()=>{a.transform=a._transf_ybd},599)}
function Kb(a){chrome.bookmarks.search({url:y.url},function(b){a(ea=b?b[0]:0)})}
function Ob(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){a(y=b?b[0]:0)})}
function Nb(a,b){chrome.tabs.query({url:a},b)}
function yd(){var a=Za.bkmks.indexOf(eb);0<=a&&Za.bkmks.splice(a,1)}
function Gb(a){return void 0!=a.dateGroupModified}
function bc(a,b){try{return(new URL(a)).hostname===(new URL(b)).hostname}catch(c){}}
function Td(a){Q.et.value=a.target.innerText}
function yc(){l.getSchKeys(a=>{zc.innerHTML="";for(var b=a.length-1;0<=b;b--){var c=a[b],d=N(0,zc,"sch-item");d.onclick=Td;va(d,c)}})}
function zd(a){Yb("assets/dialog.js",function(){var b=showDialog(z,z.body);va(b.t,"Edit");za(b.t1,Zb("CODE"));va(b.btn0,"Save");var c=a.tabView,d=c?._bg,k=qa("TEXTAREA",b.t1);c?(k[0].value=d.src,b.btn0.onclick=()=>{var h=k[0].value;Xa(c.k+"_",h,p=>{d.src=h;c.reload(d);b.s.remove()})}):Sa(hc(a.d)+"_",h=>{k[0].value=h;
b.btn0.onclick=()=>{var p=k[0].value;Xa(hc(a.d)+"_",p,q=>{b.s.remove()})}});
b.btn1.onclick=()=>{b.s.remove()}},E.showDialog)}
;