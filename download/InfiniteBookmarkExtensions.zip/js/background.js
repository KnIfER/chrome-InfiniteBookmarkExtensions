'use strict';var data={},fakePP=0,debug=console.log,log=console.log,verTG=0,_DEBUG=1,num_tabs=0;function geVal(a,b){chrome.storage.local.get(a,b)}
function getVal(a,b){geVal(a,c=>{b(c[a])})}
function tVal(a){}
function seVal(a,b){chrome.storage.local.set(a,b)}
function setVal(a,b,c){var l={};l[a]=b;seVal(l,c)}
function gm(a){return chrome.i18n.getMessage(a)||a}
var menu=chrome.contextMenus;_DEBUG&&menu.removeAll();(function(){function a(g){if(1>g)throw Error("长度不能小于1");var e={};e.data=new Map;e.sz=g;e.set=function(f,k){var h=e.data,r=e.sz;h.delete(f);h.set(f,k);h.size>r&&(f=h.keys().next().value,h.delete(f))};
e.get=function(f){var k=e.data;if(k.has(f)){var h=k.get(f);k.delete(f);k.set(f,h);f=h}else f=null;return f};
return e}
function b(g,e){var f=popupCache.bkmk?.id;if(f==g||f==e)popupCache.bkmk=0;(f=c!=g&&(!e||e!=l))||(m=Date.now(),f=100<=m-p);if(f){p=m;c=g;l=e;f=0;for(var k,h;k=data.bkmks[f++];){if(h=k[g])h.data=null,h.stl=!0,h.ver++;e&&(h=k[e])&&(h.data=null,h.stl=!0,h.ver++)}}}
(function(){chrome.bookmarks.onMoved.addListener(function(g,e){b(e.oldParentId,e.parentId)});
chrome.bookmarks.onRemoved.addListener(function(g,e){b(e.parentId)});
chrome.bookmarks.onCreated.addListener(function(g,e){b(e.parentId)});
chrome.bookmarks.onChanged.addListener(function(g,e){chrome.bookmarks.get(g,function(f){f&&f.length&&b(f[0].parentId)})});
chrome.bookmarks.onChildrenReordered.addListener(function(g,e){b(g)})})();
var c,l,p=0,m=0,n=a(5);window.newLru=a;window.pullBkmk=function(g,e,f,k){if(k){f&&(popupCache={});k=0;for(var h;h=data.bkmks[k++];)if(h=h[g])h.data=null,h.stl=!0,h.ver++}if(popupCache.bkmk?.id===g&&popupCache.bkmk?.data)e(popupCache.bkmk?.data);else if(g.startsWith("recent")){var r=parseInt(g.slice(6).replaceAll("=","").trim())||1E3;chrome.bookmarks.getRecent(r,function(q){e(q);f&&(popupCache.bkmk={id:g,data:q})})}else if(g.startsWith("q="))chrome.bookmarks.search(g.slice(2),function(q){e(q);
f&&(popupCache.bkmk={id:g,data:q})});
else{var t=0;for(k=0;h=data.bkmks[k++];)if((r=h[g])&&r.data){t=r.data;break}t?(setTimeout(function(){e(t)},0),f&&(popupCache.bkmk={id:g,
data:t})):chrome.bookmarks.getChildren(g,function(q){n.set(g,q);e(q);f&&(popupCache.bkmk={id:g,data:q})})}}})();
data.bkmks=[];function d(){return data}
loadJs("tabModel.js",function(){});
menu.create({id:"open_page",title:gm("c"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp",title:gm("f"),contexts:["browser_action","page_action"]},()=>{});
menu.create({id:"add_tmp1",title:gm("f")+" ("+gm("hw")+")",contexts:["browser_action","page_action"]},()=>{});
var _MD;menu.onClicked.addListener(func);function func(a){a=a.menuItemId;"open_page"==a&&chrome.tabs.create({url:`chrome-extension://${chrome.runtime.id}/js/popup/popup_index.html`});"add_tmp"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b)});
"add_tmp1"==a&&chrome.tabs.query({active:!0,currentWindow:!0},function(b){b=b[0];addToTmpUrls(b.pendingUrl||b.url,b.title,b,0,!0)});
_DEBUG&&_MD&&_MD(a)}
var tmpUrlData,tmpUrlPath,tmpUrlDataDirty,impUrlTd={};function getImpd(a){if(a==tmpUrlPath&&tmpUrlData)return tmpUrlData}
function cacheImpd(a,b){getTmpUrlPath(c=>{a==c&&(tmpUrlData=b)})}
function getTmpUrlPath(a){tmpUrlPath?a(tmpUrlPath):getVal("sel_tmp_url",b=>{b||="";b.startsWith("imp_")||(b="imp_tmp");tmpUrlPath=b;a(tmpUrlPath)})}
function setTmpUrlPath(a,b){tmpUrlPath!=a&&(tmpUrlDataDirty&&saveTmpUrls(),tmpUrlData=tmpUrlPath=0,setVal("sel_tmp_url",a,b))}
getTmpUrlPath(()=>{});
function getTmpUrlData(a){tmpUrlData?a(tmpUrlData):getTmpUrlPath(b=>{getVal(b,c=>{c||={};c.data||(c.data=[]);tmpUrlData=c;a(c)})})}
function pullImpt(a,b){var c=tmpUrlPath===a;if(c&&tmpUrlData)b(tmpUrlData);else{var l=0;if(!l){for(var p=0,m;(m=data.bkmks[p++])&&!(l=m[a]););l?(setTimeout(function(){b(l)},0),c&&(tmpUrlData=l)):getVal(a,n=>{n||={};
n.data||(n.data=[]);"string"==typeof n.data&&(n.data=JSON.parse(n.data));b(n);c&&(tmpUrlData=n)})}}}
function addToTmpUrls(a,b,c,l,p){getTmpUrlData(m=>{function n(k){p?m.data.splice(0,0,k):"add"==m.data[m.data.length-1]?.url?m.data.splice(m.data.length-1,0,k):m.data.push(k)}
for(var g=!1,e=0;e<m.data.length;e++)if(m.data[e].url===a){p?m.data.splice(e,1):g=!0;break}if(!g){var f=c?.url;function k(){b=f.slice(f.indexOf(":")+3);0<b.indexOf("/",5)&&(b=b.slice(0,b.indexOf("/",5)))}
void 0!==b||f.startsWith("chrome")||f.startsWith("edge")?(b||k(),n({url:a,title:b,favIconUrl:c.favIconUrl}),tmpUrlDataDirty=!0,l&&l(m.data)):chrome.tabs.executeScript(c.id,{code:`window._tmpUrl=\"${a.replace('"',"")}\";window._tmpTop=${p}`},function(h){chrome.tabs.executeScript(c.id,{file:"js/tada_active.js"},function(r){(b=r[0])&&"undefined"!=b||k();n({url:a,title:b,favIconUrl:c.favIconUrl});tmpUrlDataDirty=!0;l&&l(m.data)})})}})}
menu.create({title:gm("a2"),contexts:["link"],onclick:function(a,b){setTimeout(()=>{var c=Date.now()-topTempTime;addToTmpUrls(a.linkUrl,void 0,b,0,100>c&&0<=c)},50)}});
function loadSortable(a){loadJs("popup/Sortable.js",function(){a()})}
function loadListView(a){loadJs("popup/ListView.js",function(){a&&a()})}
function loadJs(a,b){var c=document.createElement("script");c.type="text/javascript";c.onload=b;c.src=a;document.body.appendChild(c)}
var lastAct,bkWnds={};chrome.tabs.onActivated.addListener(function(a){bkWnds[lastAct]&&chrome.tabs.sendMessage(lastAct,{name:"blur"},function(b){});
bkWnds[lastAct=a.tabId]&&chrome.tabs.sendMessage(a.tabId,{name:"focus"},function(b){});
tmpUrlDataDirty&&saveTmpUrls()});
data.favTabsVer=data.favTabsSave=data.tabsVer=0;function saveImportabs(a,b){cacheImpd(a,b);setVal(a,b,function(){})}
chrome.tabs.onUpdated.addListener(function(a,b,c){if(a=data.favTabs[a])data.favTabsVer++,a.lastUrl=a.url!=c.url?c.url:void 0});
chrome.tabs.getAllInWindow(null,function(a){num_tabs=a.length});
chrome.tabs.onCreated.addListener(function(a){num_tabs++});
chrome.tabs.onRemoved.addListener(function(a){num_tabs--;0==num_tabs&&onClose()});
function onUnLoad(){chrome.storage.local.set({date:Date.now()},function(){})}
function saveTmpUrls(){tmpUrlDataDirty=0;tmpUrlData&&setVal(tmpUrlPath,tmpUrlData)}
function onClose(){data.favTabsSave!=data.favTabsVer&&saveImportabs();onUnLoad();tmpUrlDataDirty&&saveTmpUrls()}
chrome.runtime.onMessage.addListener(function(a,b,c){if(a&&a.type&&("paste"==a.type&&sendPasteToContentScript(a.data),"openAll"==a.type)){a=a.urls.split("{BKMKBK}");b=0;for(var l in a){let p=a[l];setTimeout(function(){p&&chrome.tabs.create({url:p,active:!1})},500*b);
b++}}});
function getContentFromClipboard(){var a="",b=document.getElementById("sandbox");b.value="";b.select();document.execCommand("paste")&&(a=b.value,console.log("got value from sandbox: "+a));b.value="";return a}
function sendPasteToContentScript(a){chrome.tabs.query({active:!0,currentWindow:!0},function(b){chrome.tabs.sendMessage(b[0].id,{data:a})})}
var topTempTime;chrome.commands.onCommand.addListener(function(a){console.log("Command:",a,typeof a,Date.now());"top-temp-url"==a&&(topTempTime=Date.now())});
var schKeys=void 0;function getSchKeys(a){void 0==schKeys?getVal("sch_keys",b=>{a(schKeys=b||[])}):a(schKeys)}
function putSchKey(a){getSchKeys(b=>{if(b[b.length-1]!=a){for(var c=0;c<b.length;c++)if(b[c]==a){b.splice(c,1);break}b.push(a);25<b.length&&b.splice(0,b.length-20);setVal("sch_keys",b)}})}
function exportSettings(a){chrome.storage.local.get(null,function(b){console.log(b);a&&a(b)})}
function importSettings(a,b){try{a=JSON.parse(a)}catch(c){console.log(c)}"object"===typeof a&&chrome.storage.local.set(a,function(c){b&&b(c)})}
;